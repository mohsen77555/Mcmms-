import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { error: any }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { error };
  }

  componentDidCatch(error: any, info: any) {
    console.error("CMMS runtime error", error, info);
  }

  resetAll = () => {
    try {
      window.localStorage.removeItem("cmms-firebase-config");
      window.localStorage.removeItem("alhadi-cmms-firebase-config");
    } catch {}
    window.location.reload();
  };

  render() {
    if (this.state.error) {
      return (
        <div dir="rtl" style={{ minHeight: "100vh", background: "#F2F3F1", color: "#16191B", fontFamily: "system-ui, sans-serif", padding: 18, display: "grid", placeItems: "center" }}>
          <div style={{ background: "#fff", border: "2px solid #16191B", borderRight: "8px solid #D9480F", borderRadius: 6, padding: 16, maxWidth: 520, width: "100%" }}>
            <h2 style={{ marginTop: 0 }}>حدث خطأ في الشاشة</h2>
            <p style={{ lineHeight: 1.8, color: "#7A858C" }}>لا تقلق، البيانات لم تُحذف. غالبًا السبب إعداد Firebase غير مكتمل أو نسخة APK قديمة. اضغط إعادة المحاولة أو امسح ربط Firebase وأعد إدخال firebaseConfig.</p>
            <pre style={{ direction: "ltr", textAlign: "left", whiteSpace: "pre-wrap", background: "#F8F9FA", padding: 10, border: "1px solid #D8DCDA", borderRadius: 4, fontSize: 11, maxHeight: 180, overflow: "auto" }}>{String(this.state.error?.message || this.state.error)}</pre>
            <button onClick={() => window.location.reload()} style={{ width: "100%", marginTop: 8, padding: 12, border: "none", borderRadius: 4, background: "#16191B", color: "#fff", fontWeight: 800 }}>إعادة المحاولة</button>
            <button onClick={this.resetAll} style={{ width: "100%", marginTop: 8, padding: 12, border: "none", borderRadius: 4, background: "#D9480F", color: "#fff", fontWeight: 800 }}>مسح ربط Firebase وإعادة الفتح</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);
