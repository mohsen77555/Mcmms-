import { initializeApp, getApps, getApp, type FirebaseOptions } from "firebase/app";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, type User } from "firebase/auth";
import { initializeFirestore, getFirestore, persistentLocalCache, persistentMultipleTabManager, doc, getDoc, setDoc, collection, getDocs, updateDoc, writeBatch, type Firestore } from "firebase/firestore";

export const FIREBASE_CONFIG_STORAGE_KEY = "cmms-firebase-config-v1";
export const FIREBASE_OWNER_EMAIL = ((import.meta as any).env?.VITE_FIREBASE_OWNER_EMAIL || "mohsenalhadi77555@gmail.com").toLowerCase();

export type CmmsFirebaseServices = {
  app: ReturnType<typeof initializeApp>;
  auth: ReturnType<typeof getAuth>;
  firestore: Firestore;
  config: FirebaseOptions;
};

const ROLE_ALIASES: Record<string, string> = {
  "مدير": "مدير", admin: "مدير", manager: "مدير", owner: "مدير",
  "مشرف": "مشرف", supervisor: "مشرف",
  "فني": "فني", technician: "فني", tech: "فني",
  "مخزن": "مخزن", warehouse: "مخزن", storekeeper: "مخزن",
  "طالب خدمة": "طالب خدمة", requester: "طالب خدمة", requestor: "طالب خدمة", user: "طالب خدمة",
};

export function normalizeFirebaseRole(value: any): string {
  const raw = String(value || "").trim();
  if (!raw) return "";
  return ROLE_ALIASES[raw] || ROLE_ALIASES[raw.toLowerCase()] || raw;
}

function envConfig(): FirebaseOptions | null {
  const env = (import.meta as any).env || {};
  if (!env.VITE_FIREBASE_API_KEY || !env.VITE_FIREBASE_PROJECT_ID || !env.VITE_FIREBASE_APP_ID) return null;
  return {
    apiKey: env.VITE_FIREBASE_API_KEY,
    authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || `${env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
    projectId: env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || `${env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
    messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || "",
    appId: env.VITE_FIREBASE_APP_ID,
  };
}

export function extractFirebaseConfig(text: string): FirebaseOptions | null {
  const input = String(text || "").trim();
  if (!input) return null;

  try {
    const parsed = JSON.parse(input);
    if (parsed?.apiKey && parsed?.projectId && parsed?.appId) return parsed;
  } catch {}

  const keys = ["apiKey", "authDomain", "projectId", "storageBucket", "messagingSenderId", "appId", "measurementId"];
  const cfg: any = {};
  for (const key of keys) {
    const m = input.match(new RegExp(`${key}\\s*:\\s*[\"']([^\"']+)[\"']`));
    if (m) cfg[key] = m[1];
  }
  if (cfg.apiKey && cfg.projectId && cfg.appId) return cfg;
  return null;
}

export function runtimeConfig(): FirebaseOptions | null {
  if (typeof window === "undefined" || !window.localStorage) return null;
  try {
    const raw = window.localStorage.getItem(FIREBASE_CONFIG_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function getFirebaseConfig(): FirebaseOptions | null {
  return envConfig() || runtimeConfig();
}

export function saveRuntimeFirebaseConfig(config: FirebaseOptions) {
  if (typeof window === "undefined" || !window.localStorage) return;
  window.localStorage.setItem(FIREBASE_CONFIG_STORAGE_KEY, JSON.stringify(config));
}

export function clearRuntimeFirebaseConfig() {
  if (typeof window === "undefined" || !window.localStorage) return;
  window.localStorage.removeItem(FIREBASE_CONFIG_STORAGE_KEY);
}

let cachedServices: CmmsFirebaseServices | null = null;

export function getFirebaseServices(): CmmsFirebaseServices | null {
  if (cachedServices) return cachedServices;
  const config = getFirebaseConfig();
  if (!config) return null;

  let app: ReturnType<typeof initializeApp>;
  try {
    app = getApps().length ? getApp() : initializeApp(config);
  } catch (e) {
    console.error("Firebase config غير صالح", e);
    return null;
  }
  let firestore: Firestore;
  try {
    firestore = initializeFirestore(app, {
      ignoreUndefinedProperties: true,
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    });
  } catch {
    // initializeFirestore throws if Firestore was already initialized; re-use the existing instance.
    firestore = getFirestore(app);
  }
  cachedServices = { app, auth: getAuth(app), firestore, config };
  return cachedServices;
}

export function subscribeFirebaseAuth(services: CmmsFirebaseServices, cb: (user: User | null) => void) {
  return onAuthStateChanged(services.auth, cb);
}

export async function signInFirebase(services: CmmsFirebaseServices, email: string, password: string) {
  return signInWithEmailAndPassword(services.auth, email.trim(), password);
}

export async function registerFirebase(services: CmmsFirebaseServices, email: string, password: string) {
  return createUserWithEmailAndPassword(services.auth, email.trim(), password);
}

export async function signOutFirebase(services: CmmsFirebaseServices) {
  return signOut(services.auth);
}

export async function ensureFirebaseUserProfile(services: CmmsFirebaseServices, user: User) {
  const token = await user.getIdTokenResult(false);
  const claims: any = token.claims || {};
  const claimRole = normalizeFirebaseRole(claims.role || claims.cmmsRole || claims.cmms_role);
  const claimTechId = String(claims.technicianId || claims.techId || claims.cmmsTechId || "");
  const email = String(user.email || "").toLowerCase();
  const isOwner = email === FIREBASE_OWNER_EMAIL;

  const ref = doc(services.firestore, "users", user.uid);
  const snap = await getDoc(ref);
  const existing: any = snap.exists() ? snap.data() : null;
  const storedRole = normalizeFirebaseRole(existing?.role);
  const role = isOwner ? "مدير" : (claimRole || storedRole || "طالب خدمة");
  const technicianId = existing?.technicianId || claimTechId || "";
  const nowIso = new Date().toISOString();
  const patch: any = snap.exists()
    ? {
        displayName: existing?.displayName || user.displayName || "",
        technicianId,
        updatedAtIso: nowIso,
        lastLoginAtIso: nowIso,
      }
    : {
        email: user.email || "",
        displayName: user.displayName || "",
        role,
        technicianId,
        createdAtIso: nowIso,
        updatedAtIso: nowIso,
        lastLoginAtIso: nowIso,
      };

  try {
    await setDoc(ref, patch, { merge: true });
  } catch (e) {
    console.warn("تعذر تحديث ملف المستخدم؛ سيتم استخدام الدور المقروء فقط", e);
  }

  return { ...(existing || {}), ...patch, role, email: user.email || existing?.email || "", uid: user.uid, claims, isOwner };
}

/*
  تخزين Firestore الجديد:
  - كل سجل يصبح مستندًا مستقلًا:
    cmms/main/records/{entityKey}/rows/{recordId}
  - الكائنات المفردة مثل settings:
    cmms/main/singletons/{key}
  - بيانات التعريف والترحيل:
    cmms/main/meta/state
  - المسار القديم cmms/main/entities/{entityKey} يبقى للقراءة فقط حتى لا تضيع بيانات النسخ السابقة.
*/
const WORKSPACE_PATH = ["cmms", "main"] as const;
const LEGACY_ENTITY_COLLECTION_PATH = ["cmms", "main", "entities"] as const;
const META_STATE_PATH = ["cmms", "main", "meta", "schema"] as const;
let firestoreRecordModeConfirmed = false;

export const CMMS_RECORD_ENTITY_KEYS = [
  "maintenanceOrganizations", "plantParameters", "workAreas", "workCenters", "resources", "workCenterResources",
  "resourceInstances", "shifts", "resourceExceptions", "infolets", "importBatches",
  "governancePolicies", "approvalMatrix", "governanceApprovalRequests", "governanceDataQualityRules", "governanceRisks", "governanceChangeRequests", "governanceReviews", "governanceAuditEvents",
  "governanceFrameworks", "governanceControlLibrary", "governanceControlTests", "governanceEvidenceRegister", "governanceAuthorityLimits", "governanceSoDRules", "governanceRaciMatrix", "governanceDataOwners", "governanceKpiDefinitions", "governanceSlaRules", "governanceExceptionRegister", "governanceCapaActions", "governanceBackupPolicies", "governanceRetentionRules", "governanceSecurityReviews", "governanceAccessCertifications", "governanceReleaseGates", "governanceReadinessChecklist", "governanceERecords", "governanceEscalationRules", "governanceChangeImpactAssessments", "governanceTrainingRecords", "governanceIncidentReviews", "governancePolicyAcknowledgements",
  "technicians", "assets", "assetGroups", "assetParts", "assetRelationships", "assetLogicalHierarchyNodes", "assetFlexfields", "assetImportBatches",
  "assetFixedAssetLinks", "assetServiceMappings", "assetIotSyncEvents", "assetMaterialComponentTransactions",
  "meterTemplates", "assetMeters", "readings", "warranties",
  "stdOps", "workDefs", "workRequests", "programs", "workOrders",
  "workRequestAttachments", "standardOperationSteps",
  "workDefinitionOperations", "workDefinitionSteps", "workDefinitionMaterials", "workDefinitionResources", "workDefinitionVersions",
  "maintenanceProgramAssets", "maintenanceProgramGroups", "maintenanceForecasts",
  "workOrderSteps", "workOrderResources", "workOrderAssignments", "workOrderStatusHistory", "workOrderAttachments", "workOrderPhotos", "workOrderFailures", "workOrderExceptions", "workOrderCosts", "workOrderApprovals",
  "dispatchListViews", "technicianTasks", "workOrderExecutionSessions", "workOrderOperationTransactions", "workOrderLaborTransactions", "workOrderMaterialUsage", "workOrderMaterialReturns", "workOrderFailureRecords", "workOrderInspectionResults", "workOrderSafetyChecklists", "workOrderChecklistAnswers", "workOrderCompletionRequests", "workOrderSupervisorReviews", "workOrderExecutionHistory",
  "supervisionSavedSearches", "supervisionScheduleSnapshots", "workOrderScheduleConflicts",
  "supervisionAssignmentPlans", "resourceCapacitySnapshots", "resourceScheduleConflicts",
  "maintenanceForecastRuns", "maintenanceForecastActions", "maintenanceReportJobs",
  "forecastRuns", "forecastValidationIssues", "forecastSuppressionRules", "forecastMergeGroups",
  "reportJobs", "savedReportOutputs", "reportSchedules", "inventoryReservations", "materialIssueRequests", "materialReturnRequests", "laborCostTransactions",
  "items", "warehouses", "stockTx",
  "warrantyProviders", "laborRates", "repairTimes", "coverages", "contracts", "entitlements", "claims",
  "assetGroupRules", "logicalHierarchies",
];

export const CMMS_SINGLETON_KEYS = ["settings"];

function stableJson(value: any) {
  return JSON.stringify(value ?? null);
}

function cleanForFirestore(value: any): any {
  if (Array.isArray(value)) return value.map(cleanForFirestore);
  if (value && typeof value === "object") {
    const out: any = {};
    for (const [k, v] of Object.entries(value)) {
      if (v === undefined) continue;
      out[k] = cleanForFirestore(v);
    }
    return out;
  }
  return value;
}

function stripCmmsMeta(row: any) {
  if (!row || typeof row !== "object") return row;
  const out: any = { ...row };
  delete out._cmmsEntity;
  delete out._cmmsOrder;
  delete out._updatedAtIso;
  delete out._updatedBy;
  delete out._updatedByEmail;
  delete out._updatedByRole;
  delete out._createdByMigration;
  return out;
}

function recordIdFor(row: any, index: number) {
  const id = row?.id ?? row?.uid ?? row?.code ?? row?.number ?? row?.email;
  return String(id || `row-${index + 1}`)
    .replace(/[\/#[\]?]/g, "-")
    .slice(0, 140);
}

function recordsCollection(services: CmmsFirebaseServices, entityKey: string) {
  return collection(services.firestore, ...WORKSPACE_PATH, "records", entityKey, "items");
}

function recordDoc(services: CmmsFirebaseServices, entityKey: string, recordId: string) {
  return doc(services.firestore, ...WORKSPACE_PATH, "records", entityKey, "items", recordId);
}

function singletonDoc(services: CmmsFirebaseServices, key: string) {
  return doc(services.firestore, ...WORKSPACE_PATH, "meta", key);
}

function metaDoc(services: CmmsFirebaseServices) {
  return doc(services.firestore, ...META_STATE_PATH);
}

async function readLegacyEntities(services: CmmsFirebaseServices) {
  const raw: any = {};
  try {
    const snap = await getDocs(collection(services.firestore, ...LEGACY_ENTITY_COLLECTION_PATH));
    snap.forEach((d) => {
      raw[d.id] = d.data()?.value;
    });
  } catch (e) {
    console.warn("تعذر قراءة التخزين القديم entities؛ سيتم تجاهله", e);
  }
  return raw;
}

async function runLimited<T>(items: T[], limit: number, worker: (item: T, index: number) => Promise<void>) {
  let cursor = 0;
  const workers = new Array(Math.min(limit, items.length)).fill(0).map(async () => {
    while (cursor < items.length) {
      const index = cursor++;
      await worker(items[index], index);
    }
  });
  await Promise.all(workers);
}

function metaArrayKeysToRead(meta: any, fallbackRaw: any, hasRecordMeta: boolean) {
  const rawKeys = Object.keys(fallbackRaw || {}).filter((k) => Array.isArray(fallbackRaw[k]));
  const nonEmpty = Array.isArray(meta?.nonEmptyArrayEntityKeys) ? meta.nonEmptyArrayEntityKeys : null;
  const counts = meta?.arrayEntityCounts && typeof meta.arrayEntityCounts === "object" ? meta.arrayEntityCounts : null;

  if (hasRecordMeta && nonEmpty) return [...new Set([...nonEmpty, ...rawKeys])];
  if (hasRecordMeta && counts) return [...new Set([...Object.keys(counts).filter((k) => Number(counts[k] || 0) > 0), ...rawKeys])];

  // توافق مع النسخ القديمة: إذا لم توجد فهارس nonEmpty نقرأ المفاتيح المعروفة مرة واحدة،
  // وبعد أول حفظ ستُكتب nonEmptyArrayEntityKeys ويصبح الدخول التالي أسرع.
  return [...new Set([...(hasRecordMeta ? ((meta?.arrayEntityKeys || []) as string[]) : CMMS_RECORD_ENTITY_KEYS), ...rawKeys])];
}

export async function loadCmmsStateFromFirestore(services: CmmsFirebaseServices) {
  const raw: any = {};
  let hadNewDocs = false;

  let meta: any = null;
  try {
    const metaSnap = await getDoc(metaDoc(services));
    if (metaSnap.exists()) {
      meta = metaSnap.data();
      hadNewDocs = true;
    }
  } catch (e) {
    console.warn("تعذر قراءة CMMS meta/state", e);
  }

  const hasRecordMeta = meta?.storageMode === "record-per-document";
  if (hasRecordMeta) firestoreRecordModeConfirmed = true;

  let legacyEntityKeys: string[] = [];
  if (!hasRecordMeta) {
    Object.assign(raw, await readLegacyEntities(services));
    legacyEntityKeys = Object.keys(raw);
  }

  const arrayKeys = metaArrayKeysToRead(meta, raw, hasRecordMeta);
  const singletonKeys = [...new Set([
    ...CMMS_SINGLETON_KEYS,
    ...((meta?.singletonKeys || []) as string[]),
    ...Object.keys(raw).filter((k) => !Array.isArray(raw[k])),
  ])];

  await runLimited(arrayKeys, 8, async (key) => {
    try {
      const snap = await getDocs(recordsCollection(services, key));
      if (!snap.empty) {
        const rows: any[] = [];
        snap.forEach((d) => {
          const data: any = d.data();
          rows.push({ ...stripCmmsMeta(data), __order: typeof data?._cmmsOrder === "number" ? data._cmmsOrder : 999999 });
        });
        rows.sort((a, b) => Number(a.__order || 0) - Number(b.__order || 0));
        raw[key] = rows.map((r) => {
          const out = { ...r };
          delete out.__order;
          return out;
        });
        hadNewDocs = true;
      }
    } catch (e) {
      console.warn(`تعذر قراءة سجلات ${key}`, e);
    }
  });

  await runLimited(singletonKeys, 8, async (key) => {
    try {
      const snap = await getDoc(singletonDoc(services, key));
      if (snap.exists()) {
        const data: any = snap.data();
        raw[key] = data?.value ?? null;
        hadNewDocs = true;
      } else if (meta && !(key in raw)) {
        raw[key] = key === "settings" ? {} : null;
      }
    } catch (e) {
      console.warn(`تعذر قراءة ${key}`, e);
    }
  });

  if (!hadNewDocs && legacyEntityKeys.length === 0) return null;
  raw._meta = {
    storageMode: hasRecordMeta ? "record-per-document" : "legacy-entities",
    recordDocsDetected: hadNewDocs,
    legacyEntityKeys,
    loadedAtIso: new Date().toISOString(),
  };
  return raw;
}

export function changedEntityKeys(prev: any, next: any) {
  const keys = new Set([...Object.keys(prev || {}), ...Object.keys(next || {})]);
  keys.delete("_meta");
  return [...keys].filter((k) => stableJson(prev?.[k]) !== stableJson(next?.[k]));
}

async function commitOperations(services: CmmsFirebaseServices, ops: any[]) {
  const chunkSize = 430; // أقل من حد Firestore batch وهو 500 عملية.
  for (let i = 0; i < ops.length; i += chunkSize) {
    const batch = writeBatch(services.firestore);
    for (const op of ops.slice(i, i + chunkSize)) {
      if (op.type === "delete") batch.delete(op.ref);
      else batch.set(op.ref, op.data, op.options || { merge: false });
    }
    await batch.commit();
  }
}

export async function saveCmmsStateToFirestore(services: CmmsFirebaseServices, prev: any, next: any, actor: { uid?: string; email?: string | null; role?: string }) {
  const initialRecordMigration = !firestoreRecordModeConfirmed && prev?._meta?.storageMode !== "record-per-document";
  const changedSet = new Set(changedEntityKeys(prev, next));
  if (initialRecordMigration) {
    Object.keys(next || {}).forEach((k) => { if (k !== "_meta") changedSet.add(k); });
  }
  const changed = [...changedSet];
  if (!changed.length) return [];

  const at = new Date().toISOString();
  const ops: any[] = [];
  const actorMeta = {
    _updatedAtIso: at,
    _updatedBy: actor.uid || "",
    _updatedByEmail: actor.email || "",
    _updatedByRole: actor.role || "",
  };

  for (const key of changed) {
    const nextValue = next?.[key];
    const prevValue = prev?.[key];

    if (Array.isArray(nextValue)) {
      const prevRows = Array.isArray(prevValue) ? prevValue : [];
      const prevMap = new Map<string, any>();
      prevRows.forEach((row, index) => prevMap.set(recordIdFor(row, index), row));

      const nextIds = new Set<string>();
      nextValue.forEach((row, index) => {
        const recordId = recordIdFor(row, index);
        nextIds.add(recordId);
        const previous = prevMap.get(recordId);
        if (stableJson(previous) !== stableJson(row)) {
          ops.push({
            type: "set",
            ref: recordDoc(services, key, recordId),
            data: cleanForFirestore({ ...row, _cmmsEntity: key, _cmmsOrder: index, ...actorMeta }),
            options: { merge: false },
          });
        }
      });

      prevMap.forEach((_row, recordId) => {
        if (!nextIds.has(recordId)) {
          ops.push({ type: "delete", ref: recordDoc(services, key, recordId) });
        }
      });
    } else {
      ops.push({
        type: "set",
        ref: singletonDoc(services, key),
        data: cleanForFirestore({ value: nextValue ?? null, updatedAtIso: at, updatedBy: actor.uid || "", updatedByEmail: actor.email || "", updatedByRole: actor.role || "" }),
        options: { merge: false },
      });
    }
  }

  const allArrayEntityKeys = Object.keys(next || {}).filter((k) => Array.isArray(next[k]));
  const arrayEntityCounts = Object.fromEntries(allArrayEntityKeys.map((k) => [k, Array.isArray(next[k]) ? next[k].length : 0]));
  const nonEmptyArrayEntityKeys = allArrayEntityKeys.filter((k) => Number(arrayEntityCounts[k] || 0) > 0);
  const singletonKeys = Object.keys(next || {}).filter((k) => !Array.isArray(next[k]) && k !== "_meta");
  ops.push({
    type: "set",
    ref: metaDoc(services),
    data: cleanForFirestore({
      schemaVersion: 3,
      storageMode: "record-per-document",
      arrayEntityKeys: nonEmptyArrayEntityKeys,
      allArrayEntityKeys,
      nonEmptyArrayEntityKeys,
      arrayEntityCounts,
      singletonKeys,
      updatedAtIso: at,
      updatedBy: actor.uid || "",
      updatedByEmail: actor.email || "",
      updatedByRole: actor.role || "",
    }),
    options: { merge: false },
  });

  await commitOperations(services, ops);
  firestoreRecordModeConfirmed = true;
  return changed;
}


export async function migrateCmmsStateToRecordFirestore(
  services: CmmsFirebaseServices,
  state: any,
  actor: { uid?: string; email?: string | null; role?: string }
) {
  const cleanState = { ...(state || {}) };
  delete cleanState._meta;

  const previousEmpty: any = { _meta: { storageMode: "legacy-entities" } };
  const changed = await saveCmmsStateToFirestore(services, previousEmpty, cleanState, actor);

  const records = Object.keys(cleanState).reduce((total, key) => {
    const value = cleanState[key];
    if (Array.isArray(value)) return total + value.length;
    return key === "settings" || value !== undefined ? total + 1 : total;
  }, 0);

  return {
    ok: true,
    records,
    changed,
    storageMode: "record-per-document",
  };
}

export async function listFirebaseUsers(services: CmmsFirebaseServices) {
  const snap = await getDocs(collection(services.firestore, "users"));
  const rows: any[] = [];
  snap.forEach((d) => rows.push({ id: d.id, uid: d.id, ...d.data() }));
  return rows.sort((a, b) => String(a.email || "").localeCompare(String(b.email || "")));
}

export async function updateFirebaseUserProfile(services: CmmsFirebaseServices, uid: string, patch: any) {
  await updateDoc(doc(services.firestore, "users", uid), { ...patch, updatedAtIso: new Date().toISOString() });
}
