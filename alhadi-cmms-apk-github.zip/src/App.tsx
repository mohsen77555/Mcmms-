import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import {
  clearRuntimeFirebaseConfig, ensureFirebaseUserProfile, extractFirebaseConfig, FIREBASE_OWNER_EMAIL,
  getFirebaseServices, listFirebaseUsers, loadCmmsStateFromFirestore, migrateCmmsStateToRecordFirestore, normalizeFirebaseRole, registerFirebase,
  saveCmmsStateToFirestore, saveRuntimeFirebaseConfig, signInFirebase, signOutFirebase, subscribeFirebaseAuth,
  updateFirebaseUserProfile, type CmmsFirebaseServices
} from "./firebaseCmms";

/* ───────────────────────── ثوابت ───────────────────────── */
const C = { ink:"#16191B", paper:"#F2F3F1", card:"#FFFFFF", orange:"#E8590C", steel:"#7A858C",
  line:"#D8DCDA", green:"#2F9E44", red:"#D9480F", amber:"#E67700", blue:"#1971C2", purple:"#7048E8" };
const KEY = "cmms-data-v1";
const API = (import.meta as any).env?.VITE_API_URL || (typeof window !== "undefined" && (window as any).__CMMS_API_URL__) || "http://localhost:4000/api";
const uid = () => Math.random().toString(36).slice(2, 9);
const pad2 = (n) => String(n).padStart(2, "0");
const dateOnly = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const today = () => { const d = new Date(); return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); };
const now = () => { try { return new Date().toISOString(); } catch { return today(); } };

// محول تاريخ آمن: يمنع انهيار التطبيق برسالة "Invalid time value" عند وجود
// تاريخ قديم كنص عربي، أو Timestamp من Firestore، أو قيمة فارغة/غير صالحة.
const parseDateValue = (value) => {
  if (!value) return null;
  try {
    if (value instanceof Date) return Number.isFinite(value.getTime()) ? dateOnly(value) : null;
    if (typeof value?.toDate === "function") {
      const d = value.toDate();
      return d instanceof Date && Number.isFinite(d.getTime()) ? dateOnly(d) : null;
    }
    if (typeof value === "object" && (typeof value.seconds === "number" || typeof value._seconds === "number")) {
      const d = new Date(Number(value.seconds ?? value._seconds) * 1000);
      return Number.isFinite(d.getTime()) ? dateOnly(d) : null;
    }
    if (typeof value === "number") {
      const d = new Date(value);
      return Number.isFinite(d.getTime()) ? dateOnly(d) : null;
    }
    const raw = String(value).trim();
    if (!raw) return null;
    const iso = raw.match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if (iso) {
      const y = Number(iso[1]), m = Number(iso[2]), dd = Number(iso[3]);
      const dt = new Date(y, m - 1, dd);
      return Number.isFinite(dt.getTime()) ? dt : null;
    }
    const parsed = new Date(raw);
    return Number.isFinite(parsed.getTime()) ? dateOnly(parsed) : null;
  } catch { return null; }
};
const dateKey = (value, fallback = "") => {
  const d = parseDateValue(value);
  return d ? d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()) : fallback;
};
const addDateDays = (base, n) => {
  const d = parseDateValue(base) || parseDateValue(today()) || new Date();
  const amount = Number(n);
  d.setDate(d.getDate() + (Number.isFinite(amount) ? amount : 0));
  return dateKey(d, today());
};
const daysBetween = (later, earlier) => {
  const a = parseDateValue(later), b = parseDateValue(earlier);
  if (!a || !b) return 1;
  return Math.max(1, Math.round((a.getTime() - b.getTime()) / 86400000));
};
const fmt = (d) => {
  if (!d) return "—";
  const dt = parseDateValue(d);
  if (!dt) return typeof d === "string" ? d : "—";
  try { return dt.toLocaleDateString("ar", { month: "short", day: "numeric" }); }
  catch { return dateKey(dt, typeof d === "string" ? d : "—"); }
};
const daysUntil = (d) => {
  if (!d) return Number.NaN;
  const target = parseDateValue(d), base = parseDateValue(today());
  if (!target || !base) return Number.NaN;
  return Math.round((target.getTime() - base.getTime()) / 86400000);
};
const money = (n) => (Math.round(Number(n || 0) * 100) / 100).toLocaleString("ar") + " ر.س";

/* دورة الحالات الكاملة (وثيقة التنفيذ) */
const WO_FLOW = ["مسودة", "مُصدر", "جاهز", "قيد التنفيذ", "بانتظار المراجعة", "مغلق"];
const WO_EXTRA = ["معلق", "بانتظار مواد", "بانتظار اعتماد", "مُعاد للتصحيح", "ملغي", "متأخر", "استثناء"];
const WO_COLORS = { "مسودة": C.steel, "مُصدر": C.blue, "جاهز": C.purple, "قيد التنفيذ": C.amber,
  "بانتظار المراجعة": C.blue, "مغلق": C.ink, "معلق": C.steel, "بانتظار مواد": C.amber,
  "مُعاد للتصحيح": C.red, "ملغي": C.red, "بانتظار اعتماد": C.amber, "متأخر": C.red, "استثناء": C.amber };
const ACTIVE_STATES = ["مسودة", "مُصدر", "جاهز", "قيد التنفيذ", "بانتظار المراجعة", "معلق", "بانتظار مواد", "بانتظار اعتماد", "مُعاد للتصحيح", "متأخر", "استثناء"];
const REQ_FLOW = { "مفتوح": ["قبول", "رفض"], "مقبول": ["تحويل لأمر عمل", "رفض"] };
const ROLES = ["مدير", "مشرف", "فني", "مخزن", "طالب خدمة", "مدير المصنع", "مسؤول النظام"];
const SAFETY_DEFAULTS = ["عزل مصدر الطاقة (LOTO)", "تأمين منطقة العمل", "ارتداء معدات الوقاية الشخصية"];
const FAILURE_MODES = ["انحشار", "اهتزاز", "تسريب", "كسر", "حرارة زائدة", "خلل كهربائي", "أخرى"];
const DOC_TYPES = ["دليل تشغيل", "كتالوج قطع غيار", "مخطط كهربائي", "مخطط ميكانيكي", "مرجع PLC/IO", "نموذج فحص", "مستند ضمان", "مستند مورد"];

const MAINTENANCE_ENTITY_KEYS = [
  "workRequestAttachments", "standardOperationSteps",
  "workDefinitionOperations", "workDefinitionSteps", "workDefinitionMaterials", "workDefinitionResources", "workDefinitionVersions",
  "maintenanceProgramAssets", "maintenanceProgramGroups", "maintenanceForecasts",
  "workOrderSteps", "workOrderResources", "workOrderAssignments", "workOrderStatusHistory", "workOrderAttachments", "workOrderPhotos", "workOrderFailures", "workOrderExceptions", "workOrderCosts", "workOrderApprovals",
  "dispatchListViews", "technicianTasks", "workOrderExecutionSessions", "workOrderOperationTransactions", "workOrderLaborTransactions", "workOrderMaterialUsage", "workOrderMaterialReturns", "workOrderFailureRecords", "workOrderInspectionResults", "workOrderSafetyChecklists", "workOrderChecklistAnswers", "workOrderCompletionRequests", "workOrderSupervisorReviews", "workOrderExecutionHistory",
  "supervisionSavedSearches", "supervisionScheduleSnapshots", "workOrderScheduleConflicts",
  "supervisionAssignmentPlans", "resourceCapacitySnapshots", "resourceScheduleConflicts",
  "maintenanceForecastRuns", "maintenanceForecastActions", "maintenanceReportJobs", "reportJobs", "savedReportOutputs",
  "forecastRuns", "forecastValidationIssues", "forecastSuppressionRules", "forecastMergeGroups",
  "reportJobs", "savedReportOutputs", "reportSchedules", "inventoryReservations", "materialIssueRequests", "materialReturnRequests", "laborCostTransactions"
];
const MAINTENANCE_PERMISSIONS = [
  "View_WorkRequests", "Create_WorkRequests", "Convert_WorkRequest_To_WorkOrder",
  "View_WorkOrders", "Create_WorkOrders", "Edit_WorkOrders", "Release_WorkOrders", "Hold_WorkOrders", "Cancel_WorkOrders", "Close_WorkOrders",
  "Assign_WorkOrders", "View_Technician_Tasks", "Execute_WorkOrders", "Complete_WorkOrders",
  "Approve_WorkOrder_Completion", "Reject_WorkOrder_Completion",
  "Manage_StandardOperations", "Manage_WorkDefinitions", "Manage_MaintenancePrograms", "Generate_MaintenanceForecast", "Generate_PM_WorkOrders",
  "Record_Failure", "Record_Labor", "Record_Material_Usage", "View_WorkOrder_Cost"
];
const MAINTENANCE_REPORTS = [
  "Open Work Orders Report", "Past Due Work Orders Report", "Completed Work Orders Report", "Preventive Maintenance Compliance", "Corrective Maintenance Report", "Emergency Work Orders Report", "Work Order Cost Report", "Technician Performance Report", "Failure Analysis Report", "Asset Maintenance History", "Maintenance Forecast Report", "Material Usage by Work Order", "Repeated Failures Report", "MTBF Report", "MTTR Report",
  "Daily Maintenance Execution Report", "Technician Workload Report", "Work Completion Report", "Rejected Work Report", "Material Usage During Execution", "Labor Hours Report", "Failure Capture Report", "Before / After Photo Report", "Supervisor Review Report"
];
const MAINTENANCE_RULES = [
  "No Work Order without Asset", "No PM Work Order without Maintenance Program or Work Definition", "No Work Order release without material availability check", "No work order without technicians assign", "No technician completion without checklist", "No final close without supervisor approval", "No material cost without material transaction", "No labor cost without labor transaction", "No failure analysis without asset", "No status change without audit log", "No technician can see unassigned work unless permitted", "No start without safety checklist if required", "No completion without finishing all required operations", "No material usage without issued or approved material", "No corrective work completion without failure data", "No photo-required work completion without photos", "Every execution action must create audit history"
];
const EXECUTION_PHOTO_TYPES = ["قبل", "أثناء", "بعد", "عطل", "قطعة غيار"];

/* حوكمة 100% — Operating Model / Controls / Evidence */
const GOVERNANCE100_ENTITY_KEYS = [
  "governanceFrameworks", "governanceControlLibrary", "governanceControlTests", "governanceEvidenceRegister",
  "governanceAuthorityLimits", "governanceSoDRules", "governanceRaciMatrix", "governanceDataOwners",
  "governanceKpiDefinitions", "governanceSlaRules", "governanceExceptionRegister", "governanceCapaActions",
  "governanceBackupPolicies", "governanceRetentionRules", "governanceSecurityReviews", "governanceAccessCertifications",
  "governanceReleaseGates", "governanceReadinessChecklist", "governanceERecords", "governanceEscalationRules",
  "governanceChangeImpactAssessments", "governanceTrainingRecords", "governanceIncidentReviews", "governancePolicyAcknowledgements"
];
const GOVERNANCE100_DOMAINS = [
  "Operating Model", "Access & RBAC", "Segregation of Duties", "Approvals", "Audit & Evidence", "Data Quality", "Work Control",
  "Inventory Control", "Safety & Execution", "Forecast & Scheduling", "Financial Control", "Reporting", "Backup & Continuity", "Retention", "Change Control"
];


/* مجموعات أصول المطاحن القياسية (وثيقة الأصول) */
const STANDARD_GROUPS = [
  ["ELV", "مصاعد القواديس (Bucket Elevators)"], ["CCV", "النواقل السلسلية (Chain Conveyors)"],
  ["SCV", "النواقل الحلزونية (Screw Conveyors)"], ["SFN", "مراوح الصوامع (Silo Fans)"],
  ["SGT", "بوابات الصوامع (Silo Gates)"], ["SNS", "الحساسات (Sensors)"],
  ["RML", "الطواحين الدلفينية (Rollermills)"], ["PLS", "المناخل المستوية (Plansifters)"],
  ["PRF", "المنقيات (Purifiers)"], ["CMP", "الضواغط (Compressors)"],
  ["PCK", "ماكينات التعبئة (Packing Machines)"], ["SCL", "الموازين (Scales)"],
];

const EMPTY = {
  /* فصل 1-2: منظمة الصيانة */
  maintenanceOrganizations:[], plantParameters:[], workAreas:[], workCenters:[], resources:[], workCenterResources:[],
  resourceInstances:[], shifts:[], resourceExceptions:[], infolets:[], importBatches:[],
  governancePolicies:[], approvalMatrix:[], governanceApprovalRequests:[], governanceDataQualityRules:[], governanceRisks:[], governanceChangeRequests:[], governanceReviews:[], governanceAuditEvents:[],
  governanceFrameworks:[], governanceControlLibrary:[], governanceControlTests:[], governanceEvidenceRegister:[], governanceAuthorityLimits:[], governanceSoDRules:[], governanceRaciMatrix:[], governanceDataOwners:[], governanceKpiDefinitions:[], governanceSlaRules:[], governanceExceptionRegister:[], governanceCapaActions:[], governanceBackupPolicies:[], governanceRetentionRules:[], governanceSecurityReviews:[], governanceAccessCertifications:[], governanceReleaseGates:[], governanceReadinessChecklist:[], governanceERecords:[], governanceEscalationRules:[], governanceChangeImpactAssessments:[], governanceTrainingRecords:[], governanceIncidentReviews:[], governancePolicyAcknowledgements:[],
  technicians:[], assets:[], assetGroups:[],
  /* فصل 3: الأصول — كيانات مساندة إضافةً إلى الحقول داخل الأصل */
  assetParts:[], assetRelationships:[], assetLogicalHierarchyNodes:[], assetFlexfields:[], assetImportBatches:[],
  assetFixedAssetLinks:[], assetServiceMappings:[], assetIotSyncEvents:[], assetMaterialComponentTransactions:[],
  meterTemplates:[], assetMeters:[], readings:[], warranties:[],
  stdOps:[], workDefs:[], workRequests:[], programs:[], workOrders:[],
  workRequestAttachments:[], standardOperationSteps:[],
  workDefinitionOperations:[], workDefinitionSteps:[], workDefinitionMaterials:[], workDefinitionResources:[], workDefinitionVersions:[],
  maintenanceProgramAssets:[], maintenanceProgramGroups:[], maintenanceForecasts:[],
  workOrderSteps:[], workOrderResources:[], workOrderAssignments:[], workOrderStatusHistory:[], workOrderAttachments:[], workOrderPhotos:[], workOrderFailures:[], workOrderExceptions:[], workOrderCosts:[], workOrderApprovals:[],
  dispatchListViews:[], technicianTasks:[], workOrderExecutionSessions:[], workOrderOperationTransactions:[], workOrderLaborTransactions:[], workOrderMaterialUsage:[], workOrderMaterialReturns:[], workOrderFailureRecords:[], workOrderInspectionResults:[], workOrderSafetyChecklists:[], workOrderChecklistAnswers:[], workOrderCompletionRequests:[], workOrderSupervisorReviews:[], workOrderExecutionHistory:[],
  supervisionSavedSearches:[], supervisionScheduleSnapshots:[], workOrderScheduleConflicts:[], supervisionAssignmentPlans:[], resourceCapacitySnapshots:[], resourceScheduleConflicts:[], maintenanceForecastRuns:[], maintenanceForecastActions:[], maintenanceReportJobs:[], forecastRuns:[], forecastValidationIssues:[], forecastSuppressionRules:[], forecastMergeGroups:[], reportJobs:[], savedReportOutputs:[], reportSchedules:[], inventoryReservations:[], materialIssueRequests:[], materialReturnRequests:[], laborCostTransactions:[],
  items:[], warehouses:[], stockTx:[],
  warrantyProviders:[], laborRates:[], repairTimes:[], coverages:[], contracts:[], entitlements:[], claims:[],
  assetGroupRules:[], logicalHierarchies:[],
  settings:{ role:"مدير", myTechId:"", assetCreationMode:"IMMEDIATE", strictAssetValidation:false } };

/* ثوابت فصل 1-2: منظمة الصيانة */
const MAINT_ORG_STATUS = ["مسودة", "جاهزة", "عاملة", "معطلة"];
const RESOURCE_TYPES = ["عمالة", "معدات"];
const RESOURCE_UOMS = ["ساعة", "يوم", "أمر", "قطعة", "دقيقة"];
const SHIFT_TYPES = ["صباحي", "مسائي", "ليلي", "24 ساعة", "مخصص"];
const EXCEPTION_TYPES = ["توقف", "إتاحة إضافية", "تغيير وردية", "صيانة داخلية", "عطلة"];
const INFOLET_NAMES = ["أوامر مفتوحة", "متأخر", "بانتظار مواد", "صيانة وقائية مستحقة", "أصول حرجة", "مطالبات ضمان"];

/* ثوابت فصل 3: الأصول */
const ASSET_OWNERSHIP = ["مؤسسة", "عميل"];
const LOCATION_TYPES = ["CUSTOMER_ADDRESS", "EXTERNAL_ADDRESS", "INTERNAL_ADDRESS", "WORK_CENTER", "UNKNOWN", "INVENTORY"];
const DEFAULT_WO_SUBTYPES = ["", "Emergency", "Planned", "Reactive", "Safety", "Under warranty", "Condition based"];
const ASSET_CREATION_MODES = ["IMMEDIATE", "DEFERRED"];
const AUTO_ASSET_SOURCES = ["Miscellaneous Receipt", "Purchase Receipt to Inventory", "Manufacturing Work Order Completion", "Purchase Receipt to Work Order Destination", "Purchase Receipt to Expense Destination", "Sales Order Fulfillment"];
const ORACLE_FEATURES = [
  ["منظمة صيانة + Plant Parameters", "فصل 1-2", "org"],
  ["Work Areas / Work Centers", "فصل 2", "org"],
  ["Resources + Resource Instances", "فصل 2", "org"],
  ["Shifts + Resource Calendar Exceptions", "فصل 2", "org"],
  ["Infolets / Task Navigator", "فصل 1", "oracle"],
  ["Assets Enterprise/Customer + Item + Location Type", "فصل 3", "assets"],
  ["Manage Assets + Smart Search + Chips", "فصل 3", "assets"],
  ["Asset 360", "فصل 3", "assets"],
  ["Parts / Meters / Hierarchy / Groups", "فصل 3", "assets"],
  ["Split Asset لغير المسلسل", "فصل 3", "assets"],
  ["Flexfields / Fixed Assets / Service Mapping / IoT Sync", "فصل 3", "assets"],
  ["Asset Import/Export", "فصل 3", "data"],
];

/* ثوابت الحوكمة والرقابة */
const GOV_POLICY_TYPES = ["سياسة", "إجراء", "مصفوفة صلاحيات", "تعليمات تشغيل", "ضابط رقابي"];
const GOV_POLICY_STATUS = ["مسودة", "سارية", "قيد المراجعة", "مؤرشفة"];
const GOV_PROCESSES = ["أمر عمل", "أصل", "مخزون", "عداد", "برنامج وقائي", "ضمان", "صلاحيات", "بيانات", "Backend"];
const GOV_ACTIONS = ["إنشاء", "تعديل", "إصدار", "إغلاق", "حذف", "صرف", "تسوية", "استيراد", "تغيير صلاحية", "تغيير إعداد"];
const GOV_RISK_LEVELS = ["منخفض", "متوسط", "عال", "حرج"];
const GOV_RISK_STATUS = ["مفتوح", "قيد المعالجة", "مقبول", "مغلق"];
const GOV_CHANGE_STATUS = ["مقترح", "قيد المراجعة", "معتمد", "مرفوض", "منفذ", "مغلق"];
const GOV_REVIEW_FREQ = ["شهري", "ربع سنوي", "نصف سنوي", "سنوي"];
const GOV_REQUEST_STATUS = ["مفتوح", "معتمد", "مرفوض", "ملغي", "منفذ"];
const GOV_DATA_SEVERITY = ["منخفض", "متوسط", "عال", "حرج"];

/* ثوابت قواعد مجموعات الأصول (ف4) */
const GROUP_ATTRS = [["location", "الموقع"], ["type", "النوع"], ["workCenterId", "مركز العمل"]];
const RULE_USAGES = ["عام (صيانة وبرامج)", "حالة الأصل (قاعدة تحقق)"];
const END_REASONS = ["إلغاء يدوي", "تغير بيانات الأصل", "إنهاء الأصل"];

/* ثوابت ضمان المورد (ف6) */
const COV_STATUS = ["مسودة", "جاهز"];
const COV_TYPES = ["شراء جديد", "ضمان ممتد", "ضمان OEM"];
const DUR_UOM = { "يوم": 1, "شهر": 30, "سنة": 365 };
const CLAIM_STATUS = ["قيد المراجعة", "مُقدمة", "محلولة", "مرفوضة"];
const ENT_TYPES = ["صرف مادة", "إرجاع مادة", "تحميل مورد", "تحميل معدات", "إصلاح قياسي", "أخرى"];

/* ثوابت العمليات القياسية (ف7) */
const OP_BASIS = ["ثابت", "متغير"];
const OP_CHARGE = ["يدوي", "تلقائي"];
const OP_ACTIVITY = ["تجهيز", "تنفيذ", "إنهاء"];
const REPAIR_REASONS = ["عطل", "صيانة وقائية", "ضمان", "فحص دوري", "تحسين"];
const WORK_DONE = ["تنظيف", "إصلاح", "استبدال", "ضبط", "تشحيم", "فحص"];
const ATTACH_TYPES = ["رابط", "نص"];

/* أنواع حركات المخزون (وثيقة المخزون §Stock Transactions) */
const TX_TYPES = ["استلام", "صرف لأمر عمل", "إرجاع من أمر عمل", "تحويل", "تسوية", "إتلاف"];
const ITEM_CATS = ["محامل", "سيور", "قواديس", "زيوت وشحوم", "فلاتر", "كهرباء", "حساسات", "أخرى"];

/* ترحيل حالات النسخة السابقة */
const MIGRATE_STATUS = { "غير مُصدر": "مسودة", "مُصدر": "جاهز", "قيد التنفيذ": "قيد التنفيذ", "مكتمل": "مغلق", "مغلق": "مغلق", "ملغي": "ملغي" };

/* ضغط الصور قبل الحفظ (حد التخزين 5MB) */
const resizeImage = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const max = 480, scale = Math.min(1, max / Math.max(img.width, img.height));
      const cv = document.createElement("canvas");
      cv.width = img.width * scale; cv.height = img.height * scale;
      cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
      resolve(cv.toDataURL("image/jpeg", 0.5));
    };
    img.onerror = reject;
    img.src = reader.result;
  };
  reader.onerror = reject;
  reader.readAsDataURL(file);
});

/* ───────────────────────── ربط البيانات بالـ Backend ───────────────────────── */
const normalizeDb = (raw = {}) => {
  const d = { ...(raw || {}) };

  d.workOrders = (d.workOrders || []).map((w) => ({
    checklist: [], materials: [], photos: [], execLog: [], failure: null,
    resources: [], assignments: [], statusHistory: [], approvals: [], completionRequests: [], supervisorReviews: [],
    executionNotes: "", inspectionResults: [], externalSupplier: "", workCenterId: "", safetyPermit: "", pauseLog: [],
    _cmmsAssignedTechIds: [],
    ...w, status: MIGRATE_STATUS[w.status] || w.status,
  }));
  d.assets = (d.assets || []).map((a) => ({ parts: [], docs: [], photos: [], specs: "",
    allowWO: true, allowPrograms: true, enableIoT: false, endDate: "", quantity: 1,
    ownership: "مؤسسة", assetType: a.assetType || (a.ownership === "عميل" ? "CUSTOMER" : "ENTERPRISE"),
    itemRequired: a.itemRequired ?? false, itemId: "", itemName: "", fullLifecycleTracked: false, customerAssetTracking: false,
    operatingOrganizationId: "", serial: "", lotNumber: "", uom: "", secondaryQuantity: "",
    useBomForInitialHierarchy: false, competitorAsset: false, locationType: a.locationType || "UNKNOWN", locationId: "", locationOrganizationId: "",
    customer: "", customerId: "", customerAccountId: "", shipmentDate: "", installedDate: "", inServiceDate: "",
    contact: "", defaultWOType: "", defaultWOSubtype: "", project: "", task: "", countryOfOrigin: "",
    flexfields: [], fixedAssetNumber: "", fixedAssetBook: "", lastSalesOrderDetails: "", serviceRequests: [],
    notes: [], history: [], ...a }));
  d.stdOps = (d.stdOps || []).map((o) => ({ type: "داخلية", countPoint: true, autoTransact: false,
    resources: [], attachments: [], inactiveOn: "", repairReason: "", repairTx: "", workDone: "", ...o }));
  d.meterTemplates = (d.meterTemplates || []).map((t) => ({ code: t.code || (t.name || "MTR"), description: "",
    startDate: "", endDate: "", initial: t.initial ?? "", recordAtWO: "لا يسمح", resetAllowed: true, resetValue: 0,
    rolloverAllowed: false, rolloverMax: "", rolloverMin: 0, allowSchedule: true, estDailyRate: "", readingsForRate: "", ...t }));
  d.assetMeters = (d.assetMeters || []).map((m) => ({ recordAtWO: "", endDate: "", estDailyRate: "", readingsForRate: "", ...m }));
  d.readings = (d.readings || []).map((r) => ({ status: r.isReset ? "تصفير" : "مسجلة", comments: "", rollover: false, ...r }));

  d.maintenanceOrganizations = (d.maintenanceOrganizations || []).map((o) => ({ code:"", name:"", status:"مسودة", isMaintenanceEnabled:true, isProjectTracked:false, inactiveOn:"", ...o }));
  d.plantParameters = (d.plantParameters || []).map((p) => ({ organizationId:"", assetCreationMode:"IMMEDIATE", autoAssetPrefix:"AST", requireItemForEnterpriseAssets:false, requireFullLifecycleForWO:false, defaultUnknownLocation:true, projectTrackingEnabled:false, inventoryIssuePolicy:"لا صرف بدون أمر عمل", ...p }));
  d.workAreas = (d.workAreas || []).map((x) => ({ organizationId:"", inactiveOn:"", ...x }));
  d.workCenters = (d.workCenters || []).map((x) => ({ organizationId:"", workAreaId:"", inactiveOn:"", ...x }));
  d.resources = (d.resources || []).map((x) => ({ code:"", type:"عمالة", usageUom:"ساعة", workCenterId:"", qty:1, available24h:false, inactiveOn:"", ...x }));
  d.resourceInstances = (d.resourceInstances || []).map((x) => ({ resourceId:"", identifier:"", instanceType:"يدوي", personName:"", assetId:"", active:true, qualifications:"", inactiveOn:"", ...x }));
  d.shifts = (d.shifts || []).map((x) => ({ name:"", code:"", shiftType:"صباحي", startTime:"08:00", endTime:"17:00", days:"الأحد,الاثنين,الثلاثاء,الأربعاء,الخميس", inactiveOn:"", ...x }));
  d.resourceExceptions = (d.resourceExceptions || []).map((x) => ({ workCenterId:"", resourceId:"", date:today(), exceptionType:"توقف", startTime:"", endTime:"", reason:"", ...x }));
  d.workCenterResources = d.workCenterResources || [];
  d.infolets = d.infolets || INFOLET_NAMES.map((name, i) => ({ id: uid(), name, visible:true, order:i+1 }));
  d.importBatches = d.importBatches || [];
  d.assetFlexfields = d.assetFlexfields || [];
  d.assetImportBatches = d.assetImportBatches || [];
  d.assetFixedAssetLinks = d.assetFixedAssetLinks || [];
  d.assetServiceMappings = d.assetServiceMappings || [];
  d.assetIotSyncEvents = d.assetIotSyncEvents || [];
  d.assetMaterialComponentTransactions = d.assetMaterialComponentTransactions || [];

  /* ف4: ترقية المجموعات القديمة إلى قاعدة قياسية + تعيينات بتواريخ */
  d.assetGroupRules = d.assetGroupRules || [];
  if ((d.assetGroups || []).some((g) => !g.ruleId)) {
    let std = d.assetGroupRules.find((r) => r.code === "STD");
    if (!std) { std = { id: uid(), name: "التصنيف القياسي", code: "STD", description: "قاعدة افتراضية للمجموعات السابقة", attributes: [], usages: ["عام (صيانة وبرامج)"], enforceUnique: false, inactiveOn: "" }; d.assetGroupRules.push(std); }
    d.assetGroups = (d.assetGroups || []).map((g, i) => g.ruleId ? g : ({
      number: "AG-" + String(100 + i + 1), description: "", attrValues: {}, excludeFromRequests: false, excludeFromWO: false, inactiveOn: "",
      assignments: (g.assetIds || []).map((aid) => ({ id: uid(), assetId: aid, start: today(), end: "", endReason: "", by: "ترحيل" })),
      ...g, ruleId: std.id }));
  }

  MAINTENANCE_ENTITY_KEYS.forEach((k) => { d[k] = Array.isArray(d[k]) ? d[k] : []; });
  GOVERNANCE100_ENTITY_KEYS.forEach((k) => { d[k] = Array.isArray(d[k]) ? d[k] : []; });
  d.governanceControlLibrary = (d.governanceControlLibrary || []).map((x) => ({ status:"نشط", criticality:"متوسط", automation:"يدوي", frequency:"شهري", ...x }));
  d.governanceControlTests = (d.governanceControlTests || []).map((x) => ({ result:"لم يفحص", severity:"متوسط", status:"مفتوح", ...x }));
  d.governanceCapaActions = (d.governanceCapaActions || []).map((x) => ({ status:"مفتوح", priority:"متوسط", dueDate:"", ...x }));
  d.governanceReadinessChecklist = (d.governanceReadinessChecklist || []).map((x) => ({ status:"غير مكتمل", ownerRole:"مدير", evidence:"", ...x }));
  d.governanceReleaseGates = (d.governanceReleaseGates || []).map((x) => ({ status:"مفتوح", required:true, approvedBy:"", approvedAt:"", ...x }));
  d.workOrderStatusHistory = (d.workOrderStatusHistory || []).map((x) => ({ at: today(), from: "", to: "", by: "", ...x }));
  d.workOrderExecutionHistory = (d.workOrderExecutionHistory || []).map((x) => ({ at: today(), action: "", by: "", ...x }));
  d.supervisionSavedSearches = (d.supervisionSavedSearches || []).map((x) => ({ name:"", filter:"الكل", query:"", ownerRole:"", createdAt:"", ...x }));
  d.supervisionScheduleSnapshots = (d.supervisionScheduleSnapshots || []).map((x) => ({ at:today(), horizonDays:7, total:0, conflicts:0, createdBy:"", ...x }));
  d.workOrderScheduleConflicts = (d.workOrderScheduleConflicts || []).map((x) => ({ severity:"تحذير", type:"تعارض فني", status:"مفتوح", ...x }));
  d.maintenanceForecasts = (d.maintenanceForecasts || []).map((x) => ({ status:"Planned", suppressed:false, mergedIntoForecastId:"", generatedWorkOrderId:"", validationStatus:"غير مفحوص", ...x }));
  d.maintenanceForecastRuns = (d.maintenanceForecastRuns || []).map((x) => ({ runType:"Generate", at:today(), horizonDays:0, created:0, warnings:0, ...x }));
  d.supervisionAssignmentPlans = d.supervisionAssignmentPlans || [];
  d.resourceCapacitySnapshots = d.resourceCapacitySnapshots || [];
  d.resourceScheduleConflicts = d.resourceScheduleConflicts || [];
  d.forecastRuns = d.forecastRuns || [];
  d.forecastValidationIssues = d.forecastValidationIssues || [];
  d.forecastSuppressionRules = d.forecastSuppressionRules || [];
  d.forecastMergeGroups = d.forecastMergeGroups || [];
  d.reportJobs = d.reportJobs || [];
  d.savedReportOutputs = d.savedReportOutputs || [];
  d.reportSchedules = d.reportSchedules || [];
  d.inventoryReservations = d.inventoryReservations || [];
  d.materialIssueRequests = d.materialIssueRequests || [];
  d.materialReturnRequests = d.materialReturnRequests || [];
  d.laborCostTransactions = d.laborCostTransactions || [];
  d.maintenanceForecastActions = (d.maintenanceForecastActions || []).map((x) => ({ at:today(), action:"", forecastId:"", by:"", ...x }));
  d.maintenanceReportJobs = (d.maintenanceReportJobs || []).map((x) => ({ reportName:"", status:"مسودة", createdAt:today(), ...x }));
  d.reportJobs = (d.reportJobs || []).map((x) => ({ name:"", status:"مسودة", requestedAt:"", rowCount:0, ...x }));
  d.savedReportOutputs = (d.savedReportOutputs || []).map((x) => ({ name:"", generatedAt:"", rowCount:0, summary:"", ...x }));

  return { ...EMPTY, ...d, settings: { ...EMPTY.settings, ...(d.settings || {}) } };
};

const loadLocalBackup = () => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return null;
    const value = window.localStorage.getItem(KEY);
    return value ? JSON.parse(value) : null;
  } catch (e) {
    console.error("فشل قراءة النسخة المحلية", e);
    return null;
  }
};

const saveLocalBackup = (data) => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return false;
    window.localStorage.setItem(KEY, JSON.stringify(data));
    return true;
  } catch (e) {
    console.error("فشل حفظ النسخة المحلية", e);
    return false;
  }
};

/* ───────────────────────── التطبيق ───────────────────────── */
export default function CMMS() {
  const [db, setDb] = useState(EMPTY);
  const [loaded, setLoaded] = useState(false);
  const [syncStatus, setSyncStatus] = useState("جارٍ التحميل…");
  const [tab, setTab] = useState("home");
  const [woDetail, setWoDetail] = useState(null);
  const [assetDetail, setAssetDetail] = useState(null);
  const [firebaseServices] = useState<CmmsFirebaseServices | null>(() => getFirebaseServices());
  const firebaseEnabled = !!firebaseServices;
  const [firebaseUser, setFirebaseUser] = useState<any>(null);
  const [firebaseProfile, setFirebaseProfile] = useState<any>(null);
  const [authReady, setAuthReady] = useState(!firebaseEnabled);

  const role = firebaseEnabled ? (normalizeFirebaseRole(firebaseProfile?.role) || "طالب خدمة") : db.settings.role;
  const myTechId = firebaseEnabled ? (firebaseProfile?.technicianId || "") : db.settings.myTechId;
  const can = {
    manage: role === "مدير" || role === "مشرف" || role === "مسؤول النظام",
    execute: role === "فني" || role === "مدير" || role === "مشرف" || role === "مسؤول النظام",
    review: role === "مدير" || role === "مشرف" || role === "مسؤول النظام" || role === "مدير المصنع",
    warehouse: role === "مخزن" || role === "مدير" || role === "مشرف" || role === "مسؤول النظام",
    requestOnly: role === "طالب خدمة",
    admin: role === "مدير" || role === "مسؤول النظام",
  };

  useEffect(() => {
    if (!firebaseServices) return;
    setAuthReady(false);
    return subscribeFirebaseAuth(firebaseServices, async (user) => {
      setFirebaseUser(user);
      if (!user) {
        setFirebaseProfile(null);
        setAuthReady(true);
        setLoaded(true);
        setSyncStatus("سجّل الدخول إلى Firebase");
        return;
      }
      try {
        setSyncStatus("جارٍ قراءة صلاحيات Firebase…");
        const profile = await ensureFirebaseUserProfile(firebaseServices, user);
        setFirebaseProfile(profile);
        setSyncStatus("تم تسجيل الدخول — " + (profile.role || "بدون دور"));
      } catch (e) {
        console.error("فشل قراءة صلاحيات Firebase", e);
        setFirebaseProfile({ role: user.email?.toLowerCase() === FIREBASE_OWNER_EMAIL ? "مدير" : "طالب خدمة", email: user.email || "" });
        setSyncStatus("تعذر قراءة ملف المستخدم — تم استخدام دور احتياطي");
      }
      setAuthReady(true);
    });
  }, [firebaseServices]);

  useEffect(() => {
    if (firebaseServices) {
      if (!authReady) return;
      if (!firebaseUser) return;
      (async () => {
        const startedAt = typeof performance !== "undefined" ? performance.now() : Date.now();
        const local = loadLocalBackup();
        if (local) {
          setDb(normalizeDb(local));
          setLoaded(true);
          setSyncStatus("تم فتح النسخة المحلية — جارٍ مزامنة Firestore بالخلفية…");
        } else {
          setLoaded(false);
          setSyncStatus("جارٍ تحميل بيانات CMMS من Firestore…");
        }

        try {
          const d = await loadCmmsStateFromFirestore(firebaseServices);
          if (d) {
            const normalized = normalizeDb(d);
            setDb(normalized);
            saveLocalBackup(normalized);
          } else if (!local) {
            const emptyState = normalizeDb({ settings: { ...EMPTY.settings, role, myTechId } });
            setDb(emptyState);
            saveLocalBackup(emptyState);
          }
          const elapsed = Math.max(0.1, (((typeof performance !== "undefined" ? performance.now() : Date.now()) - startedAt) / 1000));
          setSyncStatus("متصل بـ Firebase Firestore — مزامنة " + elapsed.toFixed(1) + "ث");
        } catch (e) {
          console.error("فشل تحميل بيانات Firestore", e);
          if (local) {
            setSyncStatus("تم فتح النسخة المحلية — Firestore غير متاح أو القواعد تمنع القراءة");
          } else {
            setSyncStatus("لا توجد بيانات — تحقق من Firebase Auth و Firestore Rules");
          }
        }
        setLoaded(true);
      })();
      return;
    }

    (async () => {
      try {
        setSyncStatus("Firebase غير مفعّل — جارٍ تجربة الخادم القديم…");
        const res = await fetch(`${API}/state`, { cache: "no-store" });
        if (!res.ok) throw new Error("فشل تحميل البيانات من الخادم");
        const d = await res.json();
        if (d) setDb(normalizeDb(d));
        setSyncStatus("متصل بالخادم القديم — فعّل Firebase للحوكمة الخلفية");
      } catch (e) {
        console.error("فشل تحميل بيانات الخادم", e);
        const local = loadLocalBackup();
        if (local) {
          setDb(normalizeDb(local));
          setSyncStatus("وضع محلي مؤقت — Firebase غير مفعّل");
        } else {
          setSyncStatus("بيانات محلية فارغة — افتح المزيد ← Firebase والصلاحيات للربط");
        }
      }
      setLoaded(true);
    })();
  }, [firebaseServices, authReady, firebaseUser?.uid]);

  const save = async (next) => {
    const nextWithAuth = firebaseEnabled ? { ...next, settings: { ...next.settings, role, myTechId } } : next;
    setDb(nextWithAuth);

    if (firebaseServices && firebaseUser) {
      try {
        const changed = await saveCmmsStateToFirestore(firebaseServices, db, nextWithAuth, {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          role,
        });
        saveLocalBackup(nextWithAuth);
        setSyncStatus(changed.length ? "تم الحفظ في Firestore كمستندات مستقلة — " + changed.join("، ") : "لا توجد تغييرات للحفظ");
      } catch (e) {
        console.error("فشل الحفظ في Firestore", e);
        if (saveLocalBackup(nextWithAuth)) {
          setSyncStatus("حفظ محلي مؤقت — Firestore رفض العملية أو غير متاح");
          alert("لم يسمح Firebase بحفظ هذه العملية. راجع الدور أو Firestore Rules. تم حفظ نسخة محلية مؤقتة فقط.");
        } else {
          setSyncStatus("فشل الحفظ — تحقق من Firebase وحجم الصور");
          alert("فشل الحفظ في Firebase ولم تنجح النسخة المحلية.");
        }
      }
      return;
    }

    try {
      const res = await fetch(`${API}/state`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nextWithAuth),
      });
      if (!res.ok) throw new Error(await res.text().catch(() => "فشل الحفظ في الخادم"));
      saveLocalBackup(nextWithAuth);
      setSyncStatus("تم الحفظ في الخادم القديم");
    } catch (e) {
      console.error("فشل الحفظ في الخادم", e);
      if (saveLocalBackup(nextWithAuth)) {
        setSyncStatus("حفظ محلي مؤقت — لا يوجد Firebase أو خادم متاح");
      } else {
        setSyncStatus("فشل الحفظ — تحقق من Firebase وحجم الصور");
        alert("فشل الحفظ ولم تنجح النسخة المحلية — قد تكون مساحة التخزين امتلأت بسبب الصور.");
      }
    }
  };
  const put = (entity, rows) => save({ ...db, [entity]: rows });
  const add = (entity, row) => { const r = { id: uid(), ...row }; put(entity, [...db[entity], r]); return r; };
  const update = (entity, id, patch) => put(entity, db[entity].map((r) => (r.id === id ? { ...r, ...patch } : r)));
  const remove = (entity, id) => put(entity, db[entity].filter((r) => r.id !== id));
  const setSetting = (k, v) => save({ ...db, settings: { ...db.settings, [k]: v } });
  const nameOf = (entity, id, key = "name") => db[entity].find((r) => r.id === id)?.[key] || "—";

  /* ───── محرك العدادات (ف5): Net Change / Displayed / Life-to-Date ───── */
  const meterReadings = (amId) => db.readings.filter((r) => r.assetMeterId === amId).sort((a, b) => (a.at < b.at ? -1 : 1));
  const activeReadings = (amId) => meterReadings(amId).filter((r) => !["معطلة", "ملغاة"].includes(r.status));
  const lastReading = (amId) => activeReadings(amId).slice(-1)[0] || null;
  /* حساب الصفوف: لكل قراءة فعالة net/displayed/ltd حسب نوع العداد والاتجاه مع التصفير والتدوير */
  const meterRows = (am) => {
    const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
    let prevDisp = Number(am.initial || 0), ltdv = 0, started = false;
    const out = [];
    for (const r of activeReadings(am.id)) {
      const v = Number(r.value);
      let net = 0, disp = v;
      if (tpl.meterType === "مقياس") { net = started ? v - prevDisp : 0; disp = v; ltdv = v; }
      else if (tpl.readingType === "تغير") {
        net = v; disp = prevDisp + (tpl.direction === "تنازلي" ? -v : v);
        ltdv += (tpl.direction === "تنازلي" ? -v : v);
      } else { /* مستمر مطلق */
        if (r.status === "تصفير" || r.isReset) { net = 0; disp = v; }
        else if (r.rollover) { net = (Number(tpl.rolloverMax || 0) - prevDisp) + (v - Number(tpl.rolloverMin || 0)); disp = v; }
        else { net = started ? v - prevDisp : (r.status === "أولية" ? 0 : v - prevDisp); disp = v; }
        if (tpl.direction === "تنازلي") ltdv = disp; /* التنازلي: العمر ≈ المعروض */
        else ltdv += Math.max(0, net);
      }
      out.push({ ...r, net, displayed: disp, ltd: ltdv });
      prevDisp = disp; started = true;
    }
    return out;
  };
  const ltd = (am) => { const rows = meterRows(am); return rows.length ? rows[rows.length - 1].ltd : 0; };
  const currentValue = (am) => { const rows = meterRows(am); return rows.length ? rows[rows.length - 1].displayed : Number(am.initial || 0); };
  /* معدل الاستخدام المحسوب من آخر N قراءات: (نهاية − بداية) ÷ الأيام (ف5 §15.1) */
  const calcUtilRate = (am) => {
    const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
    if (tpl.meterType === "مقياس") return null;
    const n = Number(am.readingsForRate || tpl.readingsForRate || 0);
    const rows = meterRows(am);
    if (n < 2 || rows.length < n) return null;
    const seg = rows.slice(-n);
    const days = daysBetween(seg[seg.length - 1].at, seg[0].at);
    return (seg[seg.length - 1].ltd - seg[0].ltd) / days;
  };
  /* الأولوية: المعدل المحسوب ← المقدّر على مستوى الأصل ← المقدّر بالقالب ← متوسط التاريخ كله */
  const utilRate = (am) => {
    const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
    const calc = calcUtilRate(am);
    if (calc != null && calc > 0) return calc;
    if (Number(am.estDailyRate)) return Number(am.estDailyRate);
    if (Number(tpl.estDailyRate)) return Number(tpl.estDailyRate);
    const rows = meterRows(am);
    if (!rows.length) return 0;
    const span = daysBetween(today(), rows[0].at);
    return rows[rows.length - 1].ltd / span;
  };
  const addReading = (am, value, at, opts = {}) => {
    const tpl = db.meterTemplates.find((t) => t.id === am.templateId);
    const v = Number(value);
    const rows = activeReadings(am.id);
    const last = rows.slice(-1)[0] || null;
    if (am.endDate && at > am.endDate) return "العداد معطل (نهاية " + am.endDate + ") — لا قراءات بعد هذا التاريخ";
    if (rows.some((r) => r.at === at)) return "توجد قراءة فعالة بنفس التاريخ";
    if (!opts.historical && last && at < last.at) return "تاريخ القراءة يجب أن يكون بعد آخر قراءة (" + last.at + ") — أو فعّل «قراءة تاريخية»";
    if ((opts.historical || opts.source === "REST" || opts.source === "استيراد") && opts.source && opts.source !== "يدوي" && opts.historical)
      return "القراءة التاريخية من شاشة الإدخال فقط (قاعدة ف5)";
    /* الجار السابق حسب التاريخ (للتاريخية) */
    const prevRow = meterRows(am).filter((r) => r.at < at).slice(-1)[0] || null;
    const prevDisp = prevRow ? prevRow.displayed : Number(am.initial || 0);
    if (opts.rollover) {
      if (!(tpl.rolloverAllowed && tpl.meterType === "مستمر" && tpl.readingType === "مطلق" && tpl.direction === "تصاعدي"))
        return "التدوير متاح فقط للمستمر المطلق التصاعدي مع تفعيله بالقالب";
      if (tpl.rolloverMin !== "" && v < Number(tpl.rolloverMin)) return "بعد التدوير: القيمة ≥ " + tpl.rolloverMin;
      if (v >= prevDisp) return "التدوير يعني قيمة أقل من السابقة (" + prevDisp + ")";
    } else if (opts.isReset) {
      if (tpl.resetAllowed === false) return "التصفير غير مفعّل في هذا القالب";
    } else if (tpl.readingType === "مطلق" && tpl.meterType === "مستمر") {
      if (tpl.direction === "تصاعدي" && v < prevDisp) return "عداد تصاعدي: القيمة يجب أن تكون ≥ " + prevDisp + " (أو استخدم تدوير/تصفير)";
      if (tpl.direction === "تنازلي" && v > prevDisp) return "عداد تنازلي: القيمة يجب أن تكون ≤ " + prevDisp;
    }
    if (tpl.readingType === "تغير" || tpl.meterType === "مقياس") {
      if (tpl.readingType === "تغير" && tpl.direction !== "تنازلي" && v < 0) return "قراءة التغير يجب أن تكون ≥ 0";
      if (tpl.min !== "" && tpl.min != null && v < Number(tpl.min)) return "أقل من الحد الأدنى (" + tpl.min + ")";
      if (tpl.max !== "" && tpl.max != null && v > Number(tpl.max)) return "أعلى من الحد الأقصى (" + tpl.max + ")";
    }
    add("readings", { assetMeterId: am.id, value: v, at,
      source: opts.source || "يدوي", isReset: !!opts.isReset, rollover: !!opts.rollover,
      status: opts.isReset ? "تصفير" : opts.rollover ? "تدوير" : opts.status || "مسجلة",
      comments: opts.comments || "", workOrderId: opts.workOrderId || "" });
    return null;
  };
  /* تعطيل قراءة: تُستبعد من الحسابات (إعادة الحساب تلقائية لأن القيم تُشتق ديناميكيًا) */
  const disableReading = (am, r) => {
    const rows = activeReadings(am.id);
    const isLatest = rows.length && rows[rows.length - 1].id === r.id;
    if (r.status === "أولية") return "لا تُعطّل القراءة الأولية";
    if ((r.status === "تصفير" || r.status === "تدوير") && !isLatest) return "التصفير/التدوير يُعطّل فقط إذا كان آخر قراءة فعالة";
    update("readings", r.id, { status: "معطلة" });
    return null;
  };

  /* فحص PM بعد القراءة (وثيقة الأصول): تنبيهات الاستحقاق والاقتراب */
  const pmCheckAfterReading = (am, newValue) => {
    const alerts = [];
    db.programs.filter((p) => p.method === "فاصل عداد" && p.assetMeterId === am.id).forEach((p) => {
      const tpl = db.meterTemplates.find((t) => t.id === am.templateId);
      const delta = tpl?.readingType === "تغير" ? Number(newValue) : Math.abs(Number(newValue) - currentValue(am));
      const since = ltd(am) + delta - Number(p.lastMeterValue || 0);
      const remaining = Number(p.interval) - since;
      if (remaining <= 0) alerts.push({ program: p, msg: "🔴 «" + p.name + "» مستحق الآن — إنشاء أمر عمل" });
      else if (remaining <= Number(p.interval) * 0.1)
        alerts.push({ program: null, msg: "⏳ «" + p.name + "»: الصيانة مستحقة بعد " + remaining + " " + (tpl?.uom || "وحدة") });
    });
    return alerts;
  };

  /* ───── محرك ضمان المورد (ف6) ───── */
  const dailyRate = (am) => utilRate(am);
  /* تاريخ الانتهاء المتوقع من العدادات: اليوم + (نهاية العداد − العمر) ÷ معدل الاستخدام اليومي */
  const contractCalcExpiration = (c) => {
    const dates = (c.meters || []).map((cm) => {
      const am = db.assetMeters.find((m) => m.assetId === c.assetId && m.templateId === cm.templateId);
      if (!am) return null;
      const endValue = Number(cm.startValue || 0) + Number(cm.interval || 0);
      const rate = dailyRate(am);
      const remaining = endValue - ltd(am);
      if (remaining <= 0) return today();
      if (rate <= 0) return null;
      const offset = Math.floor(Number(remaining) / Number(rate));
      return Number.isFinite(offset) ? addDateDays(today(), offset) : null;
    }).filter(Boolean).sort();
    return dates[0] || null;
  };
  const contractEffectiveEnd = (c) => {
    const calc = contractCalcExpiration(c);
    if (c.endDate && calc) return c.endDate < calc ? c.endDate : calc; /* الأقرب انتهاءً */
    return c.endDate || calc || null;
  };
  const contractState = (c) => {
    if (c.status === "مسودة") return "مسودة";
    const end = contractEffectiveEnd(c);
    if (end && daysUntil(end) < 0) return "منتهٍ";
    return "جاهز";
  };
  /* العقود الفعالة للأصل وأصوله المرتبطة (الأب والمكونات التابعة) */
  const activeContracts = (assetId) => {
    const fam = new Set([assetId]);
    const a = db.assets.find((x) => x.id === assetId);
    if (a?.parentId) fam.add(a.parentId);
    db.assets.filter((x) => x.parentId === assetId).forEach((x) => fam.add(x.id));
    return db.contracts.filter((c) => fam.has(c.assetId) && contractState(c) === "جاهز")
      .sort((x, y) => String(contractEffectiveEnd(x) || "9999") < String(contractEffectiveEnd(y) || "9999") ? -1 : 1);
  };
  /* توافق قديم: لافتات الضمان تعمل من العقود أولًا ثم الضمانات البسيطة */
  const activeWarranty = (assetId) => {
    const c = activeContracts(assetId)[0];
    if (c) {
      const cov = db.coverages.find((v) => v.id === c.coverageId);
      return { supplier: nameOf("warrantyProviders", cov?.providerId) !== "—" ? nameOf("warrantyProviders", cov?.providerId) : (cov?.name || "ضمان"), end: contractEffectiveEnd(c) || "" };
    }
    return db.warranties.find((w) => w.assetId === assetId && daysUntil(w.end) >= 0 && (!w.start || daysUntil(w.start) <= 0));
  };
  /* ───── الأصول (ف3): قابلية الاستخدام، السجل، النسخ، التقسيم، وراثة الموقع ───── */
  const assetUsable = (a) => a && a.active !== false && (!a.endDate || a.endDate >= today());
  const nextAssetNumber = () => {
    let n = db.assets.length + 1, num;
    do { num = "AST-" + String(1000 + n); n++; } while (db.assets.some((a) => a.number === num));
    return num;
  };
  const logAsset = (assetId, action, extraPatch = {}) => {
    const a = db.assets.find((x) => x.id === assetId);
    if (!a) return;
    update("assets", assetId, { ...extraPatch, history: [...(a.history || []), { action, at: now(), by: role }] });
  };
  const assetSaveErrors = (d, editingId) => {
    if (!String(d.name || "").trim()) return "اسم الأصل مطلوب";
    if (d.number && db.assets.some((a) => a.number === d.number && a.id !== editingId)) return "رقم الأصل مستخدم — يجب أن يكون فريدًا";
    const orgKey = d.operatingOrganizationId || "__global__";
    if (d.serial && db.assets.some((a) => a.serial && a.serial === d.serial && (a.operatingOrganizationId || "__global__") === orgKey && a.id !== editingId)) return "الرقم التسلسلي مستخدم داخل نفس منظمة التشغيل";
    if (d.serial && Number(d.quantity || 1) !== 1) return "الأصل المسلسل يجب أن تكون كميته 1";
    if (d.itemRequired && !(String(d.itemId || "").trim() || String(d.itemName || "").trim())) return "الصنف Item مطلوب عند تفعيل item_required";
    if (d.ownership === "عميل" && !(String(d.customer || "").trim() || String(d.customerId || "").trim())) return "أصل العميل يحتاج اسم/معرف العميل";
    if ((d.locationType || "") === "INVENTORY" && !d.createdFromInventoryTx) return "Location = Inventory لا يضبط يدويًا من شاشة الأصل؛ يأتي من حركة مخزون";
    if (!String(d.location || "").trim()) return "لا أصل بدون موقع (قاعدة النظام)";
    return null;
  };
  /* الهرمية المادية: الفرع يرث موقع الأب الأعلى، وتغيير موقع الأب يحدّث كل الأبناء (ف3 §12) */
  const descendants = (assetId) => {
    const out = [];
    const walk = (id) => db.assets.filter((x) => x.parentId === id).forEach((c) => { out.push(c); walk(c.id); });
    walk(assetId);
    return out;
  };
  const propagateLocation = (assetId, location) => {
    const kids = descendants(assetId);
    if (!kids.length) return 0;
    save({ ...db, assets: db.assets.map((a) => kids.some((k) => k.id === a.id) ? { ...a, location } : a) });
    return kids.length;
  };
  /* نسخ أصل موجود (مع خيار نسخ العدادات) — حفظ ذري حتى لا تضيع الإضافات المتزامنة */
  const copyAsset = (a, withMeters) => {
    const created = { ...a, id: uid(), number: nextAssetNumber(), name: a.name + " (نسخة)",
      serial: "", parentId: a.parentId || "", notes: [], photos: [], docs: (a.docs || []).map((x) => ({ ...x, id: uid() })),
      parts: (a.parts || []).map((x) => ({ ...x, id: uid() })),
      history: [{ action: "إنشاء بالنسخ من " + a.number, at: now(), by: role }] };
    const copiedMeters = withMeters ? db.assetMeters.filter((m) => m.assetId === a.id && (!m.endDate || m.endDate >= today()))
      .map((m) => ({ id: uid(), assetId: created.id, templateId: m.templateId, initial: 0, recordAtWO: m.recordAtWO, endDate: "", estDailyRate: m.estDailyRate, readingsForRate: m.readingsForRate })) : [];
    save({ ...db, assets: [...db.assets, created], assetMeters: [...db.assetMeters, ...copiedMeters] });
    return created;
  };
  /* تقسيم أصل غير مسلسل (ف3 §7): شروط الأهلية ثم وحدات كمية = 1 */
  const splitAsset = (a) => {
    const qty = Number(a.quantity || 1);
    if (a.serial) return "الأصل مسلسل — لا يقبل التقسيم";
    if (!(Number.isInteger(qty) && qty > 1)) return "الكمية يجب أن تكون عددًا صحيحًا أكبر من 1";
    if ((a.locationType || "") === "INVENTORY") return "الأصل في المخزون — التقسيم من شاشة الأصل غير مسموح";
    if (a.endDate && a.endDate < today()) return "الأصل منتهٍ — لا تقسيم";
    if (db.workOrders.some((w) => w.assetId === a.id && ACTIVE_STATES.includes(w.status))) return "يوجد أمر عمل مفتوح على الأصل — أغلقه أولًا";
    const clones = [];
    for (let i = 2; i <= qty; i++) {
      clones.push({ ...a, id: uid(), number: nextAssetNumber().replace(/\d+$/, (n) => String(Number(n) + i - 2)), name: a.name + " /" + i, quantity: 1,
        notes: [], photos: [], docs: [], parts: (a.parts || []).map((x) => ({ ...x, id: uid() })),
        history: [{ action: "إنشاء بالتقسيم من " + a.number, at: now(), by: role }] });
    }
    save({ ...db, assets: db.assets.map((x) => x.id === a.id ? { ...x, quantity: 1, history: [...(x.history || []), { action: "تقسيم إلى " + qty + " وحدات: " + clones.map((c) => c.number).join("، "), at: now(), by: role }] } : x).concat(clones) });
    return null;
  };

  /* ───── قواعد مجموعات الأصول (ف4) ───── */
  const groupRule = (g) => db.assetGroupRules.find((r) => r.id === g.ruleId);
  const groupActive = (g) => !g.inactiveOn || g.inactiveOn >= today();
  const activeAssignments = (g) => (g.assignments || []).filter((x) => !x.end);
  /* أهلية الأصل للمجموعة: المجموعة فعالة + الأصل نشط + تطابق الخصائص + قيد الفريد ضمن القاعدة */
  const canAssignAsset = (asset, g) => {
    if (!asset || asset.active === false) return "الأصل منتهٍ/موقوف";
    if (!groupActive(g)) return "المجموعة معطلة — لا تعيينات جديدة";
    if (activeAssignments(g).some((x) => x.assetId === asset.id)) return "معين مسبقًا";
    const rule = groupRule(g);
    for (const attr of (rule?.attributes || [])) {
      const want = (g.attrValues || {})[attr];
      if (want && String(asset[attr] || "") !== String(want)) return "لا يطابق خاصية " + (GROUP_ATTRS.find(([k]) => k === attr)?.[1] || attr);
    }
    if (rule?.enforceUnique) {
      const other = db.assetGroups.find((og) => og.ruleId === rule.id && og.id !== g.id && activeAssignments(og).some((x) => x.assetId === asset.id));
      if (other) return "تعيين فريد: الأصل في «" + other.name + "» ضمن نفس القاعدة";
    }
    return null;
  };
  const syncIds = (g, assignments) => ({ assignments, assetIds: assignments.filter((x) => !x.end).map((x) => x.assetId) });
  const assignAsset = (g, assetId) => {
    const err = canAssignAsset(db.assets.find((a) => a.id === assetId), g);
    if (err) return err;
    const assignments = [...(g.assignments || []), { id: uid(), assetId, start: today(), end: "", endReason: "", by: role }];
    update("assetGroups", g.id, syncIds(g, assignments));
    return null;
  };
  const unassignAsset = (g, assignmentId, reason) => {
    const assignments = (g.assignments || []).map((x) => x.id === assignmentId ? { ...x, end: today(), endReason: reason || "إلغاء يدوي" } : x);
    update("assetGroups", g.id, syncIds(g, assignments));
  };
  /* إعادة التحقق: تغيّر الأصل ← أنهِ التعيين بسبب واضح بدل الحذف (ف4 §13) */
  const revalidateGroup = (g) => {
    const rule = groupRule(g);
    const bad = [];
    const assignments = (g.assignments || []).map((x) => {
      if (x.end) return x;
      const a = db.assets.find((z) => z.id === x.assetId);
      let reason = "";
      if (!a || a.active === false) reason = "إنهاء الأصل";
      else for (const attr of (rule?.attributes || [])) {
        const want = (g.attrValues || {})[attr];
        if (want && String(a[attr] || "") !== String(want)) { reason = "تغير بيانات الأصل"; break; }
      }
      if (reason) { bad.push((a?.name || "أصل") + " (" + reason + ")"); return { ...x, end: today(), endReason: reason }; }
      return x;
    });
    update("assetGroups", g.id, syncIds(g, assignments));
    return bad;
  };
  /* استبعادات قاعدة «حالة الأصل»: منع طلبات/أوامر العمل لأصول المجموعة */
  const assetExclusion = (assetId) => {
    for (const g of db.assetGroups) {
      if (!groupActive(g)) continue;
      if (!activeAssignments(g).some((x) => x.assetId === assetId)) continue;
      if (g.excludeFromWO || g.excludeFromRequests)
        return { wo: !!g.excludeFromWO, requests: !!g.excludeFromRequests, groupName: g.name };
    }
    return { wo: false, requests: false, groupName: "" };
  };

  /* توليد الاستحقاقات وتجميعها في مطالبة (يحاكي الـ Scheduled Process) */
  const generateEntitlements = (wo) => {
    if (!wo.warrantyRepair) { alert("مؤشر «إصلاح ضمان» غير مفعّل لهذا الأمر — لا تُنشأ استحقاقات (قاعدة ف6)"); return; }
    const cs = activeContracts(wo.assetId);
    if (!cs.length) { alert("لا عقود ضمان فعالة للأصل أو أصوله المرتبطة"); return; }
    const contract = cs[0]; /* الأقرب انتهاءً */
    const cov = db.coverages.find((v) => v.id === contract.coverageId) || {};
    const provId = cov.providerId || "";
    const codes = (cov.repairCodes || []).filter((r) => r.enabled !== false).map((r) => r.code);
    const useMatch = !!wo.matchCodes && codes.length > 0;
    const opCovered = (op) => !useMatch || codes.some((cd) => String(op.repairTx || "").startsWith(cd));
    const anyOpCovered = (wo.operations || []).some(opCovered);
    const findRate = () => {
      const r = db.laborRates.find((x) => x.providerId === provId && x.active !== false && (!x.startDate || x.startDate <= (contract.startDate || today())) && (!x.endDate || x.endDate >= (contract.startDate || today())));
      return r ? Number(r.hourlyRate || 0) : null;
    };
    const hourly = findRate();
    const ents = [];
    (wo.materials || []).forEach((m) => {
      const used = Number(m.usedQty || 0);
      if (used <= 0) return;
      const covd = anyOpCovered;
      ents.push({ id: uid(), workOrderId: wo.id, type: "صرف مادة", description: m.itemId ? nameOf("items", m.itemId) : m.name,
        qty: used, unitCost: Number(m.unitCost || 0), total: used * Number(m.unitCost || 0),
        contractId: covd ? contract.id : "", included: covd && cov.partsReimb !== false && !!cov.partsReimb, claimId: "" });
    });
    (wo.operations || []).filter((o) => o.status === "مكتملة").forEach((op) => {
      const covd = opCovered(op);
      const srt = db.repairTimes.find((t) => t.providerId === provId && t.stdOpId === op.stdOpId && t.active !== false && (!t.startDate || t.startDate <= (contract.startDate || today())));
      const tech = db.technicians.find((t) => t.id === op.assigneeId);
      const rate = hourly != null ? hourly : Number(tech?.rate || 0);
      if (srt) ents.push({ id: uid(), workOrderId: wo.id, type: "إصلاح قياسي", description: op.name + " (زمن قياسي)",
        qty: Number(srt.hours || 0), unitCost: rate, total: Number(srt.hours || 0) * rate,
        contractId: covd ? contract.id : "", included: covd && !!cov.laborReimb, claimId: "" });
      else if (Number(op.actualHours || 0) > 0) ents.push({ id: uid(), workOrderId: wo.id, type: "تحميل مورد", description: op.name,
        qty: Number(op.actualHours || 0), unitCost: rate, total: Number(op.actualHours || 0) * rate,
        contractId: covd ? contract.id : "", included: covd && !!cov.laborReimb, claimId: "" });
    });
    if (!ents.length) { alert("لا معاملات (مواد مستخدمة أو ساعات) لتوليد استحقاقات منها"); return; }
    /* أزل توليدًا سابقًا لنفس الأمر ومطالباته التلقائية */
    const oldEnts = db.entitlements.filter((e) => e.workOrderId === wo.id);
    const oldClaimIds = new Set(oldEnts.map((e) => e.claimId).filter(Boolean));
    let claims = db.claims.filter((c) => !(oldClaimIds.has(c.id) && c.auto));
    let entitlements = db.entitlements.filter((e) => e.workOrderId !== wo.id);
    const included = ents.filter((e) => e.included);
    if (included.length) {
      const claim = { id: uid(), number: "CLM-" + String(1000 + claims.length + 1), workOrderId: wo.id,
        providerId: provId, status: "قيد المراجعة", auto: true, createdAt: today(), submitBy: "", assignedTo: "", notes: "", adjustments: [], reimbursementAmount: "", claimType: "" };
      included.forEach((e) => { e.claimId = claim.id; });
      claims = [...claims, claim];
    }
    entitlements = [...entitlements, ...ents];
    save({ ...db, entitlements, claims });
    alert("✓ أُنشئ " + ents.length + " استحقاق (" + included.length + " ضمن مطالبة" + (included.length ? " " + "CLM-" + String(1000 + claims.length) : "") + ")\n" +
      (useMatch ? "تمت مطابقة أكواد الإصلاح مع التغطية." : "بدون مطابقة أكواد — اعتمد على العقد الفعال الأقرب انتهاءً."));
  };

  /* ───── المخزون: الرصيد من الحركات فقط (لا تعديل مباشر) ───── */
  const onHand = (itemId, whId) => db.stockTx.reduce((s, t) => {
    if (t.itemId !== itemId) return s;
    const q = Number(t.qty || 0);
    if (whId && t.type === "تحويل") return s + (t.toWarehouseId === whId ? q : 0) - (t.warehouseId === whId ? q : 0);
    if (whId && t.warehouseId !== whId) return s;
    if (t.type === "استلام" || t.type === "إرجاع من أمر عمل") return s + q;
    if (t.type === "صرف لأمر عمل" || t.type === "إتلاف") return s - q;
    if (t.type === "تسوية") return s + q;
    if (t.type === "تحويل") return s; /* بدون مستودع: التحويل لا يغيّر الإجمالي */
    return s;
  }, 0);
  /* المحجوز لأوامر العمل المفتوحة (لم يُصرف بعد) */
  const reservedQty = (itemId) => db.workOrders.reduce((s, w) =>
    ACTIVE_STATES.includes(w.status)
      ? s + (w.materials || []).reduce((x, m) => x + (m.itemId === itemId && m.reserved && !Number(m.issuedQty || 0) ? Number(m.qty || 0) : 0), 0)
      : s, 0);
  const availableQty = (itemId) => onHand(itemId) - reservedQty(itemId);
  const addTx = (tx) => add("stockTx", { at: today(), ...tx });
  /* فحص توفر مواد أمر العمل (قاعدة: لا إصدار بدون فحص التوفر) */
  const woShortages = (wo) => (wo.materials || []).filter((m) =>
    m.itemId && !Number(m.issuedQty || 0) && Number(m.qty || 0) > availableQty(m.itemId) + (m.reserved ? Number(m.qty || 0) : 0));

  /* أوامر العمل */
  const woNumber = () => "WO-" + String(1000 + db.workOrders.length + 1);
  const log = (wo, action) => [...(wo.execLog || []), { action, at: now(), by: role + (myTechId ? " — " + nameOf("technicians", myTechId) : "") }];
  const woAssignedTechIds = (wo) => [...new Set([
    ...(wo._cmmsAssignedTechIds || []),
    ...(wo.assignments || []).map((a) => a.technicianId),
    ...(db.workOrderAssignments || []).filter((a) => a.workOrderId === wo.id).map((a) => a.technicianId),
    ...(wo.operations || []).map((o) => o.assigneeId),
  ].filter(Boolean))];
  const hasAssignedTechnician = (wo) => woAssignedTechIds(wo).length > 0;
  const materialStatusOf = (wo) => {
    const mats = wo.materials || [];
    if (!mats.length) return "لا مواد";
    if (mats.every((m) => Number(m.issuedQty || 0) > 0)) return "مصروف";
    if (mats.every((m) => m.reserved || Number(m.issuedQty || 0) > 0)) return "Available";
    return woShortages(wo).length ? "Waiting Material" : "Available";
  };
  const transitionError = (wo, next, extra = {}) => {
    if (!wo.assetId) return "No Work Order without Asset — لا أمر عمل بدون أصل.";
    if (wo.type === "وقائي" && !wo.programId && !wo.workDefId && !wo.followUpOf) return "No PM Work Order without Maintenance Program or Work Definition.";
    if (["مُصدر", "جاهز", "قيد التنفيذ", "بانتظار المراجعة", "مغلق"].includes(next) && !hasAssignedTechnician(wo)) return "No work order without technicians assign — أسند فنيًا واحدًا على الأقل قبل المتابعة.";
    if (next === "قيد التنفيذ" && wo.safetyRequired && (wo.checklist || []).some((c) => !c.done)) return "No start without safety checklist if required — أكمل قائمة السلامة أولًا.";
    if (next === "بانتظار المراجعة") {
      const gaps = completionGaps(wo);
      if (gaps.length) return "لا يمكن طلب الإكمال:\n• " + gaps.join("\n• ");
    }
    if (next === "مغلق" && !extra.supervisorApproved && !wo.supervisorApproved) return "No final close without supervisor approval — لا إغلاق نهائي بدون اعتماد المشرف.";
    return "";
  };
  const createWO = (data) => {
    if (!data.assetId) { alert("No Work Order without Asset — اختر الأصل أولًا."); return; }
    if (data.type === "وقائي" && !data.programId && !data.workDefId && !data.routeId) { alert("No PM Work Order without Maintenance Program or Work Definition."); return; }
    const asset = db.assets.find((a) => a.id === data.assetId);
    if (asset && !assetUsable(asset)) { alert("⛔ الأصل منتهٍ/موقوف (" + (asset.endDate ? "تاريخ الإنهاء " + fmt(asset.endDate) : "موقوف") + ") — لا أوامر عمل"); return; }
    if (asset && asset.allowWO === false) { alert("⛔ هذا الأصل لا يسمح بأوامر العمل (علم الأصل)"); return; }
    if (asset && asset.defaultWOType && !data.type) data.type = asset.defaultWOType;
    const exc = assetExclusion(data.assetId);
    if (exc.wo) { alert("⛔ الأصل مستبعد من أوامر العمل بواسطة مجموعة التحقق «" + exc.groupName + "» (قاعدة حالة الأصل)"); return; }
    const def = db.workDefs.find((d) => d.id === data.workDefId);
    const primaryTechId = data.assignedTechnicianId || "";
    const operations = (def?.opIds || []).map((opId, i) => {
      const op = db.stdOps.find((o) => o.id === opId);
      return { id: uid(), seq: (i + 1) * 10, stdOpId: opId, name: op?.name || "عملية", workCenterId: op?.workCenterId || "",
        minutes: op?.minutes || "", status: "معلقة", assigneeId: i === 0 ? primaryTechId : "", actualHours: 0,
        steps: (op?.steps || "").split("\n").filter(Boolean).map((text, idx) => ({ id: uid(), seq: idx + 1, text, done: false })),
        opType: op?.type || "داخلية", supplier: op?.supplier || "",
        attachments: (op?.attachments || []).map((a) => ({ ...a })),
        repairReason: op?.repairReason || "", repairTx: op?.repairTx || "", workDone: op?.workDone || "",
        chargeType: (op?.resources || [])[0]?.chargeType || "يدوي" };
    });
    const assignments = primaryTechId ? [{ id: uid(), technicianId: primaryTechId, role: "فني رئيسي", status: "مسند", assignedAt: today(), assignedBy: role }] : [];
    const checklist = data.safetyRequired ? SAFETY_DEFAULTS.map((t) => ({ id: uid(), text: t, done: false })) : [];
    const w = activeWarranty(data.assetId);
    if (w && ["تصحيحي", "طارئ"].includes(data.type)) alert("⚠ تنبيه: هذا الأصل تحت ضمان ساري لدى «" + w.supplier + "» حتى " + fmt(w.end) + ".\nراجع الضمان قبل تحميل تكلفة إصلاح داخلي.");
    const wcs = activeContracts(data.assetId);
    const wCov = wcs[0] ? db.coverages.find((v) => v.id === wcs[0].coverageId) : null;
    data.warrantyRepair = wcs.length > 0 && data.type !== "وقائي";
    data.matchCodes = !!(wCov && (wCov.repairCodes || []).some((r) => r.enabled !== false));
    const createdEvent = { id: uid(), from: "", to: "مسودة", at: today(), atText: now(), by: role, action: "إنشاء أمر العمل" };
    add("workOrders", { number: woNumber(), status: "مسودة", operations, checklist, materials: [], photos: [],
      failure: null, exceptions: [], assignments, resources: [], statusHistory: [createdEvent], approvals: [], completionRequests: [], supervisorReviews: [],
      execLog: [{ action: "إنشاء أمر العمل", at: now(), by: role }],
      history: [{ to: "مسودة", at: today() }], underWarranty: !!w, _cmmsAssignedTechIds: assignments.map((a) => a.technicianId), ...data });
  };
  const setWOStatus = (wo, next, extra = {}) => {
    const err = transitionError(wo, next, extra);
    if (err) { alert(err); return false; }
    const atText = now();
    const event = { id: uid(), workOrderId: wo.id, number: wo.number, from: wo.status, to: next, at: today(), atText, by: role, byTechId: myTechId || "" };
    const assignedIds = woAssignedTechIds(wo);
    const execEvent = { id: uid(), workOrderId: wo.id, number: wo.number, action: "STATUS_CHANGE", description: "تغيير الحالة: " + wo.status + " ← " + next, at: today(), atText, by: role, byTechId: myTechId || "" };
    const patchedWo = {
      ...wo, status: next, ...extra, _cmmsAssignedTechIds: assignedIds,
      history: [...(wo.history || []), { from: wo.status, to: next, at: today() }],
      statusHistory: [...(wo.statusHistory || []), event],
      execLog: log(wo, "تغيير الحالة: " + wo.status + " ← " + next),
      ...(next === "بانتظار المراجعة" ? { completionRequestedAt: today(), completionRequestStatus: "مفتوح" } : {}),
      ...(next === "مغلق" ? { completedAt: today(), supervisorApproved: true, completionRequestStatus: "معتمد" } : {}),
    };
    const nextDb = { ...db,
      workOrders: db.workOrders.map((w) => (w.id === wo.id ? patchedWo : w)),
      workOrderStatusHistory: [...(db.workOrderStatusHistory || []), event],
      workOrderExecutionHistory: [...(db.workOrderExecutionHistory || []), execEvent],
    };
    if (next === "بانتظار المراجعة") {
      nextDb.workOrderCompletionRequests = [...(db.workOrderCompletionRequests || []), { id: uid(), workOrderId: wo.id, number: wo.number, status: "مفتوح", requestedAt: today(), requestedByRole: role, requestedByTechId: myTechId || "", notes: wo.executionNotes || "" }];
      nextDb.workOrderLaborTransactions = [...(db.workOrderLaborTransactions || []), ...(wo.operations || []).filter((op) => Number(op.actualHours || 0) > 0 && !(db.workOrderLaborTransactions || []).some((x) => x.workOrderId === wo.id && x.operationId === op.id)).map((op) => ({ id: uid(), workOrderId: wo.id, operationId: op.id, technicianId: op.assigneeId || myTechId || "", hours: Number(op.actualHours || 0), rate: Number(db.technicians.find((t) => t.id === (op.assigneeId || myTechId))?.rate || 0), at: today(), source: "Submit Completion" }))];
      nextDb.workOrderMaterialUsage = [...(db.workOrderMaterialUsage || []), ...(wo.materials || []).filter((m) => Number(m.usedQty || 0) > 0 && !(db.workOrderMaterialUsage || []).some((x) => x.workOrderId === wo.id && x.materialLineId === m.id)).map((m) => ({ id: uid(), workOrderId: wo.id, materialLineId: m.id, itemId: m.itemId, usedQty: Number(m.usedQty || 0), unitCost: Number(m.unitCost || 0), at: today(), confirmedByRole: role, confirmedByTechId: myTechId || "" }))];
    }
    if (next === "مغلق") {
      nextDb.workOrderApprovals = [...(db.workOrderApprovals || []), { id: uid(), workOrderId: wo.id, number: wo.number, decision: "Approve", approvedAt: today(), approvedByRole: role, notes: extra.reviewNotes || "" }];
      nextDb.workOrderSupervisorReviews = [...(db.workOrderSupervisorReviews || []), { id: uid(), workOrderId: wo.id, number: wo.number, decision: "Approve", reviewedAt: today(), reviewedByRole: role, notes: extra.reviewNotes || "" }];
      const cost = woCost(patchedWo);
      nextDb.workOrderCosts = [...(db.workOrderCosts || []), { id: uid(), workOrderId: wo.id, number: wo.number, labor: cost.labor, material: cost.material, total: cost.total, at: today(), source: "Close Work Order" }];
      if (wo.programId) nextDb.programs = db.programs.map((p) => p.id === wo.programId ? { ...p, lastDone: today() } : p);
    }
    if (next === "مُعاد للتصحيح") {
      nextDb.workOrderSupervisorReviews = [...(db.workOrderSupervisorReviews || []), { id: uid(), workOrderId: wo.id, number: wo.number, decision: "Reject", reviewedAt: today(), reviewedByRole: role, notes: extra.reviewNotes || "" }];
    }
    save(nextDb);
    return true;
  };

  /* بوابات التحقق قبل طلب الإكمال (وثيقة التنفيذ §12) */
  const completionGaps = (wo) => {
    const gaps = [];
    if (!hasAssignedTechnician(wo)) gaps.push("لا يوجد فني مسند لأمر العمل");
    if ((wo.checklist || []).some((c) => !c.done)) gaps.push("قائمة فحص السلامة غير مكتملة");
    if ((wo.operations || []).some((o) => o.status !== "مكتملة")) gaps.push("توجد عمليات غير مكتملة");
    const hours = (wo.operations || []).reduce((s, o) => s + Number(o.actualHours || 0), 0);
    if (hours <= 0) gaps.push("لم تُسجّل ساعات عمل");
    if ((wo.materials || []).some((m) => Number(m.issuedQty || 0) > 0 && (m.usedQty === "" || m.usedQty == null))) gaps.push("أكّد كميات المواد المستخدمة");
    if (["تصحيحي", "طارئ"].includes(wo.type) && !wo.failure) gaps.push("سجّل بيانات العطل (إلزامي للتصحيحي/الطارئ)");
    if ((wo.routeAssets || []).some((x) => x.status === "معلق")) gaps.push("أكمل أو تخطَّ كل أصول المسار");
    const mandMeters = db.assetMeters.filter((m) => m.assetId === wo.assetId && !(m.endDate && m.endDate < today()) &&
      ((m.recordAtWO || db.meterTemplates.find((t) => t.id === m.templateId)?.recordAtWO) === "إلزامي"));
    if (mandMeters.some((m) => !db.readings.some((r) => r.workOrderId === wo.id && r.assetMeterId === m.id && !["معطلة", "ملغاة"].includes(r.status))))
      gaps.push("سجّل قراءات العدادات الإلزامية عند الإكمال");
    if (!String(wo.executionNotes || "").trim()) gaps.push("أضف ملاحظات الإكمال/النتيجة");
    if (wo.photoRequired) {
      const types = (wo.photos || []).map((p) => p.type);
      if (!types.includes("قبل")) gaps.push("صورة قبل العمل مطلوبة");
      if (!types.includes("بعد")) gaps.push("صورة بعد العمل مطلوبة");
    }
    return gaps;
  };

  /* تكلفة أمر العمل: عمالة + مواد مستخدمة فعليًا */
  const woCost = (wo) => {
    let labor = 0, material = 0;
    for (const op of wo.operations || []) {
      const tech = db.technicians.find((t) => t.id === op.assigneeId);
      labor += Number(op.actualHours || 0) * Number(tech?.rate || 0);
    }
    for (const m of wo.materials || []) material += Number(m.usedQty || 0) * Number(m.unitCost || 0);
    return { labor, material, total: labor + material };
  };

  /* ───── البرامج: على أصل واحد أو مجموعة ───── */
  const programAssets = (p) => (p.targetType === "مجموعة"
    ? (db.assetGroups.find((g) => g.id === p.assetGroupId)?.assetIds || []).map((id) => db.assets.find((a) => a.id === id)).filter(Boolean)
    : [db.assets.find((a) => a.id === p.assetId)].filter(Boolean))
    .filter((a) => assetUsable(a) && a.allowPrograms !== false);
  const programDue = (p) => {
    if (p.method === "فاصل عداد") {
      const am = db.assetMeters.find((m) => m.id === p.assetMeterId);
      if (!am) return { due: false, label: "عداد غير محدد" };
      const since = ltd(am) - Number(p.lastMeterValue || 0);
      const rem = Number(p.interval) - since;
      return { due: since >= Number(p.interval), soon: rem > 0 && rem <= Number(p.interval) * 0.1,
        label: since + " / " + p.interval + " " + nameOf("meterTemplates", am.templateId, "uom") + (rem > 0 ? " (متبقٍ " + rem + ")" : "") };
    }
    const base = p.lastDone || p.startDate || today();
    const nd = addDateDays(base, Number(p.interval || 0));
    return { due: daysUntil(nd) <= 0, soon: daysUntil(nd) > 0 && daysUntil(nd) <= 7, label: "الاستحقاق " + fmt(nd), nextDate: nd };
  };
  const generateWO = (p) => {
    const info = programDue(p);
    const targets = programAssets(p);
    targets.forEach((a) => {
      createWO({ title: "صيانة وقائية — " + p.name + (targets.length > 1 ? " (" + a.name + ")" : ""),
        assetId: a.id, type: "وقائي", priority: "عادية",
        plannedStart: today(), plannedEnd: info.nextDate || today(), workDefId: p.workDefId, programId: p.id, safetyRequired: true });
    });
    if (targets.length > 1) alert("أُنشئ " + targets.length + " أمر عمل — واحد لكل أصل في المجموعة");
    if (p.method === "فاصل عداد") {
      const am = db.assetMeters.find((m) => m.id === p.assetMeterId);
      update("programs", p.id, { lastMeterValue: am ? ltd(am) : 0 });
    } else update("programs", p.id, { lastDone: today() });
  };

  /* طلبات العمل */
  const actRequest = (req, action) => {
    if (action === "قبول") update("workRequests", req.id, { status: "مقبول" });
    if (action === "رفض") update("workRequests", req.id, { status: "مرفوض" });
    if (action === "تحويل لأمر عمل") {
      update("workRequests", req.id, { status: "محوّل" });
      createWO({ title: req.title, assetId: req.assetId, type: req.severity === "حرجة" ? "طارئ" : "تصحيحي",
        priority: req.severity === "حرجة" ? "طارئ" : "عالية", plannedStart: today(), plannedEnd: "", safetyRequired: true });
    }
  };

  /* نسخ احتياطي */
  const exportData = () => {
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "cmms-backup-" + today() + ".json"; a.click();
  };
  /* تصدير سجل الأصول CSV (وثيقة الأصول §Export_Assets) */
  const exportAssetsCSV = () => {
    const head = "رقم الأصل,الاسم,النوع,المجموعة,الموقع,الأصل الأب,حرج,نشط";
    const rows = db.assets.map((a) => [a.number, a.name, a.type,
      db.assetGroups.find((g) => (g.assetIds || []).includes(a.id))?.name || "",
      a.location, a.parentId ? nameOf("assets", a.parentId) : "", a.critical ? "نعم" : "لا", a.active === false ? "لا" : "نعم"
    ].map((x) => '"' + String(x || "").replace(/"/g, '""') + '"').join(","));
    const blob = new Blob(["\uFEFF" + [head, ...rows].join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "asset-register-" + today() + ".csv"; a.click();
  };
  const importData = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      try { save(normalizeDb(JSON.parse(reader.result))); alert("تم الاستيراد بنجاح"); }
      catch (e) { alert("ملف غير صالح"); }
    };
    reader.readAsText(file);
  };

  if (firebaseEnabled && !authReady) return <div style={{ minHeight: "100vh", background: C.paper, display: "grid", placeItems: "center" }}>جارٍ التحقق من تسجيل الدخول…</div>;
  if (firebaseEnabled && authReady && !firebaseUser) return <FirebaseAuthScreen services={firebaseServices} />;
  if (!loaded) return <div style={{ minHeight: "100vh", background: C.paper, display: "grid", placeItems: "center" }}>جارٍ التحميل…</div>;

  const openWOs = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status));
  const ctx = { db, add, update, remove, nameOf, lastReading, ltd, addReading, meterReadings, currentValue,
    can, role, woCost, completionGaps, setWOStatus, log, createWO, myTechId,
    activeWarranty, pmCheckAfterReading, programAssets, programDue, generateWO, exportAssetsCSV, woAssignedTechIds, hasAssignedTechnician, materialStatusOf,
    onHand, reservedQty, availableQty, addTx, woShortages,
    activeContracts, contractState, contractEffectiveEnd, contractCalcExpiration, dailyRate, generateEntitlements, save,
    meterRows, activeReadings, calcUtilRate, utilRate, disableReading,
    groupRule, groupActive, activeAssignments, canAssignAsset, assignAsset, unassignAsset, revalidateGroup, assetExclusion,
    assetUsable, nextAssetNumber, logAsset, assetSaveErrors, descendants, propagateLocation, copyAsset, splitAsset,
    firebaseEnabled, firebaseServices, firebaseUser, firebaseProfile, setSyncStatus };

  const MAIN_TABS = can.requestOnly
    ? [["home", "الرئيسية"], ["requests", "طلباتي"]]
    : role === "فني"
      ? [["home", "الرئيسية"], ["mywork", "أعمالي"], ["wo", "أوامر العمل"], ["more", "المزيد"]]
      : role === "مخزن"
        ? [["home", "الرئيسية"], ["inventory", "المخزون"], ["wo", "أوامر العمل"], ["more", "المزيد"]]
        : [["home", "الرئيسية"], ["wo", "أوامر العمل"], ["super", "الإشراف"], ["assets", "الأصول"], ["more", "المزيد"]];
  const MORE = [
    ["firebase", "Firebase والصلاحيات"], ...(can.admin || can.review ? [["users", "المستخدمون والصلاحيات"]] : []),
    ["maintenance", "إدارة الصيانة"], ["inventory", "المخزون وقطع الغيار"], ["mywork", "قائمة الإرسال"], ["requests", "طلبات العمل"], ["programs", "البرامج الوقائية"], ["forecast", "توقعات الصيانة"],
    ["meters", "العدادات"], ["assets", "الأصول"], ["org", "منظمة الصيانة"], ["oracle", "مطابقة المتطلبات"], ["governance", "الحوكمة والرقابة"], ["governance100", "الحوكمة 100%"], ["techs", "الفنيون"],
    ["groups", "مجموعات الأصول"], ["lh", "الهرميات والمسارات"], ["warranty", "الضمانات"], ["stdops", "العمليات القياسية"], ["workdefs", "تعريفات العمل"],
    ["failures", "تحليل الأعطال"], ["reports", "التقارير"], ["data", "البيانات والنسخ"],
  ];

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: C.paper, color: C.ink, fontFamily: "'Cairo', system-ui, sans-serif", paddingBottom: 76 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;800&display=swap');
        button { cursor: pointer; font-family: inherit; }
        input, select, textarea { font-size: 16px; font-family: inherit; }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
      `}</style>

      <header style={{ padding: "12px 16px 8px", borderBottom: `2px solid ${C.ink}`, position: "sticky", top: 0, zIndex: 5, background: C.paper }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 21, fontWeight: 800 }}>نظام الصيانة<span style={{ color: C.orange }}>.</span></div>
            <div style={{ fontSize: 12, color: C.steel }}>{db.assets.length} أصل · {openWOs.length} أمر مفتوح</div>
            <div style={{ fontSize: 11, color: (syncStatus.includes("الخادم") || syncStatus.includes("Firestore") || syncStatus.includes("Firebase")) && !syncStatus.includes("غير") && !syncStatus.includes("فشل") && !syncStatus.includes("رفض") ? C.green : C.amber }}>{syncStatus}</div>
          </div>
          {firebaseEnabled ? (
            <div style={{ textAlign: "left" }}>
              <Badge text={role} color={role === "مدير" ? C.green : role === "مشرف" ? C.blue : role === "مخزن" ? C.purple : role === "فني" ? C.amber : C.steel} />
              <div style={{ fontSize: 10, color: C.steel, maxWidth: 170, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{firebaseUser?.email || "Firebase"}</div>
              <button onClick={() => firebaseServices && signOutFirebase(firebaseServices)} style={{ border: "none", background: "transparent", color: C.red, fontSize: 11, fontWeight: 800 }}>خروج</button>
            </div>
          ) : (
            <select value={role} onChange={(e) => setSetting("role", e.target.value)}
              style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, padding: "4px 8px", fontSize: 13, fontWeight: 700, background: "#fff" }}>
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
          )}
        </div>
        {role === "فني" && !firebaseEnabled && (
          <select value={db.settings.myTechId} onChange={(e) => setSetting("myTechId", e.target.value)}
            style={{ marginTop: 6, width: "100%", border: `1.5px solid ${C.line}`, borderRadius: 4, padding: "4px 8px", fontSize: 13 }}>
            <option value="">— اختر اسمك من قائمة الفنيين —</option>
            {db.technicians.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        )}
        {role === "فني" && firebaseEnabled && !myTechId && (
          <div style={{ marginTop: 6, fontSize: 12, color: C.amber, fontWeight: 700 }}>يجب أن يربط المدير حسابك بفني من شاشة المستخدمين والصلاحيات.</div>
        )}
      </header>

      <main style={{ padding: 14, maxWidth: 600, margin: "0 auto" }}>
        {tab === "home" && <Home db={db} nameOf={nameOf} programDue={programDue} generateWO={generateWO} setTab={setTab} openWO={setWoDetail} can={can} />}
        {tab === "wo" && <WorkOrders ctx={ctx} openWO={setWoDetail} />}
        {tab === "mywork" && <MyWork ctx={ctx} openWO={setWoDetail} />}
        {tab === "assets" && <Assets ctx={ctx} openAsset={setAssetDetail} />}
        {tab === "inventory" && <Inventory ctx={ctx} openWO={setWoDetail} />}
        {tab === "lh" && <LogicalHierarchies ctx={ctx} openAsset={setAssetDetail} />}
        {tab === "more" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {MORE.map(([id, label]) => (
              <button key={id} onClick={() => setTab(id)} style={{ ...card(), padding: "16px 12px", fontWeight: 700, fontSize: 14, textAlign: "right" }}>{label}</button>
            ))}
          </div>
        )}
        {tab === "firebase" && <FirebaseSecurityPanel ctx={ctx} />}
        {tab === "users" && <FirebaseUsersPanel ctx={ctx} />}
        {tab === "maintenance" && <MaintenanceManagementHub ctx={ctx} openWO={setWoDetail} setTab={setTab} />}
        {tab === "org" && <Organization ctx={ctx} />}
        {tab === "oracle" && <OracleCompliance ctx={ctx} setTab={setTab} />}
        {tab === "governance" && <GovernanceHub ctx={ctx} />}
        {tab === "governance100" && <Governance100Hub ctx={ctx} />}
        {tab === "techs" && <Crud ctx={ctx} entity="technicians" title="الفنيون" schema={[
          { k: "name", label: "اسم الفني" },
          { k: "specialty", label: "التخصص", type: "select", options: ["ميكانيكي", "كهربائي", "عام"] },
          { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
          { k: "rate", label: "أجر الساعة (ر.س)", type: "number" }, { k: "phone", label: "الجوال" },
        ]} render={(t) => [t.name, [t.specialty, nameOf("workCenters", t.workCenterId) !== "—" ? nameOf("workCenters", t.workCenterId) : "", t.rate ? money(t.rate) + "/ساعة" : ""].filter(Boolean).join(" · ")]} />}
        {tab === "groups" && <AssetGroups ctx={ctx} />}
        {tab === "meters" && <Meters ctx={ctx} />}
        {tab === "warranty" && <WarrantyHub ctx={ctx} openWO={setWoDetail} />}
        {tab === "stdops" && <StdOpsManager ctx={ctx} />}
        {tab === "workdefs" && <WorkDefs ctx={ctx} />}
        {tab === "requests" && <Requests ctx={ctx} actRequest={actRequest} />}
        {tab === "programs" && <Programs ctx={ctx} programDue={programDue} generateWO={generateWO} />}
        {tab === "forecast" && <Forecast ctx={ctx} programDue={programDue} generateWO={generateWO} />}
        {tab === "super" && <Supervision ctx={ctx} openWO={setWoDetail} />}
        {tab === "failures" && <FailureAnalysis ctx={ctx} openWO={setWoDetail} />}
        {tab === "reports" && <Reports ctx={ctx} />}
        {tab === "data" && <DataTab exportData={exportData} importData={importData} exportAssetsCSV={exportAssetsCSV} db={db} can={can} save={save} />}
      </main>

      {woDetail && <WODetail ctx={ctx} woId={woDetail} onClose={() => setWoDetail(null)}
        openAsset={(id) => { setWoDetail(null); setAssetDetail(id); }} />}
      {assetDetail && <AssetDetail ctx={ctx} assetId={assetDetail} onClose={() => setAssetDetail(null)}
        openWO={(id) => { setAssetDetail(null); setWoDetail(id); }} />}

      <nav style={{ position: "fixed", bottom: 0, left: 0, right: 0, display: "flex", borderTop: `2px solid ${C.ink}`, background: C.card, zIndex: 6 }}>
        {MAIN_TABS.map(([id, label]) => {
          const on = tab === id || (id === "more" && !MAIN_TABS.some(([t]) => t === tab));
          return <button key={id} onClick={() => setTab(id)} style={{ flex: 1, padding: "12px 0 14px", border: "none", fontWeight: 800, fontSize: 12.5, background: on ? C.ink : C.card, color: on ? "#fff" : C.ink }}>{label}</button>;
        })}
      </nav>
    </div>
  );
}


/* ───────────────────────── Firebase Auth / Governance Backend ───────────────────────── */
function FirebaseAuthScreen({ services }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState("login");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError("");
    try {
      if (mode === "register") await registerFirebase(services, email, password);
      else await signInFirebase(services, email, password);
    } catch (err) {
      console.error(err);
      setError("تعذر تسجيل الدخول. تأكد من تفعيل Email/Password في Firebase Authentication وصحة البيانات.");
    }
    setBusy(false);
  };
  return (
    <div dir="rtl" style={{ minHeight:"100vh", background:C.paper, display:"grid", placeItems:"center", padding:18, fontFamily:"'Cairo', system-ui, sans-serif" }}>
      <form onSubmit={submit} style={{ ...card(), width:"100%", maxWidth:430, padding:18 }}>
        <div style={{ fontSize:24, fontWeight:900, marginBottom:4 }}>تسجيل دخول Firebase</div>
        <div style={{ fontSize:13, color:C.steel, marginBottom:14 }}>الصلاحيات الآن من Firebase وليست من اختيار داخل الواجهة. بريد المالك الافتراضي: {FIREBASE_OWNER_EMAIL}</div>
        <Field label="البريد الإلكتروني"><input value={email} onChange={(e)=>setEmail(e.target.value)} type="email" required style={inputStyle()} /></Field>
        <Field label="كلمة المرور"><input value={password} onChange={(e)=>setPassword(e.target.value)} type="password" required minLength={6} style={inputStyle()} /></Field>
        {error && <div style={{ color:C.red, fontSize:13, marginBottom:8 }}>{error}</div>}
        <button type="submit" disabled={busy} style={{ background:C.ink, color:"#fff", border:`1.5px solid ${C.ink}`, borderRadius:4, padding:12, fontSize:13, fontWeight:800, width:"100%" }}>{busy ? "جارٍ التنفيذ…" : mode === "register" ? "إنشاء حساب" : "دخول"}</button>
        <button type="button" onClick={()=>setMode(mode === "login" ? "register" : "login")} style={{ marginTop:10, width:"100%", border:"none", background:"transparent", color:C.blue, fontWeight:800 }}>
          {mode === "login" ? "إنشاء حساب جديد كطالب خدمة" : "لدي حساب بالفعل"}
        </button>
        <button type="button" onClick={()=>{ clearRuntimeFirebaseConfig(); location.reload(); }} style={{ marginTop:8, width:"100%", border:"none", background:"transparent", color:C.red, fontWeight:800 }}>تغيير إعدادات Firebase</button>
      </form>
    </div>
  );
}

function FirebaseSecurityPanel({ ctx }) {
  const { firebaseEnabled, firebaseServices, firebaseUser, firebaseProfile, role, db, can, setSyncStatus } = ctx;
  const [configText, setConfigText] = useState("");
  const [migrating, setMigrating] = useState(false);
  const saveConfig = () => {
    const cfg = extractFirebaseConfig(configText);
    if (!cfg) return alert("لم أستطع قراءة firebaseConfig. الصق الكائن كاملًا من Firebase Web App settings.");
    saveRuntimeFirebaseConfig(cfg);
    alert("تم حفظ إعدادات Firebase على هذا الجهاز. سيُعاد تشغيل التطبيق الآن.");
    location.reload();
  };
  const migrateRecords = async () => {
    if (!firebaseServices || !firebaseUser) return alert("سجل الدخول إلى Firebase أولًا.");
    if (!can?.admin && !can?.review) return alert("الترحيل يحتاج مدير أو مشرف.");
    setMigrating(true);
    try {
      const res = await migrateCmmsStateToRecordFirestore(firebaseServices, db, {
        uid: firebaseUser.uid,
        email: firebaseUser.email,
        role,
      });
      setSyncStatus?.("تم ترحيل البيانات إلى مستندات Firestore مستقلة");
      alert("تم ترحيل " + res.records + " سجل إلى مستندات مستقلة داخل Firestore.");
    } catch (e) {
      console.error(e);
      alert("فشل الترحيل. تأكد أن قواعد Firestore الجديدة منشورة وأن حسابك مدير/مشرف.");
    }
    setMigrating(false);
  };
  return (
    <>
      <Section title="Firebase والصلاحيات الخلفية">
        <div style={{ ...card(), borderRightColor: firebaseEnabled ? C.green : C.amber }}>
          <Row main={firebaseEnabled ? "Firebase مفعّل" : "Firebase غير مفعّل على هذا الجهاز"}
            sub={firebaseEnabled ? "Project: " + (firebaseServices?.config?.projectId || "—") + " · الدور الحالي: " + role : "الصق إعدادات Firebase مرة واحدة من التطبيق، أو ابنه بمتغيرات VITE_FIREBASE_*"}
            badge={{ text: firebaseEnabled ? "محمي" : "إعداد مطلوب", color: firebaseEnabled ? C.green : C.amber }} />
        </div>
      </Section>

      {!firebaseEnabled && (
        <Section title="ربط Firebase من الهاتف">
          <div style={card()}>
            <div style={{ fontSize:13, color:C.steel, marginBottom:8 }}>من Firebase Console افتح Project settings ← Web app، ثم انسخ كائن firebaseConfig والصقه هنا. لا تحتاج لإعادة بناء APK إذا استخدمت هذه الطريقة.</div>
            <textarea value={configText} onChange={(e)=>setConfigText(e.target.value)} placeholder={'const firebaseConfig = {\n  apiKey: "...",\n  authDomain: "...",\n  projectId: "...",\n  storageBucket: "...",\n  messagingSenderId: "...",\n  appId: "..."\n};'} style={{ ...inputStyle(), minHeight:180, direction:"ltr", fontFamily:"monospace", fontSize:12 }} />
            <Btn bg={C.green} onClick={saveConfig} style={{ width:"100%", padding:12, marginTop:8 }}>حفظ إعدادات Firebase</Btn>
          </div>
        </Section>
      )}

      {firebaseEnabled && (
        <Section title="الحساب الحالي">
          <div style={card()}>
            <Row main={firebaseUser?.email || "—"} sub={(firebaseProfile?.uid || firebaseUser?.uid || "") + " · " + (firebaseProfile?.isOwner ? "مالك النظام" : "مستخدم")} badge={{ text: role, color: role === "مدير" ? C.green : C.blue }} />
            <div style={{ display:"flex", gap:8, marginTop:10 }}>
              <Btn bg={C.red} onClick={()=>firebaseServices && signOutFirebase(firebaseServices)} style={{ flex:1 }}>تسجيل خروج</Btn>
              <Btn bg={C.steel} onClick={()=>{ clearRuntimeFirebaseConfig(); alert("تم مسح إعدادات Firebase من هذا الجهاز."); location.reload(); }} style={{ flex:1 }}>مسح الربط</Btn>
            </div>
          </div>
        </Section>
      )}

      {firebaseEnabled && (
        <Section title="تخزين Firestore كمستندات مستقلة">
          <div style={{ ...card(), borderRightColor:C.blue }}>
            <Row main="Record-per-document مفعّل" sub="الأصول وأوامر العمل وحركات المخزون والقراءات والفنيون وباقي السجلات تُحفظ في مسار مستقل: cmms/main/records/{entity}/items/{id}." badge={{ text:"Schema v2", color:C.blue }} />
            <div style={{ fontSize:12, color:C.steel, lineHeight:1.8, marginTop:8 }}>
              هذا يقلل خطر حد حجم المستند الواحد، ويسمح بقواعد صلاحيات أدق على مستوى السجل بدل حفظ كل قسم كمصفوفة كبيرة.
            </div>
            {(can?.admin || can?.review) && <Btn bg={C.green} onClick={migrateRecords} style={{ width:"100%", padding:12, marginTop:10 }}>{migrating ? "جارٍ الترحيل…" : "ترحيل/تحديث كل البيانات إلى مستندات مستقلة"}</Btn>}
          </div>
        </Section>
      )}

      <Section title="ما الذي أصبح Backend-Enforced؟">
        <div style={{ ...card(), fontSize:13, color:C.steel, lineHeight:1.8 }}>
          <b style={{ color:C.ink }}>المهم:</b> لم يعد اختيار الدور من القائمة هو مصدر الصلاحية عند تفعيل Firebase. القراءة والكتابة تمر عبر Firebase Auth و Firestore Security Rules. القواعد الموجودة في ملف <b>firestore.rules</b> تمنع المستخدم غير المصرح من كتابة سجلات لا يملكها حتى لو عدّل ملف APK. النسخة الجديدة تحفظ كل سجل في مستند مستقل، وليس كمصفوفة كبيرة داخل مستند واحد.
        </div>
      </Section>
    </>
  );
}

function FirebaseUsersPanel({ ctx }) {
  const { firebaseEnabled, firebaseServices, db, can } = ctx;
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const load = async () => {
    if (!firebaseServices) return;
    setLoading(true); setErr("");
    try { setUsers(await listFirebaseUsers(firebaseServices)); }
    catch (e) { console.error(e); setErr("تعذر تحميل المستخدمين. تأكد أن دورك مدير/مشرف وأن Firestore Rules منشورة."); }
    setLoading(false);
  };
  useEffect(() => { if (firebaseEnabled && can.review) load(); }, [firebaseEnabled, can.review]);
  const patchUser = async (u, patch) => {
    try {
      await updateFirebaseUserProfile(firebaseServices, u.uid, patch);
      await load();
    } catch (e) {
      console.error(e);
      alert("رفض Firebase التعديل. تأكد أن حسابك مدير وأن القواعد منشورة.");
    }
  };
  if (!firebaseEnabled) return <Empty text="فعّل Firebase أولًا من شاشة Firebase والصلاحيات." />;
  if (!can.review) return <Empty text="هذه الشاشة للمدير أو المشرف فقط." />;
  return (
    <>
      <Section title="المستخدمون والصلاحيات">
        <div style={{ ...card(), fontSize:13, color:C.steel }}>أنشئ المستخدم من شاشة تسجيل الدخول، ثم اربطه هنا بدور وفني. دور المدير يستطيع تغيير الأدوار، والمشرف يستطيع القراءة حسب القواعد.</div>
        {err && <div style={{ ...card(), color:C.red }}>{err}</div>}
        <Btn bg={C.blue} onClick={load} style={{ width:"100%", padding:10, marginBottom:8 }}>{loading ? "جارٍ التحميل…" : "تحديث القائمة"}</Btn>
        {users.length === 0 && !loading && <Empty text="لا يوجد مستخدمون بعد." />}
        {users.map((u) => (
          <div key={u.uid} style={card()}>
            <Row main={u.email || u.uid} sub={(u.displayName || "بدون اسم") + " · " + (u.uid || "")} badge={{ text:u.role || "—", color:u.role === "مدير" ? C.green : C.steel }} />
            {can.admin && <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginTop:10 }}>
              <Field label="الدور"><select value={u.role || "طالب خدمة"} onChange={(e)=>patchUser(u, { role:e.target.value })} style={inputStyle()}>{ROLES.map((r)=><option key={r}>{r}</option>)}</select></Field>
              <Field label="ربط بفني"><select value={u.technicianId || ""} onChange={(e)=>patchUser(u, { technicianId:e.target.value })} style={inputStyle()}><option value="">— بدون —</option>{db.technicians.map((t)=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>
            </div>}
          </div>
        ))}
      </Section>
    </>
  );
}

/* ───────────────────────── الرئيسية ───────────────────────── */
function Home({ db, nameOf, programDue, generateWO, setTab, openWO, can }) {
  const open = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status));
  const overdue = open.filter((w) => w.plannedEnd && daysUntil(w.plannedEnd) < 0);
  const pendingReview = db.workOrders.filter((w) => w.status === "بانتظار المراجعة");
  const emergency = open.filter((w) => w.priority === "طارئ" || w.type === "طارئ");
  const newReqs = db.workRequests.filter((r) => r.status === "مفتوح");
  const duePrograms = can.manage ? db.programs.filter((p) => programDue(p).due) : [];
  const soonPrograms = can.manage ? db.programs.filter((p) => { const i = programDue(p); return !i.due && i.soon; }) : [];
  return (
    <>
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <Stat n={emergency.length} label="طارئ" color={emergency.length ? C.red : C.steel} />
        <Stat n={overdue.length} label="متأخر" color={overdue.length ? C.red : C.steel} />
        <Stat n={pendingReview.length} label="بانتظار المراجعة" color={pendingReview.length ? C.blue : C.steel} />
        <Stat n={open.length} label="مفتوح" color={C.ink} />
      </div>

      {soonPrograms.length > 0 && (
        <Section title="⏳ تنبيه: صيانة مستحقة قريبًا">
          {soonPrograms.map((p) => (
            <div key={p.id} style={{ ...card(), borderRightColor: C.amber }}>
              <Row main={p.name} sub={nameOf("assets", p.assetId) + " · " + programDue(p).label} />
            </div>
          ))}
        </Section>
      )}
      {duePrograms.length > 0 && (
        <Section title="برامج وقائية مستحقة">
          {duePrograms.map((p) => (
            <div key={p.id} style={card()}>
              <Row main={p.name} sub={nameOf("assets", p.assetId) + " · " + programDue(p).label}
                action={<Btn bg={C.orange} onClick={() => generateWO(p)}>إنشاء أمر عمل</Btn>} />
            </div>
          ))}
        </Section>
      )}

      <Section title="يحتاج انتباهك">
        {[...emergency, ...overdue, ...pendingReview, ...newReqs].length === 0 && <Empty text="لا شيء عاجل. كل شيء تحت السيطرة." />}
        {emergency.map((w) => (
          <div key={w.id} style={{ ...card(), borderRightColor: C.red }} onClick={() => openWO(w.id)}>
            <Row main={"🚨 " + w.number + " — " + w.title} sub={nameOf("assets", w.assetId)} badge={{ text: w.status, color: WO_COLORS[w.status] }} />
          </div>
        ))}
        {overdue.filter((w) => !emergency.includes(w)).map((w) => (
          <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
            <Row main={w.number + " — " + w.title} sub={"متأخر منذ " + fmt(w.plannedEnd)} badge={{ text: w.status, color: WO_COLORS[w.status] }} />
          </div>
        ))}
        {can.review && pendingReview.map((w) => (
          <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
            <Row main={w.number + " — " + w.title} sub="أكمله الفني — بانتظار اعتمادك" badge={{ text: "راجِع", color: C.blue }} />
          </div>
        ))}
        {newReqs.map((r) => (
          <div key={r.id} style={card()} onClick={() => setTab("requests")}>
            <Row main={"طلب: " + r.title} sub={nameOf("assets", r.assetId) + " · خطورة " + r.severity} badge={{ text: "مفتوح", color: C.amber }} />
          </div>
        ))}
      </Section>
    </>
  );
}

/* ───────────────────────── أعمالي / قائمة الإرسال (وثيقة التنفيذ §2,§5) ───────────────────────── */
function MyWork({ ctx, openWO }) {
  const { db, nameOf, role, myTechId } = ctx;
  const [view, setView] = useState("اليوم");
  const isTech = role === "فني";
  let wos = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status) && !["مسودة", "مُصدر"].includes(w.status));
  /* الفني لا يرى غير المسند إليه (قاعدة) */
  if (isTech && myTechId) wos = wos.filter((w) => (ctx.woAssignedTechIds ? ctx.woAssignedTechIds(w) : (w.operations || []).map((o) => o.assigneeId)).includes(myTechId));
  const VIEWS = {
    "اليوم": (w) => !w.plannedStart || daysUntil(w.plannedStart) <= 0,
    "متأخر": (w) => w.plannedEnd && daysUntil(w.plannedEnd) < 0,
    "طارئ": (w) => w.priority === "طارئ" || w.type === "طارئ",
    "قيد التنفيذ": (w) => w.status === "قيد التنفيذ",
    "بانتظار مواد": (w) => w.status === "بانتظار مواد",
    "مُعاد للتصحيح": (w) => w.status === "مُعاد للتصحيح",
    "بانتظار المراجعة": (w) => w.status === "بانتظار المراجعة",
  };
  const list = wos.filter(VIEWS[view]);
  return (
    <>
      {isTech && !myTechId && <Empty text="اختر اسمك من القائمة في الأعلى لعرض مهامك." />}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
        {Object.keys(VIEWS).map((v) => {
          const n = wos.filter(VIEWS[v]).length;
          return <Chip key={v} active={view === v} onClick={() => setView(v)}>{v}{n > 0 ? " (" + n + ")" : ""}</Chip>;
        })}
      </div>
      {list.length === 0 && <Empty text={"لا مهام في «" + view + "»."} />}
      {list.map((w) => <TaskCard key={w.id} w={w} ctx={ctx} onClick={() => openWO(w.id)} />)}
    </>
  );
}

/* بطاقة المهمة (وثيقة التنفيذ §بطاقة المهمة) */
function TaskCard({ w, ctx, onClick }) {
  const { nameOf, activeWarranty, materialStatusOf, woAssignedTechIds } = ctx;
  const matStatus = materialStatusOf ? "المواد: " + materialStatusOf(w) : ((w.materials || []).length === 0 ? "" :
    (w.materials || []).every((m) => Number(m.issuedQty || 0) > 0) ? "المواد: متوفرة" : "المواد: ناقصة");
  const assignees = (woAssignedTechIds ? woAssignedTechIds(w) : []).map((id) => nameOf("technicians", id)).filter((x) => x !== "—").join("، ");
  return (
    <div style={{ ...card(), borderRightColor: w.priority === "طارئ" ? C.red : C.ink }} onClick={onClick}>
      <Row main={w.number + " — " + w.title} badge={{ text: w.status, color: WO_COLORS[w.status] }}
        sub={[nameOf("assets", w.assetId), w.type, "أولوية " + w.priority,
          w.plannedStart ? "البدء " + fmt(w.plannedStart) : "", assignees ? "الفني: " + assignees : "غير مسند", matStatus,
          w.safetyRequired ? "🔒 سلامة" : "", activeWarranty(w.assetId) ? "🛡 ضمان" : ""].filter(Boolean).join(" · ")} />
      {w.status === "مُعاد للتصحيح" && w.reviewNotes && (
        <div style={{ fontSize: 12.5, color: C.red, marginTop: 4 }}>ملاحظات المشرف: {w.reviewNotes}</div>
      )}
    </div>
  );
}

/* ───────────────────────── أوامر العمل ───────────────────────── */
function WorkOrders({ ctx, openWO }) {
  const { db, nameOf, can, createWO } = ctx;
  const [form, setForm] = useState(false);
  const [filter, setFilter] = useState("الكل");
  const [q, setQ] = useState("");
  const list = db.workOrders.filter((w) =>
    (filter === "الكل" || w.status === filter) && (!q || (w.title + w.number).includes(q)));
  return (
    <>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث…" style={{ ...input, marginBottom: 10 }} />
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
        {["الكل", ...WO_FLOW, ...WO_EXTRA].map((s) => <Chip key={s} active={filter === s} onClick={() => setFilter(s)}>{s}</Chip>)}
      </div>
      {can.manage && <Btn bg={C.orange} onClick={() => setForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ أمر عمل جديد</Btn>}
      {list.length === 0 && <Empty text="لا توجد أوامر عمل هنا." />}
      {list.map((w) => <TaskCard key={w.id} w={w} ctx={ctx} onClick={() => openWO(w.id)} />)}
      {form && (
        <FormSheet title="أمر عمل جديد" onClose={() => setForm(false)} db={db}
          schema={[
            { k: "title", label: "وصف العمل" },
            { k: "assetId", label: "الأصل (إلزامي)", type: "select", from: "assets", fromKey: "name" },
            { k: "type", label: "النوع", type: "select", options: ["تصحيحي", "وقائي", "طارئ"] },
            { k: "priority", label: "الأولوية", type: "select", options: ["منخفضة", "عادية", "عالية", "طارئ"] },
            { k: "workDefId", label: "تعريف العمل (ينسخ عملياته)", type: "select", from: "workDefs", fromKey: "name" },
            { k: "assignedTechnicianId", label: "الفني الرئيسي (مطلوب قبل الإصدار)", type: "select", from: "technicians", fromKey: "name" },
            { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
            { k: "externalSupplier", label: "مورد خارجي عند الحاجة" },
            { k: "plannedStart", label: "البدء المخطط", type: "date" }, { k: "plannedEnd", label: "الانتهاء المخطط", type: "date" },
            { k: "safetyRequired", label: "يتطلب قائمة فحص سلامة (LOTO)", type: "check" },
            { k: "photoRequired", label: "صور قبل/بعد إلزامية", type: "check" },
          ]} initial={{ type: "تصحيحي", priority: "عادية", plannedStart: today(), safetyRequired: true }}
          onSave={(d) => {
            if (!d.assetId) { alert("لا أمر عمل بدون أصل (قاعدة النظام)"); return; }
            createWO(d); setForm(false);
          }} />
      )}
    </>
  );
}

/* ───────────────────────── تفاصيل أمر العمل — قلب التنفيذ ───────────────────────── */
function WODetail({ ctx, woId, onClose, openAsset }) {
  const { db, nameOf, update, can, role, myTechId, woCost, completionGaps, setWOStatus, log, activeWarranty, availableQty, onHand, addTx, woShortages, activeContracts, contractEffectiveEnd, generateEntitlements } = ctx;
  const wo = db.workOrders.find((w) => w.id === woId);
  const [sub, setSub] = useState("عام");
  const [opForm, setOpForm] = useState(false);
  const [matForm, setMatForm] = useState(false);
  const [failForm, setFailForm] = useState(false);
  const [completing, setCompleting] = useState(null);
  const [reviewing, setReviewing] = useState(false);
  const [excText, setExcText] = useState("");
  if (!wo) return null;
  const cost = woCost(wo);
  const gaps = completionGaps(wo);
  const isTech = role === "فني";
  const mineOnly = (op) => !isTech || !myTechId || op.assigneeId === myTechId;
  const aw = activeWarranty(wo.assetId);

  const patchOps = (ops) => update("workOrders", wo.id, { operations: ops });
  const patchLog = (action, extra = {}) => update("workOrders", wo.id, { execLog: log(wo, action), ...extra });

  const TABS = ["عام", "الإسناد", "العمليات", "المواد", "السلامة", "العطل", "الصور", "الضمان", "السجل"];

  return (
    <Sheet title={wo.number} onClose={onClose}>
      <div style={{ marginBottom: 10 }}>
        <div style={{ fontWeight: 800, fontSize: 17 }}>{wo.title}</div>
        <div style={{ fontSize: 13, color: C.steel }}>
          <span style={{ textDecoration: "underline" }} onClick={() => wo.assetId && openAsset(wo.assetId)}>{nameOf("assets", wo.assetId)}</span>
          {" · "}{wo.type} · أولوية {wo.priority} · {fmt(wo.plannedStart)} ← {fmt(wo.plannedEnd)}
        </div>
        {aw && ["تصحيحي", "طارئ"].includes(wo.type) && (
          <div style={{ fontSize: 13, color: C.green, fontWeight: 700, marginTop: 4 }}>
            🛡 الأصل تحت ضمان «{aw.supplier}» حتى {fmt(aw.end)} — راجع الضمان قبل تكلفة إصلاح داخلي
          </div>
        )}
        {cost.total > 0 && <div style={{ fontSize: 13, marginTop: 4 }}>التكلفة: <b>{money(cost.total)}</b> (عمالة {money(cost.labor)} + مواد {money(cost.material)})</div>}

        {/* أزرار الحالة حسب الدور والمرحلة */}
        <div style={{ display: "flex", gap: 6, marginTop: 10, flexWrap: "wrap" }}>
          <Badge text={wo.status} color={WO_COLORS[wo.status]} />
          {wo.status === "مسودة" && can.manage && <Btn bg={C.blue} onClick={() => {
            const sh = woShortages(wo);
            if (sh.length && !confirm("نقص مواد:\n" + sh.map((m) => "• " + nameOf("items", m.itemId) + " (مطلوب " + m.qty + "، المتاح " + Math.max(0, availableQty(m.itemId)) + ")").join("\n") + "\n\nإصدار كـ«بانتظار مواد»؟")) return;
            setWOStatus(wo, sh.length ? "بانتظار مواد" : "مُصدر");
          }}>إصدار (فحص المواد)</Btn>}
          {wo.status === "مُصدر" && can.manage && <Btn bg={C.purple} onClick={() => setWOStatus(wo, "جاهز")}>جاهز للتنفيذ</Btn>}
          {wo.status === "جاهز" && can.execute && (
            <Btn bg={C.green} onClick={() => {
              if (wo.safetyRequired && (wo.checklist || []).some((c) => !c.done)) { alert("لا بدء قبل إكمال قائمة فحص السلامة"); setSub("السلامة"); return; }
              setWOStatus(wo, "قيد التنفيذ", { actualStart: today() });
            }}>▶ بدء العمل</Btn>
          )}
          {wo.status === "قيد التنفيذ" && can.execute && (
            <>
              <Btn bg={C.steel} onClick={() => patchLog("⏸ إيقاف مؤقت")}>⏸ إيقاف</Btn>
              <Btn bg={C.green} onClick={() => {
                if (gaps.length) { alert("لا يمكن طلب الإكمال:\n• " + gaps.join("\n• ")); return; }
                setWOStatus(wo, "بانتظار المراجعة");
              }}>✓ طلب الإكمال</Btn>
            </>
          )}
          {wo.status === "مُعاد للتصحيح" && can.execute && <Btn bg={C.amber} onClick={() => setWOStatus(wo, "قيد التنفيذ")}>استئناف التصحيح</Btn>}
          {wo.status === "بانتظار المراجعة" && can.review && <Btn bg={C.blue} onClick={() => setReviewing(true)}>مراجعة المشرف</Btn>}
          {["جاهز", "قيد التنفيذ"].includes(wo.status) && can.manage && (
            <>
              <Btn bg={C.steel} onClick={() => setWOStatus(wo, "معلق")}>تعليق</Btn>
              <Btn bg={C.amber} onClick={() => setWOStatus(wo, "بانتظار مواد")}>بانتظار مواد</Btn>
            </>
          )}
          {["معلق", "بانتظار مواد"].includes(wo.status) && can.manage && <Btn bg={C.green} onClick={() => setWOStatus(wo, "قيد التنفيذ")}>استئناف</Btn>}
          {!["مغلق", "ملغي"].includes(wo.status) && can.manage && <Btn bg={C.red} onClick={() => setWOStatus(wo, "ملغي")}>إلغاء</Btn>}
        </div>
        {wo.status === "قيد التنفيذ" && gaps.length > 0 && (
          <div style={{ fontSize: 12, color: C.amber, marginTop: 6 }}>قبل الإكمال: {gaps.join(" · ")}</div>
        )}
        {wo.reviewNotes && wo.status === "مُعاد للتصحيح" && (
          <div style={{ fontSize: 13, color: C.red, marginTop: 6, fontWeight: 700 }}>ملاحظات المشرف: {wo.reviewNotes}</div>
        )}
      </div>

      <div style={{ display: "flex", gap: 5, overflowX: "auto", marginBottom: 10 }}>
        {TABS.map((t) => <Chip key={t} active={sub === t} onClick={() => setSub(t)}>{t}</Chip>)}
      </div>

      {sub === "الإسناد" && (
        <Section title="الإسناد والجدولة">
          <div style={card()}>
            <Field label="الفني الرئيسي / Assigned Technician">
              <select value={(wo.assignments || [])[0]?.technicianId || ""} disabled={!can.manage || ["مغلق", "ملغي"].includes(wo.status)} onChange={(e) => {
                const techId = e.target.value;
                const assignments = techId ? [{ id: (wo.assignments || [])[0]?.id || uid(), technicianId: techId, role: "فني رئيسي", status: "مسند", assignedAt: today(), assignedBy: role }] : [];
                update("workOrders", wo.id, {
                  assignments,
                  _cmmsAssignedTechIds: assignments.map((a) => a.technicianId),
                  operations: (wo.operations || []).map((op, i) => i === 0 && techId ? { ...op, assigneeId: techId } : op),
                  execLog: log(wo, "إسناد الفني الرئيسي: " + (techId ? nameOf("technicians", techId) : "إلغاء")),
                });
              }} style={input}>
                <option value="">— غير مسند —</option>
                {db.technicians.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.specialty || "عام"})</option>)}
              </select>
            </Field>
            <Field label="الفريق / Team"><input value={wo.team || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { team:e.target.value, execLog: log(wo, "تحديث الفريق") })} style={input} /></Field>
            <Field label="مركز العمل / Work Center"><select value={wo.workCenterId || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { workCenterId:e.target.value, execLog: log(wo, "تحديث مركز العمل") })} style={input}><option value="">—</option>{db.workCenters.map((wcx)=><option key={wcx.id} value={wcx.id}>{wcx.name}</option>)}</select></Field>
            <Field label="المورد الخارجي / External Supplier"><input value={wo.externalSupplier || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { externalSupplier:e.target.value, execLog: log(wo, "تحديث المورد الخارجي") })} style={input} /></Field>
            <Field label="بداية مخططة"><input type="date" value={wo.plannedStart || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { plannedStart:e.target.value, execLog: log(wo, "تعديل الجدولة") })} style={input} /></Field>
            <Field label="نهاية مخططة"><input type="date" value={wo.plannedEnd || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { plannedEnd:e.target.value, execLog: log(wo, "تعديل تاريخ الاستحقاق") })} style={input} /></Field>
          </div>
        </Section>
      )}

      {/* ───── عام: معاينة العمل ───── */}
      {sub === "عام" && (
        <>
        {(wo.routeAssets || []).length > 0 && (
          <Section title={"أصول المسار (" + wo.routeAssets.filter((x) => x.status !== "معلق").length + "/" + wo.routeAssets.length + ")"}>
            {(() => { const h = db.logicalHierarchies.find((x) => x.id === wo.routeId); return wo.routeAssets.map((x) => {
              const ast = db.assets.find((z) => z.id === x.assetId);
              return (
                <div key={x.assetId} style={{ ...card(), borderRightColor: x.status === "تم" ? C.green : x.status === "تخطي" ? C.amber : C.ink }}>
                  <Row main={(ast?.number ? ast.number + " — " : "") + (ast?.name || "أصل")} sub={ast?.location}
                    badge={{ text: x.status, color: x.status === "تم" ? C.green : x.status === "تخطي" ? C.amber : C.steel }}
                    action={x.status === "معلق" && can.execute && wo.status === "قيد التنفيذ" ? (
                      <div style={{ display: "flex", gap: 4 }}>
                        <Btn bg={C.green} onClick={() => update("workOrders", wo.id, { routeAssets: wo.routeAssets.map((y) => y.assetId === x.assetId ? { ...y, status: "تم" } : y), execLog: log(wo, "مسار: تم — " + (ast?.name || "")) })}>تم</Btn>
                        {(h?.allowSkip) && <Btn bg={C.amber} onClick={() => update("workOrders", wo.id, { routeAssets: wo.routeAssets.map((y) => y.assetId === x.assetId ? { ...y, status: "تخطي" } : y), execLog: log(wo, "مسار: تخطي — " + (ast?.name || "")) })}>تخطي</Btn>}
                      </div>
                    ) : null} />
                </div>
              );
            }); })()}
          </Section>
        )}
          <Section title="معاينة العمل">
            <div style={card()}>
              <div style={{ fontSize: 13.5, lineHeight: 1.9 }}>
                الأصل: <b>{nameOf("assets", wo.assetId)}</b><br />
                آخر صيانة لهذا الأصل: <b>{(() => {
                  const prev = db.workOrders.filter((x) => x.assetId === wo.assetId && x.id !== wo.id && x.status === "مغلق").slice(-1)[0];
                  return prev ? prev.completedAt + " (" + prev.title + ")" : "لا يوجد";
                })()}</b><br />
                السلامة: <b>{wo.safetyRequired ? "تصريح عزل طاقة مطلوب" : "غير مطلوب"}</b> ·
                الصور: <b>{wo.photoRequired ? "قبل/بعد إلزامية" : "اختيارية"}</b>
              </div>
            </div>
          </Section>
          <Section title="ملاحظات الإكمال والنتيجة">
            <textarea value={wo.executionNotes || ""} disabled={!can.execute || ["مغلق", "ملغي"].includes(wo.status)} onChange={(e)=>update("workOrders", wo.id, { executionNotes:e.target.value, execLog: log(wo, "إضافة/تحديث ملاحظة تنفيذ") })} placeholder="اكتب نتيجة الفحص، Trial run result، أو ملاحظات الفني قبل طلب الإكمال…" style={{ ...input, minHeight:80, resize:"vertical" }} />
          </Section>
          <Section title={"الاستثناءات (" + (wo.exceptions || []).length + ")"}>
            {(wo.exceptions || []).map((e, i) => (
              <div key={i} style={{ ...card(), borderRightColor: C.amber }}><Row main={e.text} sub={e.at} /></div>
            ))}
            {can.execute && (
              <div style={{ display: "flex", gap: 8 }}>
                <input value={excText} onChange={(e) => setExcText(e.target.value)} placeholder="نقص مادة، عدم توفر فني…" style={input} />
                <Btn bg={C.amber} onClick={() => { if (excText.trim()) { update("workOrders", wo.id, { exceptions: [...(wo.exceptions || []), { text: excText, at: today() }], execLog: log(wo, "استثناء: " + excText) }); setExcText(""); } }}>تسجيل</Btn>
              </div>
            )}
          </Section>
        </>
      )}

      {/* ───── العمليات ───── */}
      {sub === "العمليات" && (
        <Section title={"العمليات (" + wo.operations.length + ")"}>
          {wo.operations.slice().sort((a, b) => a.seq - b.seq).map((op) => (
            <div key={op.id} style={{ ...card(), opacity: mineOnly(op) ? 1 : 0.55 }}>
              <Row main={op.seq + " — " + op.name + (op.opType === "خارجية" ? " (خارجية)" : "")}
                sub={[op.opType === "خارجية" ? "المورد: " + (op.supplier || "—") : (op.assigneeId ? "الفني: " + nameOf("technicians", op.assigneeId) : "غير مُسند"),
                  op.chargeType ? "تحميل " + op.chargeType : "",
                  op.status === "مكتملة" ? op.actualHours + " ساعة فعلية" : op.minutes ? op.minutes + " د مخطط" : ""].filter(Boolean).join(" · ")}
                action={op.status === "مكتملة"
                  ? <Badge text="مكتملة" color={C.green} />
                  : wo.status === "قيد التنفيذ" && can.execute && mineOnly(op)
                    ? <Btn bg={C.green} onClick={() => setCompleting(op)}>إكمال</Btn> : null} />
              {(op.attachments || []).length > 0 && (
                <div style={{ display: "flex", gap: 8, marginTop: 4, flexWrap: "wrap" }}>
                  {(op.attachments || []).map((a) => a.type === "رابط" && a.value
                    ? <button key={a.id} onClick={(e) => { e.stopPropagation(); window.open(a.value, "_blank"); }} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>🔗 {a.name}</button>
                    : <span key={a.id} style={{ fontSize: 12, color: C.steel }}>📝 {a.name}{a.value ? ": " + a.value : ""}</span>)}
                </div>
              )}
              {(op.repairReason || op.workDone || op.repairTx) && (
                <div style={{ fontSize: 12, color: C.steel, marginTop: 2 }}>أكواد الإصلاح: {[op.repairReason, op.repairTx, op.workDone].filter(Boolean).join(" / ")}</div>
              )}
              {op.status !== "مكتملة" && can.manage && (
                <select value={op.assigneeId || ""} onChange={(e) => {
                  patchOps(wo.operations.map((o) => o.id === op.id ? { ...o, assigneeId: e.target.value } : o));
                }} style={{ ...input, marginTop: 6, padding: "6px 10px", fontSize: 13 }}>
                  <option value="">— إسناد لفني —</option>
                  {db.technicians.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.specialty || "عام"})</option>)}
                </select>
              )}
            </div>
          ))}
          {["مسودة", "مُصدر"].includes(wo.status) && can.manage && <Btn bg={C.ink} onClick={() => setOpForm(true)} style={{ width: "100%" }}>+ إضافة عملية</Btn>}
        </Section>
      )}

      {/* ───── المواد: صرف ← استخدام ← إرجاع (وثيقة التنفيذ §8) ───── */}
      {sub === "المواد" && (
        <Section title="المواد — مطلوب ← حجز ← تجهيز ← صرف ← استخدام ← إرجاع">
          {(wo.materials || []).length === 0 && <Empty text="أضف المواد المطلوبة من ماستر الأصناف — لا صرف بدون أمر عمل." />}
          {(wo.materials || []).map((m) => {
            const issued = Number(m.issuedQty || 0);
            const ret = Math.max(0, issued - Number(m.usedQty || 0));
            const av = m.itemId ? availableQty(m.itemId) + (m.reserved && !issued ? Number(m.qty || 0) : 0) : null;
            const stage = issued ? (m.returned ? "أُرجع الفائض" : "مصروف") : m.picked ? "جاهز للصرف" : m.reserved ? "محجوز" : "مطلوب";
            return (
              <div key={m.id} style={{ ...card(), borderRightColor: issued ? C.green : m.reserved ? C.blue : C.ink }}>
                <Row main={(m.itemId ? nameOf("items", m.itemId) : m.name) + " ×" + (m.qty || m.issuedQty)}
                  badge={{ text: stage, color: issued ? C.green : m.picked ? C.purple : m.reserved ? C.blue : C.steel }}
                  sub={[m.itemId && !issued ? "المتاح: " + Math.max(0, av) : "", issued ? "مصروف " + issued + " × " + money(m.unitCost) : ""].filter(Boolean).join(" · ")} />
                {/* مخزن: حجز ← تأكيد تجهيز ← صرف */}
                {!issued && !["مغلق", "ملغي"].includes(wo.status) && (
                  <div style={{ display: "flex", gap: 6, marginTop: 6, flexWrap: "wrap" }}>
                    {!m.reserved && m.itemId && can.warehouse && (
                      <Btn bg={C.blue} onClick={() => {
                        if (Number(m.qty || 0) > availableQty(m.itemId)) { alert("المتاح غير كافٍ (" + Math.max(0, availableQty(m.itemId)) + ") — حدّث الرصيد باستلام أو خفّض الكمية"); return; }
                        update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, reserved: true } : x), execLog: log(wo, "حجز: " + nameOf("items", m.itemId) + " ×" + m.qty) });
                      }}>حجز</Btn>
                    )}
                    {m.reserved && !m.picked && can.warehouse && (
                      <Btn bg={C.purple} onClick={() => update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, picked: true } : x), execLog: log(wo, "تأكيد تجهيز: " + nameOf("items", m.itemId)) })}>تأكيد التجهيز</Btn>
                    )}
                    {m.reserved && m.picked && can.warehouse && (
                      <Btn bg={C.green} onClick={() => {
                        const item = db.items.find((i) => i.id === m.itemId);
                        addTx({ type: "صرف لأمر عمل", itemId: m.itemId, qty: Number(m.qty || 0), workOrderId: wo.id });
                        update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, issuedQty: Number(m.qty || 0), unitCost: Number(item?.unitCost || 0), usedQty: "" } : x), execLog: log(wo, "صرف: " + nameOf("items", m.itemId) + " ×" + m.qty) });
                      }}>صرف للأمر</Btn>
                    )}
                    {can.manage && <Btn bg={C.red} onClick={() => update("workOrders", wo.id, { materials: wo.materials.filter((x) => x.id !== m.id) })}>إزالة</Btn>}
                  </div>
                )}
                {/* فني: تأكيد المستخدم ← إرجاع الفائض */}
                {issued > 0 && (
                  <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 6, flexWrap: "wrap" }}>
                    <span style={{ fontSize: 13 }}>المستخدم فعليًا:</span>
                    <input type="number" value={m.usedQty ?? ""} disabled={!can.execute || m.returned || ["مغلق", "ملغي"].includes(wo.status)}
                      onChange={(e) => update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, usedQty: e.target.value } : x) })}
                      style={{ ...input, width: 80, padding: "6px 10px" }} />
                    <span style={{ fontSize: 12.5, color: C.steel }}>يُرجَع: {ret} · التكلفة: {money(Number(m.usedQty || 0) * Number(m.unitCost || 0))}</span>
                    {!m.returned && ret > 0 && m.usedQty !== "" && m.usedQty != null && can.warehouse && (
                      <Btn bg={C.amber} onClick={() => {
                        addTx({ type: "إرجاع من أمر عمل", itemId: m.itemId, qty: ret, workOrderId: wo.id });
                        update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, returned: true } : x), execLog: log(wo, "إرجاع فائض: ×" + ret) });
                      }}>إرجاع الفائض للمخزن</Btn>
                    )}
                  </div>
                )}
              </div>
            );
          })}
          {can.manage && !["مغلق", "ملغي"].includes(wo.status) && db.items.length > 0 && (
            <Btn bg={C.ink} onClick={() => setMatForm(true)} style={{ width: "100%" }}>+ مادة مطلوبة (من الأصناف)</Btn>
          )}
          {db.items.length === 0 && <div style={{ fontSize: 12.5, color: C.steel, marginTop: 6 }}>أنشئ الأصناف أولًا من «المخزون ← الأصناف».</div>}
        </Section>
      )}

      {/* ───── السلامة (وثيقة التنفيذ §4) ───── */}
      {sub === "السلامة" && (
        <Section title="قائمة فحص السلامة">
          {!wo.safetyRequired && (wo.checklist || []).length === 0 && <Empty text="هذا الأمر لا يتطلب قائمة سلامة." />}
          {(wo.checklist || []).map((c) => (
            <label key={c.id} style={{ ...card(), display: "flex", gap: 10, alignItems: "center" }}>
              <input type="checkbox" checked={c.done} disabled={!can.execute || ["مغلق", "ملغي"].includes(wo.status)}
                onChange={(e) => update("workOrders", wo.id, {
                  checklist: wo.checklist.map((x) => x.id === c.id ? { ...x, done: e.target.checked } : x),
                  execLog: log(wo, (e.target.checked ? "✓ " : "✗ ") + c.text),
                })}
                style={{ width: 22, height: 22 }} />
              <span style={{ fontSize: 14.5, textDecoration: c.done ? "line-through" : "none" }}>{c.text}</span>
            </label>
          ))}
          {can.manage && !["مغلق", "ملغي"].includes(wo.status) && (
            <AddInline placeholder="بند فحص إضافي…" onAdd={(t) =>
              update("workOrders", wo.id, { checklist: [...(wo.checklist || []), { id: uid(), text: t, done: false }] })} />
          )}
        </Section>
      )}

      {/* ───── العطل (وثيقة التنفيذ §10) ───── */}
      {sub === "العطل" && (
        <Section title="تسجيل العطل">
          {["تصحيحي", "طارئ"].includes(wo.type) && !wo.failure &&
            <div style={{ fontSize: 13, color: C.red, marginBottom: 8 }}>⚠ إلزامي قبل الإكمال لأوامر التصحيح والطوارئ.</div>}
          {wo.failure ? (
            <div style={{ ...card(), borderRightColor: C.red }}>
              <div style={{ fontSize: 14, lineHeight: 2 }}>
                <b>نمط العطل:</b> {wo.failure.mode}{wo.failure.repeated ? " (متكرر ⚠)" : ""}<br />
                <b>السبب:</b> {wo.failure.cause}<br />
                <b>الأثر:</b> {wo.failure.effect}<br />
                <b>الإجراء المتخذ:</b> {wo.failure.action}<br />
                <b>زمن التوقف:</b> {wo.failure.downtime} دقيقة<br />
                {wo.failure.rootCause && <><b>السبب الجذري:</b> {wo.failure.rootCause}</>}
              </div>
              {can.execute && !["مغلق", "ملغي"].includes(wo.status) && <Btn bg={C.blue} onClick={() => setFailForm(true)} style={{ marginTop: 8 }}>تعديل</Btn>}
            </div>
          ) : (
            can.execute && !["مغلق", "ملغي"].includes(wo.status)
              ? <Btn bg={C.red} onClick={() => setFailForm(true)} style={{ width: "100%", padding: 12 }}>+ تسجيل عطل</Btn>
              : <Empty text="لا عطل مسجل." />
          )}
        </Section>
      )}

      {/* ───── الصور (وثيقة التنفيذ §11) ───── */}
      {sub === "الصور" && <PhotosTab ctx={ctx} wo={wo} />}

      {/* ───── سجل التنفيذ والحالات ───── */}
      {/* ───── ضمان المورد (ف6 §22) ───── */}
      {sub === "الضمان" && (() => {
        const cs = activeContracts(wo.assetId);
        const woEnts = db.entitlements.filter((e) => e.workOrderId === wo.id);
        const woClaims = db.claims.filter((c) => c.workOrderId === wo.id);
        return (<>
          {can.manage && (
            <div style={{ ...card(), display: "flex", gap: 16, flexWrap: "wrap" }}>
              <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <input type="checkbox" checked={!!wo.warrantyRepair} disabled={["مغلق", "ملغي"].includes(wo.status) && woEnts.length > 0}
                  onChange={(e) => update("workOrders", wo.id, { warrantyRepair: e.target.checked, execLog: log(wo, "إصلاح ضمان: " + (e.target.checked ? "نعم" : "لا")) })} style={{ width: 20, height: 20 }} />
                <span style={{ fontSize: 14 }}>إصلاح ضمان</span>
              </label>
              <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <input type="checkbox" checked={!!wo.matchCodes}
                  onChange={(e) => update("workOrders", wo.id, { matchCodes: e.target.checked })} style={{ width: 20, height: 20 }} />
                <span style={{ fontSize: 14 }}>مطابقة أكواد الإصلاح</span>
              </label>
            </div>
          )}
          <Section title={"العقود الفعالة للأصل وأصوله المرتبطة (" + cs.length + ")"}>
            {cs.length === 0 && <Empty text="لا عقود فعالة — وجود الأيقونة 🛡 لا يعني تغطية نهائية؛ القرار حسب الشروط والأكواد." />}
            {cs.map((c) => (
              <div key={c.id} style={{ ...card(), borderRightColor: C.green }}>
                <Row main={c.number + " — " + nameOf("coverages", c.coverageId)}
                  sub={[nameOf("assets", c.assetId) !== nameOf("assets", wo.assetId) ? "أصل مرتبط: " + nameOf("assets", c.assetId) : "",
                    "ينتهي " + fmt(contractEffectiveEnd(c))].filter(Boolean).join(" · ")} />
              </div>
            ))}
          </Section>
          {can.manage && ["بانتظار المراجعة", "مغلق"].includes(wo.status) && (
            <Btn bg={C.purple} style={{ width: "100%", padding: 12, marginBottom: 12 }} onClick={() => generateEntitlements(wo)}>
              ⚙ توليد استحقاقات الضمان وتجميعها في مطالبة
            </Btn>
          )}
          {wo.status !== "مغلق" && wo.status !== "بانتظار المراجعة" && (
            <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 10 }}>يفضّل توليد الاستحقاقات بعد إكمال الأمر واكتمال التكلفة (قاعدة ف6).</div>
          )}
          <Section title={"استحقاقات هذا الأمر (" + woEnts.length + ")"}>
            {woEnts.map((e) => (
              <div key={e.id} style={{ ...card(), borderRightColor: e.included ? C.green : C.steel }}>
                <Row main={e.type + " — " + e.description} badge={e.included ? { text: "ضمن مطالبة", color: C.green } : { text: "مستبعد", color: C.steel }}
                  sub={e.qty + " × " + money(e.unitCost) + " = " + money(e.total)} />
              </div>
            ))}
            {woEnts.length === 0 && <Empty text="لا استحقاقات بعد." />}
          </Section>
          {woClaims.length > 0 && (
            <Section title="مطالبات هذا الأمر">
              {woClaims.map((c) => (
                <div key={c.id} style={card()}>
                  <Row main={c.number + " — " + nameOf("warrantyProviders", c.providerId)}
                    badge={{ text: c.status, color: { "قيد المراجعة": C.amber, "مُقدمة": C.blue, "محلولة": C.green, "مرفوضة": C.red }[c.status] || C.steel }}
                    sub="تُدار من: المزيد ← الضمانات ← المطالبات" />
                </div>
              ))}
            </Section>
          )}
        </>);
      })()}

      {sub === "السجل" && (
        <>
          <Section title="سجل التنفيذ (Audit)">
            {(wo.execLog || []).slice().reverse().map((h, i) => (
              <div key={i} style={{ fontSize: 13, color: C.steel, marginBottom: 4, borderBottom: `1px dashed ${C.line}`, paddingBottom: 4 }}>
                <b style={{ color: C.ink }}>{h.action}</b> — {h.at} — {h.by}
              </div>
            ))}
          </Section>
          <Section title="سجل الحالات">
            {(wo.history || []).map((h, i) => (
              <div key={i} style={{ fontSize: 13, color: C.steel, marginBottom: 3 }}>
                {h.at} — {h.from ? h.from + " ← " : ""}<b style={{ color: C.ink }}>{h.to}</b>
              </div>
            ))}
          </Section>
        </>
      )}

      {/* نوافذ فرعية */}
      {opForm && (
        <FormSheet title="إضافة عملية" onClose={() => setOpForm(false)} db={db}
          schema={[
            { k: "seq", label: "التسلسل", type: "number" }, { k: "name", label: "اسم العملية" },
            { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
            { k: "minutes", label: "الدقائق المخططة", type: "number" },
            { k: "assigneeId", label: "الفني", type: "select", from: "technicians", fromKey: "name" },
          ]} initial={{ seq: (wo.operations.length + 1) * 10 }}
          onSave={(d) => { patchOps([...wo.operations, { id: uid(), status: "معلقة", actualHours: 0, ...d }]); setOpForm(false); }} />
      )}
      {matForm && (
        <FormSheet title="مادة مطلوبة" onClose={() => setMatForm(false)} db={db}
          schema={[
            { k: "itemId", label: "الصنف (لا قطعة غيار بدون ماستر الأصناف)", type: "select", from: "items", fromLabel: (i) => i.code + " — " + i.name + " (متاح " + Math.max(0, availableQty(i.id)) + ")" },
            { k: "qty", label: "الكمية المطلوبة", type: "number" },
          ]} initial={{ qty: 1 }}
          onSave={(d) => {
            if (!d.itemId) { alert("اختر الصنف"); return; }
            update("workOrders", wo.id, { materials: [...(wo.materials || []), { id: uid(), ...d, reserved: false, picked: false, issuedQty: 0, usedQty: "", returned: false, unitCost: Number(db.items.find((i) => i.id === d.itemId)?.unitCost || 0) }], execLog: log(wo, "مادة مطلوبة: " + nameOf("items", d.itemId) + " ×" + d.qty) });
            setMatForm(false);
          }} />
      )}
      {failForm && (
        <FormSheet title="بيانات العطل" onClose={() => setFailForm(false)} db={db}
          schema={[
            { k: "mode", label: "نمط العطل", type: "select", options: FAILURE_MODES },
            { k: "cause", label: "السبب" }, { k: "effect", label: "الأثر (توقف الخط…)" },
            { k: "action", label: "الإجراء المتخذ" },
            { k: "downtime", label: "زمن التوقف (دقيقة)", type: "number" },
            { k: "rootCause", label: "السبب الجذري", type: "textarea" },
            { k: "repeated", label: "عطل متكرر؟", type: "check" },
          ]} initial={wo.failure || { mode: FAILURE_MODES[0] }}
          onSave={(d) => { update("workOrders", wo.id, { failure: d, execLog: log(wo, "تسجيل عطل: " + d.mode) }); setFailForm(false); }} />
      )}
      {completing && <CompleteOpSheet ctx={ctx} wo={wo} op={completing} onClose={() => setCompleting(null)}
        onComplete={(d) => {
          patchOps(wo.operations.map((o) => o.id === completing.id
            ? { ...o, status: "مكتملة", completedAt: today(), actualHours: Number(d.hours || 0) } : o));
          setCompleting(null);
        }} />}
      {reviewing && <ReviewSheet ctx={ctx} wo={wo} onClose={() => setReviewing(false)} />}
    </Sheet>
  );
}

/* مراجعة المشرف (وثيقة التنفيذ §13): اعتماد / رفض / أمر متابعة */
function ReviewSheet({ ctx, wo, onClose }) {
  const { db, nameOf, setWOStatus, createWO, woCost } = ctx;
  const [notes, setNotes] = useState("");
  const hours = (wo.operations || []).reduce((s, o) => s + Number(o.actualHours || 0), 0);
  return (
    <Sheet title={"مراجعة " + wo.number} onClose={onClose}>
      <div style={{ ...card(), fontSize: 13.5, lineHeight: 2 }}>
        <b>قائمة السلامة:</b> {(wo.checklist || []).every((c) => c.done) ? "✓ مكتملة" : "✗ ناقصة"}<br />
        <b>العمليات:</b> {(wo.operations || []).filter((o) => o.status === "مكتملة").length}/{(wo.operations || []).length} مكتملة<br />
        <b>ساعات العمل:</b> {hours} ساعة<br />
        <b>المواد المستخدمة:</b> {(wo.materials || []).map((m) => m.name + " ×" + (m.usedQty || 0)).join("، ") || "لا شيء"}<br />
        <b>العطل:</b> {wo.failure ? wo.failure.mode + " — " + wo.failure.cause : "غير مسجل"}<br />
        <b>الصور:</b> {(wo.photos || []).length} صورة<br />
        <b>التكلفة:</b> {money(woCost(wo).total)}
      </div>
      <Field label="ملاحظات المراجعة">
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} style={{ ...input, resize: "vertical" }} />
      </Field>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <Btn bg={C.green} style={{ padding: 13, fontSize: 15 }} onClick={() => { setWOStatus(wo, "مغلق", { reviewNotes: notes, supervisorApproved: true }); onClose(); }}>
          ✓ اعتماد وإغلاق نهائي
        </Btn>
        <Btn bg={C.red} style={{ padding: 13 }} onClick={() => {
          if (!notes.trim()) { alert("اكتب سبب الرفض للفني"); return; }
          setWOStatus(wo, "مُعاد للتصحيح", { reviewNotes: notes }); onClose();
        }}>✗ رفض — إعادة للفني مع ملاحظات</Btn>
        <Btn bg={C.purple} style={{ padding: 13 }} onClick={() => {
          createWO({ title: "متابعة — " + wo.title, assetId: wo.assetId, type: "تصحيحي", priority: "عالية",
            plannedStart: today(), safetyRequired: true, followUpOf: wo.number });
          setWOStatus(wo, "مغلق", { reviewNotes: (notes ? notes + " · " : "") + "أُنشئ أمر متابعة", supervisorApproved: true }); onClose();
        }}>+ اعتماد مع أمر متابعة لعطل جديد</Btn>
      </div>
    </Sheet>
  );
}

/* تبويب الصور: قبل / أثناء / بعد / عطل / قطعة غيار */
function PhotosTab({ ctx, wo }) {
  const { update, can, log } = ctx;
  const [type, setType] = useState("قبل");
  const TYPES = EXECUTION_PHOTO_TYPES;
  const addPhoto = async (file) => {
    try {
      const data = await resizeImage(file);
      update("workOrders", wo.id, { photos: [...(wo.photos || []), { id: uid(), type, data, at: today() }], execLog: log(wo, "صورة " + type) });
    } catch (e) { alert("تعذر معالجة الصورة"); }
  };
  return (
    <Section title={"الصور (" + (wo.photos || []).length + ")" + (wo.photoRequired ? " — قبل/بعد إلزامية" : "")}>
      {can.execute && !["مغلق", "ملغي"].includes(wo.status) && (
        <div style={{ ...card() }}>
          <div style={{ display: "flex", gap: 5, marginBottom: 8, flexWrap: "wrap" }}>
            {TYPES.map((t) => <Chip key={t} active={type === t} onClick={() => setType(t)}>{t}</Chip>)}
          </div>
          <input type="file" accept="image/*" capture="environment" onChange={(e) => e.target.files[0] && addPhoto(e.target.files[0])} style={{ fontSize: 14 }} />
          <div style={{ fontSize: 11.5, color: C.steel, marginTop: 4 }}>تُضغط الصور تلقائيًا للحفاظ على مساحة التخزين.</div>
        </div>
      )}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {(wo.photos || []).map((p) => (
          <div key={p.id} style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, overflow: "hidden", background: "#fff" }}>
            <img src={p.data} alt={p.type} style={{ width: "100%", display: "block" }} />
            <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 8px", fontSize: 12 }}>
              <b>{p.type}</b><span style={{ color: C.steel }}>{fmt(p.at)}</span>
              {can.execute && <button onClick={() => update("workOrders", wo.id, { photos: wo.photos.filter((x) => x.id !== p.id) })} style={{ ...delBtn, marginTop: 0 }}>حذف</button>}
            </div>
          </div>
        ))}
      </div>
      {(wo.photos || []).length === 0 && <Empty text="لا صور بعد." />}
    </Section>
  );
}

function CompleteOpSheet({ ctx, wo, op, onClose, onComplete }) {
  const { db, nameOf, addReading, currentValue, pmCheckAfterReading } = ctx;
  const [hours, setHours] = useState(op.minutes ? (op.minutes / 60).toFixed(1) : "1");
  const meters = db.assetMeters.filter((m) => m.assetId === wo.assetId && (!m.endDate || m.endDate >= today()));
  const isMand = (m) => (m.recordAtWO || db.meterTemplates.find((t) => t.id === m.templateId)?.recordAtWO) === "إلزامي";
  const mandPending = meters.filter((m) => isMand(m) && !db.readings.some((r) => r.workOrderId === wo.id && r.assetMeterId === m.id && !["معطلة", "ملغاة"].includes(r.status)));
  const [meterId, setMeterId] = useState(""); const [meterVal, setMeterVal] = useState(""); const [err, setErr] = useState("");
  return (
    <Sheet title={"إكمال: " + op.name} onClose={onClose}>
      <Field label="الساعات الفعلية"><input type="number" step="0.5" value={hours} onChange={(e) => setHours(e.target.value)} style={input} /></Field>
      {mandPending.length > 0 && (
        <div style={{ fontSize: 12.5, color: C.red, marginBottom: 8 }}>
          ⚠ عدادات إلزامية لم تُسجّل بعد: {mandPending.map((m) => nameOf("meterTemplates", m.templateId)).join("، ")} — لن يُقبل طلب الإكمال بدونها.
        </div>
      )}
      {meters.length > 0 && (
        <>
          <Field label="قراءة عداد عند الإكمال">
            <select value={meterId} onChange={(e) => { setMeterId(e.target.value); setErr(""); }} style={input}>
              <option value="">— بدون —</option>
              {meters.map((m) => <option key={m.id} value={m.id}>{(isMand(m) ? "⚠ إلزامي — " : "") + nameOf("meterTemplates", m.templateId)} (المعروض: {currentValue(m)})</option>)}
            </select>
          </Field>
          {meterId && <Field label="القراءة الجديدة"><input type="number" value={meterVal} onChange={(e) => setMeterVal(e.target.value)} style={input} /></Field>}
        </>
      )}
      {err && <div style={{ color: C.red, fontSize: 13, marginBottom: 8 }}>⚠ {err}</div>}
      <Btn bg={C.green} style={{ width: "100%", padding: 13, fontSize: 15 }} onClick={() => {
        if (meterId && meterVal !== "") {
          const am = db.assetMeters.find((m) => m.id === meterId);
          const alerts = pmCheckAfterReading(am, meterVal);
          const e = addReading(am, meterVal, today(), { source: "أمر عمل", workOrderId: wo.id });
          if (e) { setErr(e); return; }
          if (alerts.length) alert(alerts.map((x) => x.msg).join("\n"));
        }
        onComplete({ hours });
      }}>تأكيد إكمال العملية</Btn>
    </Sheet>
  );
}

/* ───────────────────────── تحليل الأعطال (Failure Analysis + MTTR) ───────────────────────── */
function FailureAnalysis({ ctx, openWO }) {
  const { db, nameOf } = ctx;
  const failures = db.workOrders.filter((w) => w.failure).map((w) => ({ wo: w, f: w.failure }));
  const mttr = failures.length ? Math.round(failures.reduce((s, x) => s + Number(x.f.downtime || 0), 0) / failures.length) : 0;
  const totalDowntime = failures.reduce((s, x) => s + Number(x.f.downtime || 0), 0);
  /* الأعطال المتكررة: نفس النمط على نفس الأصل أكثر من مرة */
  const repeatMap = {};
  failures.forEach(({ wo, f }) => { const k = (wo.assetId || "؟") + "|" + f.mode; repeatMap[k] = (repeatMap[k] || 0) + 1; });
  const repeated = Object.entries(repeatMap).filter(([, n]) => n > 1)
    .map(([k, n]) => { const [assetId, mode] = k.split("|"); return { asset: nameOf("assets", assetId), mode, n }; });
  /* أكثر الأصول مشاكل (وثيقة الأصول §Top Problem Assets) */
  const probMap = {};
  failures.forEach(({ wo }) => { probMap[wo.assetId] = (probMap[wo.assetId] || 0) + 1; });
  const topProblem = Object.entries(probMap).map(([id, n]) => ({ name: nameOf("assets", id), n })).sort((a, b) => b.n - a.n).slice(0, 5);
  return (
    <>
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <Stat n={failures.length} label="أعطال مسجلة" color={C.red} />
        <Stat n={mttr + " د"} label="MTTR متوسط الإصلاح" color={C.amber} small />
        <Stat n={totalDowntime + " د"} label="إجمالي التوقف" color={C.ink} small />
      </div>
      {topProblem.length > 0 && (
        <Section title="أكثر الأصول مشاكل">
          <div style={card()}>
            {topProblem.map((x) => (
              <div key={x.name} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4 }}>
                <span>{x.name}</span><b style={{ color: C.red }}>{x.n} عطل</b>
              </div>
            ))}
          </div>
        </Section>
      )}
      {repeated.length > 0 && (
        <Section title="⚠ أعطال متكررة — تحتاج سببًا جذريًا">
          {repeated.map((r, i) => (
            <div key={i} style={{ ...card(), borderRightColor: C.red }}>
              <Row main={r.mode + " — " + r.asset} sub={"تكرر " + r.n + " مرات"} />
            </div>
          ))}
        </Section>
      )}
      <Section title="سجل الأعطال">
        {failures.length === 0 && <Empty text="لا أعطال مسجلة بعد — تُسجّل من داخل أمر العمل (تبويب العطل)." />}
        {failures.slice().reverse().map(({ wo, f }) => (
          <div key={wo.id} style={card()} onClick={() => openWO(wo.id)}>
            <Row main={f.mode + " — " + nameOf("assets", wo.assetId)}
              sub={[f.cause, f.downtime + " د توقف", wo.number].join(" · ")}
              badge={f.repeated ? { text: "متكرر", color: C.red } : undefined} />
          </div>
        ))}
      </Section>
    </>
  );
}


/* ───────────────────────── إدارة الصيانة الشاملة — حسب المتطلبات ───────────────────────── */
function MaintenanceManagementHub({ ctx, openWO, setTab }) {
  const { db, save, can, nameOf, programDue, generateWO, woAssignedTechIds, materialStatusOf } = ctx;
  const [sub, setSub] = useState("الملخص");
  const open = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status));
  const todayWos = open.filter((w) => !w.plannedStart || daysUntil(w.plannedStart) <= 0);
  const pastDue = open.filter((w) => w.plannedEnd && daysUntil(w.plannedEnd) < 0);
  const waitingMat = open.filter((w) => w.status === "بانتظار مواد" || (materialStatusOf && materialStatusOf(w) === "Waiting Material"));
  const pendingReview = open.filter((w) => w.status === "بانتظار المراجعة");
  const emergency = open.filter((w) => w.priority === "طارئ" || w.type === "طارئ");
  const rejected = db.workOrders.filter((w) => w.status === "مُعاد للتصحيح");
  const seedDemo = () => {
    const next = normalizeDb(db);
    const getOrAdd = (key, pred, maker) => { let row = next[key].find(pred); if (!row) { row = { id: uid(), ...maker() }; next[key] = [...next[key], row]; } return row; };
    const org = getOrAdd("maintenanceOrganizations", (x) => x.code === "MAIN", () => ({ code:"MAIN", name:"Main Maintenance Organization", status:"عاملة", isMaintenanceEnabled:true }));
    const area = getOrAdd("workAreas", (x) => x.code === "MILL", () => ({ organizationId:org.id, code:"MILL", name:"Mill Maintenance Area" }));
    const wcMech = getOrAdd("workCenters", (x) => x.code === "MECH", () => ({ organizationId:org.id, workAreaId:area.id, code:"MECH", name:"Mechanical Workshop" }));
    const wcElec = getOrAdd("workCenters", (x) => x.code === "ELEC", () => ({ organizationId:org.id, workAreaId:area.id, code:"ELEC", name:"Electrical Workshop" }));
    getOrAdd("resources", (x) => x.code === "LAB-MECH", () => ({ code:"LAB-MECH", name:"Mechanical Technician", type:"عمالة", usageUom:"ساعة", workCenterId:wcMech.id, qty:4, available24h:false }));
    getOrAdd("resources", (x) => x.code === "LAB-ELEC", () => ({ code:"LAB-ELEC", name:"Electrical Technician", type:"عمالة", usageUom:"ساعة", workCenterId:wcElec.id, qty:3, available24h:false }));
    const ahmed = getOrAdd("technicians", (x) => x.name === "Ahmed", () => ({ name:"Ahmed", specialty:"ميكانيكي", workCenterId:wcMech.id, rate:50 }));
    const ali = getOrAdd("technicians", (x) => x.name === "Ali", () => ({ name:"Ali", specialty:"كهربائي", workCenterId:wcElec.id, rate:55 }));
    const ela = getOrAdd("assets", (x) => x.number === "ELA-01", () => ({ number:"ELA-01", name:"Bucket Elevator ELA-01", type:"معدات", location:"Mill / Elevator Line", locationType:"WORK_CENTER", workCenterId:wcMech.id, ownership:"مؤسسة", active:true, allowWO:true, allowPrograms:true, critical:true, parts:[], docs:[], photos:[], notes:[], history:[{ action:"إنشاء نموذج إدارة الصيانة", at:now(), by:"النظام" }] }));
    const fan = getOrAdd("assets", (x) => x.number === "SFN-01", () => ({ number:"SFN-01", name:"Silo Fan SFN-01", type:"معدات", location:"Silo Area", locationType:"WORK_CENTER", workCenterId:wcElec.id, ownership:"مؤسسة", active:true, allowWO:true, allowPrograms:true, critical:false, parts:[], docs:[], photos:[], notes:[], history:[] }));
    const cc = getOrAdd("assets", (x) => x.number === "CC-01", () => ({ number:"CC-01", name:"Chain Conveyor CC-01", type:"معدات", location:"Mill / Conveyor Line", locationType:"WORK_CENTER", workCenterId:wcMech.id, ownership:"مؤسسة", active:true, allowWO:true, allowPrograms:true, critical:true, parts:[], docs:[], photos:[], notes:[], history:[] }));
    const bucketGroup = getOrAdd("assetGroups", (x) => x.code === "ELV", () => ({ code:"ELV", number:"AG-ELV", name:"Bucket Elevators", description:"مصاعد القواديس", assetIds:[ela.id], assignments:[{ id:uid(), assetId:ela.id, start:today(), end:"" }] }));
    const fanGroup = getOrAdd("assetGroups", (x) => x.code === "SFN", () => ({ code:"SFN", number:"AG-SFN", name:"Silo Fans", description:"مراوح الصوامع", assetIds:[fan.id], assignments:[{ id:uid(), assetId:fan.id, start:today(), end:"" }] }));
    bucketGroup.assetIds = [...new Set([...(bucketGroup.assetIds||[]), ela.id])]; fanGroup.assetIds = [...new Set([...(fanGroup.assetIds||[]), fan.id])];
    const grease = getOrAdd("items", (x) => x.code === "GRS-001", () => ({ code:"GRS-001", name:"Grease", category:"زيوت وشحوم", unit:"kg", minQty:1, unitCost:25 }));
    const tools = getOrAdd("items", (x) => x.code === "CLN-TOOLS", () => ({ code:"CLN-TOOLS", name:"Cleaning tools", category:"أخرى", unit:"set", minQty:1, unitCost:10 }));
    const wh = getOrAdd("warehouses", (x) => x.name === "Main Store", () => ({ name:"Main Store" }));
    if (!next.stockTx.some((t) => t.itemId === grease.id && t.type === "استلام")) next.stockTx.push({ id:uid(), type:"استلام", itemId:grease.id, warehouseId:wh.id, qty:10, at:today() });
    const mkOp = (code, name, wc, minutes, steps) => getOrAdd("stdOps", (x) => x.code === code, () => ({ code, name, type:"داخلية", workCenterId:wc.id, minutes, steps, countPoint:true, resources:[], attachments:[] }));
    const bearing = mkOp("BRG-LUB", "Bearing Lubrication", wcMech, 30, "Safety isolation\nOpen guard\nClean bearing area\nApply grease\nCheck temperature\nTrial run\nRecord result");
    const inspectBelt = mkOp("ELV-BELT", "Inspect belt", wcMech, 20, "Inspect belt tension\nCheck belt alignment\nRecord observations");
    const inspectBuckets = mkOp("ELV-BUCKET", "Inspect buckets", wcMech, 15, "Inspect buckets\nTighten loose bolts\nRecord damaged buckets");
    const pulley = mkOp("ELV-PULLEY", "Check pulley alignment", wcMech, 20, "Check drive pulley\nCheck tail pulley\nRecord alignment");
    const sensors = mkOp("ELV-SENSOR", "Check sensors", wcElec, 20, "Check speed switch\nCheck bearing temperature sensor\nCheck safety interlock");
    const trial = mkOp("ELV-TRIAL", "Trial run", wcMech, 15, "Remove tools\nRun equipment\nRecord result");
    const def = getOrAdd("workDefs", (x) => x.name === "Bucket Elevator Monthly PM", () => ({ name:"Bucket Elevator Monthly PM", description:"Operations + Steps + Materials + Resources + Time + Safety", assetGroupId:bucketGroup.id, opIds:[inspectBelt.id, inspectBuckets.id, pulley.id, bearing.id, sensors.id, trial.id], materials:"Grease\nCleaning tools", resources:"Mechanical Technician\nElectrical Technician", estimatedHours:2 }));
    const tpl = getOrAdd("meterTemplates", (x) => x.code === "RUN-HOURS", () => ({ code:"RUN-HOURS", name:"Running Hours", uom:"ساعة", meterType:"مستمر", readingType:"مطلق", direction:"تصاعدي", allowSchedule:true, recordAtWO:"اختياري" }));
    const am = getOrAdd("assetMeters", (x) => x.assetId === fan.id && x.templateId === tpl.id, () => ({ assetId:fan.id, templateId:tpl.id, initial:0, estDailyRate:10 }));
    if (!next.readings.some((r) => r.assetMeterId === am.id && Number(r.value) === 485)) next.readings.push({ id:uid(), assetMeterId:am.id, assetId:fan.id, value:485, at:today(), status:"مسجلة", comments:"Current Meter 485 hours" });
    const prog = getOrAdd("programs", (x) => x.name === "Silo Fan PM", () => ({ name:"Silo Fan PM", targetType:"أصل واحد", assetId:fan.id, assetGroupId:fanGroup.id, workDefId:def.id, method:"فاصل عداد", interval:500, assetMeterId:am.id, lastMeterValue:0, startDate:today() }));
    getOrAdd("workRequests", (x) => x.title === "Abnormal sound in ELA-01", () => ({ title:"Abnormal sound in ELA-01", assetId:ela.id, severity:"حرجة", desc:"Operator notices abnormal sound in ELA-01", status:"مفتوح", createdAt:today(), requester:"Operator" }));
    if (!next.workOrders.some((w) => w.number === "WO-1001")) {
      const ops = [inspectBelt, inspectBuckets, pulley, bearing, sensors, trial].map((op, i) => ({ id:uid(), seq:(i+1)*10, stdOpId:op.id, name:op.name, workCenterId:op.workCenterId, minutes:op.minutes, status:"معلقة", assigneeId:i === 3 ? ahmed.id : (op.workCenterId === wcElec.id ? ali.id : ahmed.id), actualHours:0, steps:(op.steps||"").split("\n").filter(Boolean).map((text, idx)=>({ id:uid(), seq:idx+1, text, done:false })) }));
      next.workOrders.push({ id:uid(), number:"WO-1001", title:"Bucket Elevator Monthly PM", assetId:ela.id, type:"وقائي", priority:"عالية", status:"جاهز", plannedStart:today(), plannedEnd:today(), workDefId:def.id, programId:prog.id, workCenterId:wcMech.id, safetyRequired:true, photoRequired:true, materials:[{ id:uid(), itemId:grease.id, qty:1, reserved:true, picked:true, issuedQty:0, usedQty:"", returned:false, unitCost:25 }, { id:uid(), itemId:tools.id, qty:1, reserved:true, picked:true, issuedQty:0, usedQty:"", returned:false, unitCost:10 }], checklist:SAFETY_DEFAULTS.map((text)=>({ id:uid(), text, done:false })), operations:ops, photos:[], failure:null, exceptions:[], assignments:[{ id:uid(), technicianId:ahmed.id, role:"Mechanical Technician", status:"مسند", assignedAt:today() }, { id:uid(), technicianId:ali.id, role:"Electrical Technician", status:"مسند", assignedAt:today() }], _cmmsAssignedTechIds:[ahmed.id, ali.id], execLog:[{ action:"إنشاء نموذج WO-1001", at:now(), by:"النظام" }], history:[{ to:"جاهز", at:today() }], statusHistory:[{ id:uid(), from:"مسودة", to:"جاهز", at:today(), atText:now(), by:"النظام" }] });
    }
    next.standardOperationSteps = next.standardOperationSteps.length ? next.standardOperationSteps : (bearing.steps||"").split("\n").map((text, i)=>({ id:uid(), standardOperationId:bearing.id, seq:i+1, text }));
    next.workDefinitionOperations = next.workDefinitionOperations.length ? next.workDefinitionOperations : (def.opIds||[]).map((opId, i)=>({ id:uid(), workDefinitionId:def.id, operationId:opId, seq:(i+1)*10 }));
    next.workDefinitionMaterials = next.workDefinitionMaterials.length ? next.workDefinitionMaterials : [{ id:uid(), workDefinitionId:def.id, itemId:grease.id, qty:1 }, { id:uid(), workDefinitionId:def.id, itemId:tools.id, qty:1 }];
    next.workDefinitionResources = next.workDefinitionResources.length ? next.workDefinitionResources : [{ id:uid(), workDefinitionId:def.id, resourceName:"Mechanical Technician", hours:1.5 }, { id:uid(), workDefinitionId:def.id, resourceName:"Electrical Technician", hours:0.5 }];
    next.maintenanceProgramGroups = next.maintenanceProgramGroups.length ? next.maintenanceProgramGroups : [{ id:uid(), programId:prog.id, assetGroupId:fanGroup.id }];
    next.maintenanceForecasts = [{ id:uid(), programId:prog.id, assetId:fan.id, currentMeter:485, dueAt:500, remaining:15, alert:"Maintenance due soon", generatedAt:today() }];
    save(next); alert("تم إنشاء نموذج إدارة الصيانة الكامل.");
  };
  const ruleFindings = [];
  db.workOrders.forEach((w) => {
    if (!w.assetId) ruleFindings.push(["No Work Order without Asset", w.number]);
    if (w.type === "وقائي" && !w.programId && !w.workDefId) ruleFindings.push(["No PM Work Order without Maintenance Program or Work Definition", w.number]);
    if (!woAssignedTechIds(w).length) ruleFindings.push(["No work order without technicians assign", w.number]);
    if (["بانتظار المراجعة", "مغلق"].includes(w.status) && (w.checklist||[]).some((c)=>!c.done)) ruleFindings.push(["No technician completion without checklist", w.number]);
    if (w.status === "مغلق" && !w.supervisorApproved) ruleFindings.push(["No final close without supervisor approval", w.number]);
    if (["تصحيحي", "طارئ"].includes(w.type) && ["بانتظار المراجعة", "مغلق"].includes(w.status) && !w.failure) ruleFindings.push(["No corrective work completion without failure data", w.number]);
    if (w.photoRequired && ["بانتظار المراجعة", "مغلق"].includes(w.status)) { const types = (w.photos||[]).map((p)=>p.type); if (!types.includes("قبل") || !types.includes("بعد")) ruleFindings.push(["No photo-required work completion without photos", w.number]); }
    if (!(w.execLog||[]).length && !(w.statusHistory||[]).length) ruleFindings.push(["No status change without audit log", w.number]);
  });
  const techLoad = db.technicians.map((t)=>({ t, n: open.filter((w)=>woAssignedTechIds(w).includes(t.id)).length })).filter((x)=>x.n>0).sort((a,b)=>b.n-a.n);
  const dueForecasts = db.programs.map((p) => ({ p, info: programDue ? programDue(p) : { label:"—" } }));
  const tabs = ["الملخص", "التدفق", "التخطيط", "الإرسال", "تنفيذ الفني", "المراجعة", "القواعد", "التقارير", "الكيانات"];
  return <>
    <div style={{ display:"flex", gap:6, overflowX:"auto", marginBottom:12 }}>{tabs.map((t)=><Chip key={t} active={sub===t} onClick={()=>setSub(t)}>{t}</Chip>)}</div>
    {can.manage && <Btn bg={C.orange} onClick={seedDemo} style={{ width:"100%", padding:12, marginBottom:12 }}>+ إنشاء نموذج إدارة الصيانة الكامل</Btn>}
    {sub === "الملخص" && <>
      <div style={{ display:"flex", gap:8, marginBottom:16 }}><Stat n={todayWos.length} label="Today Work Orders" color={C.blue}/><Stat n={pastDue.length} label="Past Due" color={pastDue.length?C.red:C.steel}/><Stat n={waitingMat.length} label="Waiting Material" color={waitingMat.length?C.amber:C.steel}/><Stat n={pendingReview.length} label="Pending Review" color={C.purple}/></div>
      <Section title="Maintenance Management"><div style={card()}><Row main="Work Requests → Standard Operations → Work Definitions → Programs → Forecast → Work Orders → Scheduling → Assignment → Execution → Supervision → Closing → Reports" sub="هذه الشاشة تجمع دورة العمل التي طلبتها وتربطها بالشاشات الحالية." /></div></Section>
      <Section title="Supervisor see"><div style={card()}><Row main="Today / Past Due / Waiting Material / Completed Pending Review / Emergency / Rejected" sub={"اليوم "+todayWos.length+" · متأخر "+pastDue.length+" · مواد "+waitingMat.length+" · مراجعة "+pendingReview.length+" · طارئ "+emergency.length+" · مرفوض "+rejected.length}/></div><div style={card()}><Row main="Technician Load" sub={techLoad.map((x)=>x.t.name+": "+x.n).join(" · ") || "لا حمل"}/></div></Section>
    </>}
    {sub === "التدفق" && <Section title="Work Request to Work Order"><div style={card()}><Row main="Operator notices abnormal sound in ELA-01" sub="Creates Work Request → Supervisor reviews → Convert to Work Order" /></div>{db.workRequests.slice(-5).map((r)=><div key={r.id} style={card()}><Row main={r.title} sub={nameOf("assets", r.assetId)+" · "+r.status}/></div>)}</Section>}
    {sub === "التخطيط" && <><Section title="Standard Operation: Bearing Lubrication">{db.stdOps.filter((o)=>o.code==="BRG-LUB" || o.name.includes("Bearing")).map((o)=><div key={o.id} style={card()}><Row main={o.code+" — "+o.name} sub={(o.steps||"").split("\n").filter(Boolean).map((x,i)=>(i+1)+". "+x).join(" · ")}/></div>)}{!db.stdOps.some((o)=>o.code==="BRG-LUB") && <Empty text="اضغط إنشاء النموذج لإضافة العملية القياسية."/>}</Section><Section title="Work Definition: Bucket Elevator Monthly PM">{db.workDefs.filter((d)=>d.name.includes("Bucket Elevator")).map((d)=><div key={d.id} style={card()}><Row main={d.name} sub={[(d.opIds||[]).length+" Operations", d.materials, d.resources, d.estimatedHours?d.estimatedHours+" hours":""].filter(Boolean).join(" · ")}/></div>)}</Section><Section title="Maintenance Forecast">{dueForecasts.map(({p,info})=><div key={p.id} style={{...card(), borderRightColor:info.due?C.red:info.soon?C.amber:C.green}}><Row main={p.name} sub={info.label} action={info.due?<Btn bg={C.orange} onClick={()=>generateWO(p)}>Generate WO</Btn>:<Badge text={info.soon?"Maintenance due soon":"OK"} color={info.soon?C.amber:C.green}/>} /></div>)}</Section></>}
    {sub === "الإرسال" && <Section title="Maintenance Dispatch List">{open.map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} badge={{text:w.status, color:WO_COLORS[w.status]||C.steel}} sub={["Asset: "+nameOf("assets", w.assetId), "Work Type: "+w.type, "Priority: "+w.priority, "Planned: "+(w.plannedStart||"—"), "Work Center: "+nameOf("workCenters", w.workCenterId), "Technician: "+(woAssignedTechIds(w).map((id)=>nameOf("technicians", id)).join("، ")||"—"), "Material Status: "+materialStatusOf(w), w.safetyRequired?"Safety Permit: Required":""].filter(Boolean).join(" · ")} /></div>)}{open.length===0 && <Empty text="لا توجد أوامر مفتوحة للإرسال."/>}</Section>}
    {sub === "تنفيذ الفني" && <Section title="My Maintenance Work / Technician Execution">{["New Assigned Tasks", "In Progress Tasks", "Emergency Tasks", "Tasks Waiting Materials", "Tasks Returned by Supervisor", "Completed Tasks"].map((b)=><div key={b} style={card()}><Row main={b} sub="Start Work · Pause · Resume · Add Note · Request Material · Record Failure · Upload Photo · Complete Work" /></div>)}<Btn bg={C.blue} onClick={()=>setTab("mywork")} style={{width:"100%"}}>فتح شاشة الفني</Btn></Section>}
    {sub === "المراجعة" && <Section title="Supervisor Review">{pendingReview.map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} sub={["Technician Notes", "Checklist", "Material Usage", "Labor Time", "Failure Data", "Photos", "Inspection Results", "Trial Run Result"].join(" · ")} badge={{text:"Review", color:C.blue}} /></div>)}{pendingReview.length===0 && <Empty text="لا أوامر بانتظار مراجعة المشرف."/>}</Section>}
    {sub === "القواعد" && <><Section title={"قواعد التنفيذ — ملاحظات حالية " + ruleFindings.length}>{MAINTENANCE_RULES.map((r)=><div key={r} style={{...card(), borderRightColor:ruleFindings.some(([x])=>x===r)?C.red:C.green}}><Row main={r} sub={ruleFindings.filter(([x])=>x===r).map(([,ref])=>ref).join("، ") || "مطبق"} badge={{text:ruleFindings.some(([x])=>x===r)?"تحقق":"✓", color:ruleFindings.some(([x])=>x===r)?C.red:C.green}}/></div>)}</Section><Section title="الصلاحيات"><div style={card()}>{MAINTENANCE_PERMISSIONS.map((p)=><span key={p} style={{display:"inline-block", fontSize:11, border:`1px solid ${C.line}`, borderRadius:999, padding:"3px 7px", margin:3}}>{p}</span>)}</div></Section></>}
    {sub === "التقارير" && <Section title="Maintenance Reports">{MAINTENANCE_REPORTS.map((r)=><div key={r} style={card()}><Row main={r} sub={r.includes("Cost")?"يعتمد على WorkOrderCosts + Material/Labor Transactions":r.includes("Failure")||r.includes("MTTR")||r.includes("MTBF")?"يعتمد على Failure Capture و Downtime":"متاح من بيانات أوامر العمل"}/></div>)}</Section>}
    {sub === "الكيانات" && <Section title="Data Model / Tables">{MAINTENANCE_ENTITY_KEYS.map((e)=><div key={e} style={card()}><Row main={e} sub={(db[e]||[]).length+" records"}/></div>)}</Section>}
  </>;
}

/* ───────────────────────── الإشراف المتقدم — Supervision Workbench ───────────────────────── */
function Supervision({ ctx, openWO }) {
  const { db, save, update, nameOf, woCost, woAssignedTechIds, materialStatusOf, setWOStatus, can } = ctx;
  const [view, setView] = useState("العمل اليومي");
  const [filter, setFilter] = useState("الكل");
  const [selectedTech, setSelectedTech] = useState("");
  const [searchName, setSearchName] = useState("");
  const open = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status));
  const byFilter = (w) => filter === "الكل" || w.status === filter || w.priority === filter || w.type === filter;
  const visible = open.filter(byFilter).filter((w) => !selectedTech || woAssignedTechIds(w).includes(selectedTech) || (w.operations || []).some((o)=>o.assigneeId === selectedTech));
  const technicianLoad = db.technicians.map((t) => {
    const orders = open.filter((w) => woAssignedTechIds(w).includes(t.id) || (w.operations || []).some((o)=>o.assigneeId === t.id && o.status !== "مكتملة"));
    const hours = orders.reduce((s, w) => s + (w.operations || []).filter((o)=>o.assigneeId === t.id && o.status !== "مكتملة").reduce((x, o)=>x + (Number(o.minutes || 0) / 60 || Number(o.actualHours || 0)), 0), 0);
    return { t, orders, hours };
  }).sort((a,b)=>b.orders.length-a.orders.length);
  const conflicts = [];
  const scheduleMap = {};
  open.forEach((w) => woAssignedTechIds(w).forEach((tid) => {
    const key = tid + "|" + (w.plannedStart || today());
    scheduleMap[key] = scheduleMap[key] || [];
    scheduleMap[key].push(w);
  }));
  Object.entries(scheduleMap).forEach(([key, list]) => {
    if (list.length > 1) {
      const [tid, date] = key.split("|");
      conflicts.push({ id:key, type:"تعارض جدول", technicianId:tid, date, orders:list });
    }
  });
  open.forEach((w) => (w.operations || []).forEach((op) => {
    if (!op.assigneeId) return;
    const tech = db.technicians.find((t)=>t.id === op.assigneeId);
    if (tech?.workCenterId && op.workCenterId && tech.workCenterId !== op.workCenterId) conflicts.push({ id:w.id+op.id, type:"تعارض تأهيل/مركز عمل", technicianId:tech.id, date:w.plannedStart || today(), orders:[w], operation:op.name });
  }));
  const materialWaiting = open.filter((w)=>w.status === "بانتظار مواد" || (materialStatusOf && String(materialStatusOf(w)).includes("Waiting")));
  const saveSearch = () => {
    if (!String(searchName).trim()) return alert("اكتب اسم البحث المحفوظ.");
    save({ ...db, supervisionSavedSearches:[...(db.supervisionSavedSearches || []), { id:uid(), name:searchName.trim(), filter, technicianId:selectedTech, createdAt:now() }] });
    setSearchName("");
  };
  const applySearch = (s) => { setFilter(s.filter || "الكل"); setSelectedTech(s.technicianId || ""); };
  const assignTech = (w, techId) => {
    const tech = db.technicians.find((t)=>t.id === techId);
    if (!tech) return;
    const assignments = [...(w.assignments || []).filter((a)=>a.technicianId !== techId), { id:uid(), technicianId:techId, role:tech.specialty || "Technician", status:"مسند", assignedAt:today(), assignedBy:"Supervision Workbench" }];
    const ops = (w.operations || []).map((op)=> op.assigneeId ? op : { ...op, assigneeId:techId });
    update("workOrders", w.id, { assignments, operations:ops, _cmmsAssignedTechIds:[...new Set(assignments.map((a)=>a.technicianId))], execLog:[...(w.execLog||[]), { action:"إسناد فني من لوحة المشرف: " + tech.name, at:now(), by:"مشرف" }] });
  };
  const makePlanSnapshot = () => {
    save({ ...db,
      supervisionAssignmentPlans:[...(db.supervisionAssignmentPlans || []), { id:uid(), at:now(), date:today(), openOrders:open.length, conflicts:conflicts.length, waitingMaterial:materialWaiting.length, createdBy:"Supervision Workbench" }],
      resourceCapacitySnapshots:[...(db.resourceCapacitySnapshots || []), ...technicianLoad.map((x)=>({ id:uid(), at:today(), technicianId:x.t.id, technicianName:x.t.name, assignedOrders:x.orders.length, estimatedHours:Math.round(x.hours*10)/10 }))],
      resourceScheduleConflicts:[...(db.resourceScheduleConflicts || []), ...conflicts.map((c)=>({ id:uid(), at:now(), type:c.type, technicianId:c.technicianId, date:c.date, workOrderNumbers:(c.orders||[]).map((w)=>w.number).join(", "), operation:c.operation || "" }))]
    });
  };
  const statusBuckets = ["الكل", "جاهز", "قيد التنفيذ", "بانتظار مواد", "بانتظار المراجعة", "مُعاد للتصحيح", "طارئ", "وقائي", "تصحيحي"];
  const views = ["العمل اليومي", "الجدولة", "الإسناد", "المواد", "المراجعة", "التعارضات", "البحوث"];
  return <>
    <div style={{display:"flex", gap:6, overflowX:"auto", marginBottom:10}}>{views.map((v)=><Chip key={v} active={view===v} onClick={()=>setView(v)}>{v}</Chip>)}</div>
    <Section title="Supervision Workbench">
      <div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={open.length} label="Open" color={C.blue}/><Stat n={open.filter((w)=>w.plannedEnd && daysUntil(w.plannedEnd)<0).length} label="Past Due" color={C.red}/><Stat n={materialWaiting.length} label="Waiting Material" color={C.amber}/><Stat n={conflicts.length} label="Conflicts" color={conflicts.length?C.red:C.green}/></div>
      <div style={{...card(), display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}><Field label="فلتر"><select value={filter} onChange={(e)=>setFilter(e.target.value)} style={inputStyle()}>{statusBuckets.map((x)=><option key={x}>{x}</option>)}</select></Field><Field label="فني"><select value={selectedTech} onChange={(e)=>setSelectedTech(e.target.value)} style={inputStyle()}><option value="">كل الفنيين</option>{db.technicians.map((t)=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field></div>
      {can?.review && <Btn bg={C.purple} onClick={makePlanSnapshot} style={{width:"100%", padding:10, marginBottom:8}}>حفظ Snapshot للجدولة والتعارضات</Btn>}
    </Section>
    {view === "العمل اليومي" && <Section title={"أوامر العمل حسب الفلتر ("+visible.length+")"}>{visible.map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} sub={["Asset: "+nameOf("assets", w.assetId), "Planned: "+(w.plannedStart||"—"), "End: "+(w.plannedEnd||"—"), "Technicians: "+(woAssignedTechIds(w).map((id)=>nameOf("technicians", id)).join("، ")||"—"), "Cost: "+money(woCost(w).total)].join(" · ")} badge={{text:w.status, color:WO_COLORS[w.status]||C.steel}} /></div>)}{visible.length===0 && <Empty text="لا توجد أوامر ضمن الفلتر."/>}</Section>}
    {view === "الجدولة" && <><Section title="Scheduling Board — اليوم والمتأخر">{["اليوم", "متأخر", "هذا الأسبوع"].map((bucket)=>{ const list = open.filter((w)=> bucket==="اليوم" ? (!w.plannedStart || daysUntil(w.plannedStart)===0) : bucket==="متأخر" ? (w.plannedEnd && daysUntil(w.plannedEnd)<0) : (w.plannedStart && daysUntil(w.plannedStart)>=0 && daysUntil(w.plannedStart)<=7)); return <div key={bucket} style={card()}><Row main={bucket+" — "+list.length} sub={list.map((w)=>w.number).join("، ") || "—"}/></div>; })}</Section><Section title="Resource Capacity / Technician Load">{technicianLoad.map((x)=><div key={x.t.id} style={{...card(), borderRightColor:x.orders.length>5?C.red:x.orders.length>2?C.amber:C.green}}><Row main={x.t.name} sub={x.orders.length+" أوامر · " + (Math.round(x.hours*10)/10) + " ساعة تقديرية · " + (nameOf("workCenters", x.t.workCenterId)||"بدون مركز")} badge={{text:x.orders.length>5?"Overload":"OK", color:x.orders.length>5?C.red:C.green}} /></div>)}</Section></>}
    {view === "الإسناد" && <Section title="Assignment Drawer مبسط">{visible.map((w)=><div key={w.id} style={card()}><Row main={w.number+" — "+w.title} sub={"الحالي: "+(woAssignedTechIds(w).map((id)=>nameOf("technicians", id)).join("، ")||"غير مسند")} /><div style={{display:"grid", gridTemplateColumns:"1fr auto", gap:8, marginTop:8}}><select onChange={(e)=>e.target.value && assignTech(w, e.target.value)} defaultValue="" style={inputStyle()}><option value="">اختر فني للإسناد/إعادة الإسناد</option>{db.technicians.map((t)=><option key={t.id} value={t.id}>{t.name} — {t.specialty || "فني"}</option>)}</select><Btn bg={C.amber} onClick={()=>setWOStatus(w, "معلق")}>Hold</Btn></div><div style={{display:"flex", gap:8, marginTop:8}}><Btn bg={C.blue} onClick={()=>update("workOrders", w.id, { priority:"طارئ" })}>Emergency</Btn><Btn bg={C.green} onClick={()=>setWOStatus(w, w.status === "مسودة" ? "مُصدر" : "جاهز")}>Release/Ready</Btn></div></div>)}</Section>}
    {view === "المواد" && <Section title="Waiting Material Orders">{materialWaiting.map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} sub={(w.materials||[]).map((m)=>nameOf("items", m.itemId)+": مطلوب "+m.qty+" · مصروف "+(m.issuedQty||0)+" · مستخدم "+(m.usedQty||0)).join(" | ") || "لا مواد"} badge={{text:"Material Review", color:C.amber}} /></div>)}{materialWaiting.length===0 && <Empty text="لا توجد أوامر بانتظار مواد."/>}</Section>}
    {view === "المراجعة" && <Section title="Completed Pending Review">{open.filter((w)=>w.status==="بانتظار المراجعة").map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} sub={["Checklist", "Labor", "Materials", "Failure", "Photos", "Trial Run"].join(" · ")} badge={{text:"Supervisor Review", color:C.blue}} /><div style={{display:"flex", gap:8, marginTop:8}}><Btn bg={C.green} onClick={()=>setWOStatus(w, "مغلق", { reviewNotes:"Approved from Supervision Workbench" })}>Approve / Close</Btn><Btn bg={C.red} onClick={()=>setWOStatus(w, "مُعاد للتصحيح", { reviewNotes:"Rejected from Supervision Workbench" })}>Reject</Btn></div></div>)}{open.filter((w)=>w.status==="بانتظار المراجعة").length===0 && <Empty text="لا توجد أوامر بانتظار المراجعة."/>}</Section>}
    {view === "التعارضات" && <Section title="Conflict Preview / Qualification Check">{conflicts.map((c)=><div key={c.id} style={{...card(), borderRightColor:C.red}}><Row main={c.type} sub={["Date: "+c.date, "Technician: "+nameOf("technicians", c.technicianId), "Orders: "+(c.orders||[]).map((w)=>w.number).join("، "), c.operation ? "Operation: "+c.operation : ""].filter(Boolean).join(" · ")} badge={{text:"Conflict", color:C.red}} /></div>)}{conflicts.length===0 && <Empty text="لا توجد تعارضات جدول أو تأهيل مكتشفة."/>}</Section>}
    {view === "البحوث" && <Section title="Saved Searches"><div style={{...card(), display:"grid", gridTemplateColumns:"1fr auto", gap:8}}><input value={searchName} onChange={(e)=>setSearchName(e.target.value)} placeholder="اسم البحث المحفوظ" style={inputStyle()}/><Btn bg={C.green} onClick={saveSearch}>حفظ</Btn></div>{(db.supervisionSavedSearches||[]).map((s)=><div key={s.id} style={card()} onClick={()=>applySearch(s)}><Row main={s.name} sub={["Filter: "+(s.filter||"الكل"), s.technicianId ? "Technician: "+nameOf("technicians", s.technicianId) : "كل الفنيين", s.createdAt].join(" · ")} /></div>)}</Section>}
  </>;
}

/* ───────────────────────── توقعات الصيانة المتقدمة ───────────────────────── */
function Forecast({ ctx, programDue, generateWO }) {
  const { db, save, nameOf, programAssets, ltd, utilRate, can } = ctx;
  const [horizon, setHorizon] = useState(30);
  const [view, setView] = useState("التوقعات");
  const addDays = (base, n) => addDateDays(base || today(), Number(n || 0));
  const forecastForProgram = (p) => {
    const assets = programAssets(p);
    const info = programDue(p);
    const rows = [];
    if (!assets.length) rows.push({ program:p, asset:null, status:"Invalid", reason:"لا توجد أصول متأثرة", dueDate:info.nextDate || today(), remaining:null });
    assets.forEach((asset) => {
      let dueDate = info.nextDate || today(); let remaining = null; let currentMeter = null; let dueAt = null;
      let alert = info.soon ? "Maintenance due soon" : "OK";
      if (p.method === "فاصل عداد") {
        const am = db.assetMeters.find((m)=>m.id === p.assetMeterId) || db.assetMeters.find((m)=>m.assetId === asset.id && (!p.assetMeterId || m.id === p.assetMeterId));
        if (am) {
          currentMeter = ltd ? ltd(am) : 0;
          dueAt = Number(p.lastMeterValue || 0) + Number(p.interval || 0);
          remaining = Math.max(0, dueAt - currentMeter);
          const rate = Number(utilRate ? utilRate(am) : 0) || Number(am.estDailyRate || 0) || 1;
          dueDate = addDays(today(), Math.ceil(remaining / Math.max(rate, 0.01)));
          alert = remaining <= Number(p.interval || 0) * 0.1 ? "Maintenance due soon" : "OK";
        } else alert = "Invalid: meter missing";
      }
      const dLeft = daysUntil(dueDate);
      const status = alert.startsWith("Invalid") ? "Invalid" : dLeft <= 0 ? "Due" : dLeft <= Number(horizon) ? "Forecast" : "Future";
      rows.push({ id:"FC-"+p.id+"-"+asset.id+"-"+dueDate, program:p, asset, programId:p.id, assetId:asset.id, workDefId:p.workDefId || "", programName:p.name, assetName:asset.name, dueDate, remaining, currentMeter, dueAt, alert, status, risk: asset.critical || dLeft <= 0 ? "عال" : dLeft <= 7 ? "متوسط" : "منخفض" });
    });
    return rows;
  };
  const allLines = db.programs.flatMap(forecastForProgram).sort((a,b)=>String(a.dueDate).localeCompare(String(b.dueDate)));
  const visible = allLines.filter((l)=> l.status !== "Future");
  const validations = [];
  allLines.forEach((l)=>{
    if (!l.assetId) validations.push({ id:uid(), programId:l.programId || l.program?.id, assetId:"", severity:"حرج", message:l.reason || "لا توجد أصول للبرنامج" });
    if (l.program && !l.program.workDefId) validations.push({ id:uid(), programId:l.program.id, assetId:l.assetId || "", severity:"عال", message:"برنامج بدون Work Definition" });
    if (l.asset && (l.asset.active === false || l.asset.allowPrograms === false)) validations.push({ id:uid(), programId:l.program.id, assetId:l.asset.id, severity:"عال", message:"الأصل غير نشط أو لا يسمح بالبرامج" });
    if (l.program?.method === "فاصل عداد" && l.alert === "Invalid: meter missing") validations.push({ id:uid(), programId:l.program.id, assetId:l.assetId || "", severity:"حرج", message:"برنامج عداد بدون عداد صالح" });
    const dup = db.workOrders.some((w)=>ACTIVE_STATES.includes(w.status) && w.programId === l.programId && w.assetId === l.assetId);
    if (dup) validations.push({ id:uid(), programId:l.programId, assetId:l.assetId, severity:"متوسط", message:"يوجد أمر عمل مفتوح لنفس البرنامج والأصل" });
  });
  const saveForecast = () => { const runId = uid(); const rows = visible.map((l)=>({ id:l.id, runId, programId:l.programId, assetId:l.assetId, workDefId:l.workDefId, dueDate:l.dueDate, status:l.status, risk:l.risk, alert:l.alert, currentMeter:l.currentMeter, dueAt:l.dueAt, remaining:l.remaining, generatedAt:now(), suppressed:false })); save({ ...db, maintenanceForecasts:[...(db.maintenanceForecasts || []).filter((x)=>!rows.some((r)=>r.id===x.id)), ...rows], forecastRuns:[...(db.forecastRuns || []), { id:runId, at:now(), horizonDays:Number(horizon), lines:rows.length, due:rows.filter((x)=>x.status==="Due").length, warnings:validations.length }], forecastValidationIssues:[...(db.forecastValidationIssues || []), ...validations.map((v)=>({ ...v, runId, at:now() }))] }); };
  const suppress = (line, reason="Suppressed by planner") => save({ ...db, maintenanceForecasts:[...(db.maintenanceForecasts || []), { id:line.id, programId:line.programId, assetId:line.assetId, dueDate:line.dueDate, status:"Suppressed", risk:line.risk, alert:line.alert, suppressed:true, suppressReason:reason, generatedAt:now() }], forecastSuppressionRules:[...(db.forecastSuppressionRules || []), { id:uid(), programId:line.programId, assetId:line.assetId, dueDate:line.dueDate, reason, at:now() }] });
  const generateFromLine = (line) => { if (!line.program) return; if (db.workOrders.some((w)=>ACTIVE_STATES.includes(w.status) && w.programId === line.programId && w.assetId === line.assetId)) return alert("يوجد أمر عمل مفتوح لهذا البرنامج والأصل."); generateWO(line.program); };
  const tabs = ["التوقعات", "التحقق", "المحفوظة", "Merge/Suppress"];
  return <>
    <div style={{display:"flex", gap:6, overflowX:"auto", marginBottom:10}}>{tabs.map((t)=><Chip key={t} active={view===t} onClick={()=>setView(t)}>{t}</Chip>)}</div>
    <Section title="Advanced Maintenance Forecast"><div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={visible.length} label="Forecast Lines" color={C.blue}/><Stat n={visible.filter((l)=>l.status==="Due").length} label="Due" color={C.red}/><Stat n={validations.length} label="Validation Issues" color={validations.length?C.amber:C.green}/><Stat n={(db.maintenanceForecasts||[]).length} label="Saved" color={C.purple}/></div><div style={{...card(), display:"grid", gridTemplateColumns:"1fr auto", gap:8}}><Field label="Forecast Horizon بالأيام"><input type="number" value={horizon} onChange={(e)=>setHorizon(Number(e.target.value||30))} style={inputStyle()}/></Field>{can?.manage && <Btn bg={C.green} onClick={saveForecast} style={{alignSelf:"end", marginBottom:11}}>Generate / Validate</Btn>}</div></Section>
    {view === "التوقعات" && <Section title="Forecast Lines">{visible.map((l)=><div key={l.id} style={{...card(), borderRightColor:l.status==="Due"?C.red:l.alert.includes("soon")?C.amber:C.green}}><Row main={(l.programName || l.program?.name || "Program") + " — " + (l.assetName || "No asset")} sub={["Due: "+fmt(l.dueDate), l.remaining != null ? "Remaining: "+l.remaining : "", l.currentMeter != null ? "Current Meter: "+l.currentMeter : "", l.dueAt != null ? "PM Due: "+l.dueAt : "", l.alert].filter(Boolean).join(" · ")} badge={{text:l.status, color:l.status==="Due"?C.red:l.status==="Forecast"?C.amber:C.steel}} action={l.status !== "Invalid" && <Btn bg={C.orange} onClick={()=>generateFromLine(l)}>Generate WO</Btn>} /></div>)}{visible.length===0 && <Empty text="لا توجد توقعات ضمن الأفق الحالي."/>}</Section>}
    {view === "التحقق" && <Section title="Forecast Validation">{validations.map((v)=><div key={v.id} style={{...card(), borderRightColor:v.severity==="حرج"?C.red:C.amber}}><Row main={v.message} sub={["Program: "+nameOf("programs", v.programId), v.assetId ? "Asset: "+nameOf("assets", v.assetId) : "No asset"].join(" · ")} badge={{text:v.severity, color:v.severity==="حرج"?C.red:C.amber}} /></div>)}{validations.length===0 && <Empty text="التحقق ناجح: لا توجد مشاكل في التوقعات الحالية."/>}</Section>}
    {view === "المحفوظة" && <><Section title="Forecast Runs">{(db.forecastRuns||[]).slice().reverse().map((r)=><div key={r.id} style={card()}><Row main={r.at} sub={"Horizon: "+r.horizonDays+" days · Lines: "+r.lines+" · Due: "+r.due+" · Warnings: "+r.warnings}/></div>)}{!(db.forecastRuns||[]).length && <Empty text="لم يتم حفظ أي تشغيل توقعات بعد."/>}</Section><Section title="Saved Maintenance Forecasts">{(db.maintenanceForecasts||[]).slice().reverse().map((f)=><div key={f.id} style={card()}><Row main={nameOf("programs", f.programId)+" — "+nameOf("assets", f.assetId)} sub={["Due: "+fmt(f.dueDate), f.status, f.suppressReason].filter(Boolean).join(" · ")} badge={{text:f.suppressed?"Suppressed":(f.status||"—"), color:f.suppressed?C.steel:C.blue}} /></div>)}</Section></>}
    {view === "Merge/Suppress" && <Section title="Suppress / Merge Controls">{visible.map((l)=><div key={l.id} style={card()}><Row main={(l.programName || "Program")+" — "+(l.assetName || "Asset")} sub={"Due: "+fmt(l.dueDate)+" · Risk: "+l.risk} /><div style={{display:"flex", gap:8, marginTop:8}}><Btn bg={C.steel} onClick={()=>suppress(l)}>Suppress</Btn><Btn bg={C.purple} onClick={()=>save({ ...db, forecastMergeGroups:[...(db.forecastMergeGroups||[]), { id:uid(), at:now(), programId:l.programId, assetId:l.assetId, dueDate:l.dueDate, rule:"Merge compatible PM lines for same asset/date" }] })}>Mark for Merge</Btn></div></div>)}</Section>}
  </>;
}

/* ───────────────────────── العمليات القياسية بخطوات (وثيقة التنفيذ §Standard Operation) ───────────────────────── */
/* ───────────────────────── مكتبة العمليات القياسية (ف7) ───────────────────────── */
function StdOpsManager({ ctx }) {
  const { db, add, update, nameOf, can } = ctx;
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("الكل");
  const [showInactive, setShowInactive] = useState(false);
  const [form, setForm] = useState(false);
  const [detail, setDetail] = useState(null);
  /* الاستخدام: في تعريفات العمل أو أوامر العمل (يمنع الحذف وتغيير الكود) */
  const usage = (id) => ({
    defs: db.workDefs.filter((d) => (d.opIds || []).includes(id)),
    wos: db.workOrders.filter((w) => (w.operations || []).some((o) => o.stdOpId === id)),
  });
  const isInactive = (o) => o.inactiveOn && daysUntil(o.inactiveOn) <= 0;
  let list = db.stdOps.filter((o) =>
    (!q || (o.name + o.code + (o.description || "") + nameOf("workCenters", o.workCenterId)).includes(q)) &&
    (filter === "الكل" || (filter === "داخلية" && (o.type || "داخلية") === "داخلية") || (filter === "خارجية" && o.type === "خارجية")) &&
    (showInactive || !isInactive(o)));
  const opSchema = (editing) => [
    { k: "type", label: "نوع العملية", type: "select", options: ["داخلية", "خارجية"] },
    { k: "code", label: "الكود (فريد)" + (editing && (usage(editing.id).defs.length || usage(editing.id).wos.length) ? " — مقفل (مستخدمة)" : "") },
    { k: "name", label: "اسم العملية" },
    { k: "description", label: "الوصف", type: "textarea" },
    { k: "workCenterId", label: "مركز العمل" + (editing && (editing.resources || []).length ? " — مقفل (توجد موارد)" : ""), type: "select", from: "workCenters", fromKey: "name" },
    { k: "minutes", label: "المدة بالدقائق", type: "number" },
    { k: "steps", label: "الخطوات (سطر لكل خطوة)", type: "textarea" },
    { k: "countPoint", label: "نقطة عد (يجب الإبلاغ عن إكمالها صراحةً)", type: "check" },
    { k: "autoTransact", label: "تنفيذ تلقائي (لا يجتمع مع نقطة العد)", type: "check" },
    { k: "supplier", label: "المورد (للخارجية)" },
    { k: "supplierSite", label: "موقع المورد" },
    { k: "ospItemId", label: "صنف خدمة المورد — من ماستر الأصناف (إلزامي للخارجية)", type: "select", from: "items", fromLabel: (i) => i.code + " — " + i.name },
    { k: "inactiveOn", label: "تعطيل اعتبارًا من", type: "date" },
  ];
  const validate = (d, editing) => {
    if (!String(d.code || "").trim() || !String(d.name || "").trim()) return "الكود والاسم مطلوبان";
    if (db.stdOps.some((o) => o.code === d.code && o.id !== editing?.id)) return "الكود مستخدم — يجب أن يكون فريدًا";
    if (d.countPoint && d.autoTransact) return "نقطة العد والتنفيذ التلقائي لا يجتمعان (قاعدة ف7)";
    if (d.type === "خارجية" && !d.ospItemId) return "العملية الخارجية تتطلب صنف خدمة المورد";
    if (d.type === "خارجية" && (editing?.resources || []).length) return "العملية الخارجية لا تحمل موارد داخلية — احذف الموارد أولًا";
    if (editing) {
      const u = usage(editing.id);
      if (d.code !== editing.code && (u.defs.length || u.wos.length)) return "لا يمكن تغيير الكود — العملية مستخدمة";
      if (d.workCenterId !== editing.workCenterId && (editing.resources || []).length) return "لا يمكن تغيير مركز العمل مع وجود موارد";
    }
    return null;
  };
  return (
    <>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث بالاسم/الكود/الوصف/مركز العمل…" style={{ ...input, marginBottom: 8 }} />
      <div style={{ display: "flex", gap: 6, marginBottom: 10, alignItems: "center", flexWrap: "wrap" }}>
        {["الكل", "داخلية", "خارجية"].map((f) => <Chip key={f} active={filter === f} onClick={() => setFilter(f)}>{f}</Chip>)}
        <label style={{ display: "flex", gap: 5, alignItems: "center", fontSize: 12.5 }}>
          <input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} /> إظهار غير النشطة
        </label>
      </div>
      {can.manage && <Btn bg={C.orange} onClick={() => setForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ عملية قياسية جديدة</Btn>}
      {list.length === 0 && <Empty text="مكتبة قوالب: عرّف «تشحيم محامل» مرة واحدة واستخدمها في كل تعريفات وأوامر العمل." />}
      {list.map((o) => {
        const u = usage(o.id);
        return (
          <div key={o.id} style={{ ...card(), borderRightColor: isInactive(o) ? C.steel : o.type === "خارجية" ? C.purple : C.ink, opacity: isInactive(o) ? 0.6 : 1 }}
            onClick={() => setDetail(o.id)}>
            <Row main={o.code + " — " + o.name}
              badge={isInactive(o) ? { text: "غير نشطة", color: C.steel } : { text: o.type || "داخلية", color: o.type === "خارجية" ? C.purple : C.blue }}
              sub={[nameOf("workCenters", o.workCenterId) !== "—" ? nameOf("workCenters", o.workCenterId) : "",
                (o.resources || []).length + " مورد", (o.attachments || []).length ? (o.attachments || []).length + " مرفق" : "",
                u.defs.length + u.wos.length > 0 ? "مستخدمة في " + (u.defs.length + u.wos.length) : "",
                o.type === "خارجية" && o.supplier ? "مورد: " + o.supplier : ""].filter(Boolean).join(" · ")} />
          </div>
        );
      })}
      {form && (
        <FormSheet title="عملية قياسية جديدة" onClose={() => setForm(false)} db={db} schema={opSchema(null)}
          initial={{ type: "داخلية", countPoint: true, autoTransact: false }}
          onSave={(d) => {
            const err = validate(d, null);
            if (err) { alert(err); return; }
            add("stdOps", { resources: [], attachments: [], ...d }); setForm(false);
          }} />
      )}
      {detail && <StdOpDetail ctx={ctx} opId={detail} onClose={() => setDetail(null)} usage={usage} opSchema={opSchema} validate={validate} />}
    </>
  );
}

function StdOpDetail({ ctx, opId, onClose, usage, opSchema, validate }) {
  const { db, update, remove, nameOf, can } = ctx;
  const o = db.stdOps.find((x) => x.id === opId);
  const [sub, setSub] = useState("عام");
  const [edit, setEdit] = useState(false);
  const [resForm, setResForm] = useState(null); // null | "new" | resource obj
  const [altFor, setAltFor] = useState(null);
  if (!o) return null;
  const u = usage(o.id);
  const used = u.defs.length + u.wos.length > 0;
  const TABS = ["عام", "الموارد", "المرفقات", "أكواد الإصلاح", "الاستخدام"];
  const wcResources = db.resources.filter((r) => !o.workCenterId || r.workCenterId === o.workCenterId);
  const patchRes = (rs) => update("stdOps", o.id, { resources: rs });
  const resSchema = [
    { k: "seq", label: "التسلسل (نفس الرقم = موارد متزامنة)", type: "number" },
    { k: "resourceId", label: "المورد (من نفس مركز العمل)", type: "select",
      from: "resources", fromLabel: (r) => r.name + (r.workCenterId === o.workCenterId ? "" : " ⚠ خارج المركز") },
    { k: "units", label: "الوحدات المخصصة", type: "number" },
    { k: "basis", label: "الأساس", type: "select", options: OP_BASIS },
    { k: "usage", label: "الاستخدام (ساعات/وحدة — أكبر من صفر)", type: "number" },
    { k: "chargeType", label: "نوع التحميل", type: "select", options: OP_CHARGE },
    { k: "activity", label: "النشاط", type: "select", options: OP_ACTIVITY },
    { k: "scheduled", label: "يدخل في الجدولة", type: "check" },
    { k: "principal", label: "مورد رئيسي (واحد فقط لكل تسلسل متزامن)", type: "check" },
  ];
  const validateRes = (d, editing) => {
    if (!d.resourceId) return "اختر المورد";
    if (!(Number(d.usage) > 0)) return "الاستخدام يجب أن يكون أكبر من صفر";
    const r = db.resources.find((x) => x.id === d.resourceId);
    if (o.workCenterId && r && r.workCenterId !== o.workCenterId) return "المورد يجب أن يتبع نفس مركز العمل";
    if (d.principal && (o.resources || []).some((x) => x.id !== editing?.id && Number(x.seq) === Number(d.seq) && x.principal))
      return "يوجد مورد رئيسي آخر بنفس التسلسل المتزامن";
    return null;
  };
  return (
    <Sheet title={o.code + " — " + o.name} onClose={onClose}>
      <div style={{ display: "flex", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
        <Badge text={o.type || "داخلية"} color={o.type === "خارجية" ? C.purple : C.blue} />
        {o.countPoint && <Badge text="نقطة عد" color={C.ink} />}
        {o.autoTransact && <Badge text="تنفيذ تلقائي" color={C.amber} />}
        {o.inactiveOn && daysUntil(o.inactiveOn) <= 0 && <Badge text="غير نشطة" color={C.steel} />}
        {can.manage && <Btn bg={C.blue} onClick={() => setEdit(true)}>تعديل</Btn>}
        {can.admin && (used
          ? <Btn bg={C.steel} onClick={() => { update("stdOps", o.id, { inactiveOn: today() }); alert("العملية مستخدمة — عُطّلت بدل الحذف (قاعدة ف7)"); }}>تعطيل (مستخدمة)</Btn>
          : <Btn bg={C.red} onClick={() => { if (confirm("حذف العملية نهائيًا؟")) { remove("stdOps", o.id); onClose(); } }}>حذف</Btn>)}
      </div>
      <div style={{ display: "flex", gap: 5, overflowX: "auto", marginBottom: 10 }}>
        {TABS.map((t) => <Chip key={t} active={sub === t} onClick={() => setSub(t)}>{t}</Chip>)}
      </div>

      {sub === "عام" && (
        <div style={{ ...card(), fontSize: 14, lineHeight: 2 }}>
          {o.description && <>{o.description}<br /></>}
          مركز العمل: <b>{nameOf("workCenters", o.workCenterId)}</b> · المدة: <b>{o.minutes || "—"} د</b><br />
          {o.type === "خارجية" && (<>
            المورد: <b>{o.supplier || "—"}</b> · الموقع: <b>{o.supplierSite || "—"}</b><br />
            صنف الخدمة: <b>{nameOf("items", o.ospItemId)}</b><br />
            <span style={{ fontSize: 12.5, color: C.steel }}>العملية الخارجية لا تحمل موارد داخلية.</span><br />
          </>)}
          {(o.steps || "").split("\n").filter(Boolean).length > 0 && (<>
            <b>الخطوات:</b>
            {(o.steps || "").split("\n").filter(Boolean).map((s, i) => <div key={i} style={{ fontSize: 13.5 }}>{(i + 1) + ". " + s}</div>)}
          </>)}
        </div>
      )}

      {sub === "الموارد" && (<>
        {o.type === "خارجية"
          ? <Empty text="الموارد للعمليات الداخلية فقط (قاعدة ف7)." />
          : (<>
            {(o.resources || []).slice().sort((a, b) => a.seq - b.seq).map((r) => (
              <div key={r.id} style={{ ...card(), borderRightColor: r.principal ? C.orange : C.ink }}>
                <Row main={r.seq + " — " + nameOf("resources", r.resourceId) + (r.principal ? " ★ رئيسي" : "")}
                  sub={[r.units + " وحدة", r.basis, "استخدام " + r.usage, r.chargeType + " التحميل", r.activity,
                    r.scheduled ? "مجدول" : "غير مجدول"].join(" · ")}
                  action={can.manage ? <Btn bg={C.blue} onClick={() => setResForm(r)}>تعديل</Btn> : null} />
                {(r.alternates || []).length > 0 && (
                  <div style={{ fontSize: 12.5, color: C.steel, marginTop: 4 }}>
                    البدائل: {(r.alternates || []).map((a) => nameOf("resources", a.resourceId) + " (أولوية " + a.priority + ")").join("، ")}
                  </div>
                )}
                {can.manage && (
                  <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
                    <button onClick={() => setAltFor(r)} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>+ مورد بديل</button>
                    <button onClick={() => patchRes(o.resources.filter((x) => x.id !== r.id))} style={{ ...delBtn, marginTop: 0 }}>حذف</button>
                  </div>
                )}
              </div>
            ))}
            {(o.resources || []).length === 0 && <Empty text="مثال: تسلسل 10 فني (رئيسي) + جهاز تشخيص متزامن، ثم تسلسل 20 مفتش جودة." />}
            {can.manage && <Btn bg={C.ink} onClick={() => setResForm("new")} style={{ width: "100%" }}>+ إضافة مورد للعملية</Btn>}
          </>)}
      </>)}

      {sub === "المرفقات" && (<>
        <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 8 }}>تورَّث تعليمات العمل إلى أوامر العمل عند الإنشاء (نسخة).</div>
        {(o.attachments || []).map((a) => (
          <div key={a.id} style={card()}>
            <Row main={(a.type === "رابط" ? "🔗 " : "📝 ") + a.name}
              sub={a.type === "نص" ? a.value : ""}
              action={a.type === "رابط" && a.value ? <Btn bg={C.blue} onClick={() => window.open(a.value, "_blank")}>فتح</Btn> : null} />
            {can.manage && <button onClick={() => update("stdOps", o.id, { attachments: o.attachments.filter((x) => x.id !== a.id) })} style={delBtn}>حذف</button>}
          </div>
        ))}
        {can.manage && <AttachForm onAdd={(a) => update("stdOps", o.id, { attachments: [...(o.attachments || []), { id: uid(), ...a }] })} />}
      </>)}

      {sub === "أكواد الإصلاح" && (
        <div style={card()}>
          <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 8 }}>تنتقل إلى عملية أمر العمل عند الإنشاء وتستخدم في تحليل الضمان والتقارير.</div>
          <Field label="سبب الإصلاح">
            <select value={o.repairReason || ""} onChange={(e) => update("stdOps", o.id, { repairReason: e.target.value })} disabled={!can.manage} style={input}>
              <option value="">—</option>{REPAIR_REASONS.map((r) => <option key={r}>{r}</option>)}
            </select>
          </Field>
          <Field label="كود معاملة الإصلاح (النظام/المكون)">
            <input value={o.repairTx || ""} onChange={(e) => update("stdOps", o.id, { repairTx: e.target.value })} disabled={!can.manage} placeholder="ELV-BRG محامل المصاعد…" style={input} />
          </Field>
          <Field label="العمل المنجز">
            <select value={o.workDone || ""} onChange={(e) => update("stdOps", o.id, { workDone: e.target.value })} disabled={!can.manage} style={input}>
              <option value="">—</option>{WORK_DONE.map((r) => <option key={r}>{r}</option>)}
            </select>
          </Field>
        </div>
      )}

      {sub === "الاستخدام" && (<>
        <Section title={"تعريفات العمل (" + u.defs.length + ") — مرجع: تحديث العملية ينعكس عليها"}>
          {u.defs.map((d) => <div key={d.id} style={card()}><Row main={d.name} /></div>)}
          {u.defs.length === 0 && <Empty text="غير مستخدمة في تعريفات عمل." />}
        </Section>
        <Section title={"أوامر العمل (" + u.wos.length + ") — نسخة: لا تتأثر بالتحديث"}>
          {u.wos.map((w) => <div key={w.id} style={card()}><Row main={w.number + " — " + w.title} badge={{ text: w.status, color: WO_COLORS[w.status] }} /></div>)}
          {u.wos.length === 0 && <Empty text="غير مستخدمة في أوامر عمل." />}
        </Section>
      </>)}

      {edit && (
        <FormSheet title="تعديل العملية القياسية" onClose={() => setEdit(false)} db={db} schema={opSchema(o)} initial={o}
          onSave={(d) => { const err = validate(d, o); if (err) { alert(err); return; } update("stdOps", o.id, d); setEdit(false); }} />
      )}
      {resForm && (
        <FormSheet title={resForm === "new" ? "إضافة مورد" : "تعديل مورد"} onClose={() => setResForm(null)} db={db} schema={resSchema}
          initial={resForm === "new" ? { seq: ((o.resources || []).length + 1) * 10, units: 1, basis: "ثابت", usage: 1, chargeType: "يدوي", activity: "تنفيذ", scheduled: true, principal: (o.resources || []).length === 0 } : resForm}
          onSave={(d) => {
            const err = validateRes(d, resForm === "new" ? null : resForm);
            if (err) { alert(err); return; }
            patchRes(resForm === "new" ? [...(o.resources || []), { id: uid(), alternates: [], ...d }]
              : o.resources.map((x) => x.id === resForm.id ? { ...x, ...d } : x));
            setResForm(null);
          }} />
      )}
      {altFor && (
        <FormSheet title={"مورد بديل لـ " + nameOf("resources", altFor.resourceId)} onClose={() => setAltFor(null)} db={db}
          schema={[
            { k: "resourceId", label: "المورد البديل (نشط، نفس مركز العمل)", type: "select", from: "resources", fromKey: "name" },
            { k: "priority", label: "الأولوية", type: "number" },
          ]} initial={{ priority: ((altFor.alternates || []).length + 1) }}
          onSave={(d) => {
            if (!d.resourceId) { alert("اختر البديل"); return; }
            if (d.resourceId === altFor.resourceId) { alert("البديل لا يكون نفس المورد الأساسي"); return; }
            if ((altFor.alternates || []).some((a) => a.resourceId === d.resourceId)) { alert("البديل مضاف مسبقًا"); return; }
            const r = db.resources.find((x) => x.id === d.resourceId);
            if (o.workCenterId && r && r.workCenterId !== o.workCenterId) { alert("البديل يجب أن يتبع نفس مركز العمل"); return; }
            patchRes(o.resources.map((x) => x.id === altFor.id ? { ...x, alternates: [...(x.alternates || []), d] } : x));
            setAltFor(null);
          }} />
      )}
    </Sheet>
  );
}

function AttachForm({ onAdd }) {
  const [name, setName] = useState(""); const [type, setType] = useState("رابط"); const [value, setValue] = useState("");
  return (
    <div style={card()}>
      <Field label="اسم المرفق"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="فيديو تشحيم المحامل" style={input} /></Field>
      <div style={{ display: "flex", gap: 8 }}>
        <Field label="النوع">
          <select value={type} onChange={(e) => setType(e.target.value)} style={input}>{ATTACH_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
        </Field>
      </div>
      <Field label={type === "رابط" ? "الرابط (URL)" : "نص التعليمات"}>
        {type === "رابط"
          ? <input value={value} onChange={(e) => setValue(e.target.value)} placeholder="https://…" style={input} />
          : <textarea value={value} onChange={(e) => setValue(e.target.value)} rows={3} style={{ ...input, resize: "vertical" }} />}
      </Field>
      <Btn bg={C.ink} style={{ width: "100%" }} onClick={() => { if (name.trim()) { onAdd({ name, type, value }); setName(""); setValue(""); } }}>+ إضافة مرفق</Btn>
    </div>
  );
}

/* تعريفات العمل: عمليات + مواد + موارد + وقت (وثيقة التنفيذ §Work Definition) */
function WorkDefs({ ctx }) {
  return <Crud ctx={ctx} entity="workDefs" title="تعريفات العمل" schema={[
    { k: "name", label: "اسم التعريف (مثل: PM شهري للمصاعد)" },
    { k: "description", label: "الوصف", type: "textarea" },
    { k: "opIds", label: "العمليات (من القياسية)", type: "multi", from: "stdOps", fromKey: "name" },
    { k: "materials", label: "المواد المطلوبة (شحم، أدوات تنظيف…)" },
    { k: "resources", label: "الموارد المطلوبة (فني ميكانيكي + كهربائي…)" },
    { k: "estimatedHours", label: "الوقت التقديري (ساعات)", type: "number" },
  ]} render={(d) => [d.name, [(d.opIds || []).length + " عملية", d.estimatedHours ? d.estimatedHours + " ساعة" : "", d.materials].filter(Boolean).join(" · ")]} />;
}

/* ───────────────────────── طلبات العمل ───────────────────────── */
function Requests({ ctx, actRequest }) {
  const { db, nameOf, add, remove, can } = ctx;
  const [form, setForm] = useState(false);
  return (
    <>
      <Btn bg={C.orange} onClick={() => setForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ طلب عمل جديد</Btn>
      {db.workRequests.length === 0 && <Empty text="لاحظ المشغّل صوتًا غير طبيعي؟ يرفع طلب عمل من هنا." />}
      {db.workRequests.map((r) => (
        <div key={r.id} style={card()}>
          <Row main={r.title} sub={nameOf("assets", r.assetId) + " · خطورة " + r.severity + (r.desc ? " · " + r.desc : "")}
            badge={{ text: r.status, color: { "مفتوح": C.amber, "مقبول": C.blue, "محوّل": C.green, "مرفوض": C.red }[r.status] }} />
          {can.manage && (
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
              {(REQ_FLOW[r.status] || []).map((a) => (
                <Btn key={a} bg={a === "رفض" ? C.red : a === "قبول" ? C.blue : C.green} onClick={() => actRequest(r, a)}>{a}</Btn>
              ))}
              <button onClick={() => remove("workRequests", r.id)} style={delBtn}>حذف</button>
            </div>
          )}
        </div>
      ))}
      {form && (
        <FormSheet title="طلب عمل" onClose={() => setForm(false)} db={db}
          schema={[
            { k: "title", label: "وصف المشكلة (صوت غير طبيعي…)" },
            { k: "assetId", label: "الأصل", type: "select", from: "assets", fromKey: "name" },
            { k: "severity", label: "الخطورة", type: "select", options: ["منخفضة", "متوسطة", "حرجة"] },
            { k: "desc", label: "تفاصيل إضافية", type: "textarea" },
          ]} initial={{ severity: "متوسطة" }}
          onSave={(d) => {
            const exc = ctx.assetExclusion(d.assetId);
            if (exc.requests) { alert("⛔ الأصل مستبعد من طلبات العمل بواسطة مجموعة «" + exc.groupName + "»"); return; }
            add("workRequests", { status: "مفتوح", createdAt: today(), ...d }); setForm(false);
          }} />
      )}
    </>
  );
}

/* ───────────────────────── البرامج الوقائية ───────────────────────── */
function Programs({ ctx, programDue, generateWO }) {
  const { db, nameOf, add, remove, programAssets } = ctx;
  const [form, setForm] = useState(false);
  return (
    <>
      <Btn bg={C.orange} onClick={() => setForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ متطلب صيانة وقائية</Btn>
      {db.programs.length === 0 && <Empty text="مثال: مراوح الصوامع — كل 500 ساعة تشغيل ← أمر عمل تلقائي." />}
      {db.programs.map((p) => {
        const info = programDue(p);
        return (
          <div key={p.id} style={{ ...card(), borderRightColor: info.due ? C.red : info.soon ? C.amber : C.ink }}>
            <Row main={p.name}
              sub={[(p.targetType === "مجموعة" ? "مجموعة " + nameOf("assetGroups", p.assetGroupId) + " (" + programAssets(p).length + " أصل)" : nameOf("assets", p.assetId)),
                p.method + " كل " + p.interval, info.label].join(" · ")}
              action={info.due
                ? <Btn bg={C.orange} onClick={() => generateWO(p)}>إنشاء</Btn>
                : <Badge text={info.soon ? "قريبًا ⏳" : "غير مستحق"} color={info.soon ? C.amber : C.steel} />} />
            <button onClick={() => remove("programs", p.id)} style={delBtn}>حذف</button>
          </div>
        );
      })}
      {form && (
        <FormSheet title="متطلب وقائي" onClose={() => setForm(false)} db={db}
          schema={[
            { k: "name", label: "اسم المتطلب (فحص شهري للمصاعد…)" },
            { k: "targetType", label: "يطبق على", type: "select", options: ["أصل واحد", "مجموعة"] },
            { k: "assetId", label: "الأصل (لو أصل واحد)", type: "select", from: "assets", fromKey: "name" },
            { k: "assetGroupId", label: "المجموعة (لو مجموعة)", type: "select", from: "assetGroups", fromKey: "name" },
            { k: "workDefId", label: "تعريف العمل (قالب PM)", type: "select", from: "workDefs", fromKey: "name" },
            { k: "method", label: "طريقة التوقع", type: "select", options: ["فاصل أيام", "فاصل عداد"] },
            { k: "interval", label: "الفاصل (أيام أو وحدات عداد)", type: "number" },
            { k: "assetMeterId", label: "عداد الأصل (لطريقة العداد — أصل واحد فقط)", type: "select", from: "assetMeters",
              fromLabel: (m) => nameOf("assets", m.assetId) + " / " + nameOf("meterTemplates", m.templateId) },
            { k: "startDate", label: "تاريخ البداية", type: "date" },
          ]} initial={{ targetType: "أصل واحد", method: "فاصل أيام", startDate: today() }}
          onSave={(d) => {
            if (d.targetType === "مجموعة" && d.method === "فاصل عداد") { alert("طريقة العداد تعمل مع أصل واحد فقط — استخدم فاصل الأيام للمجموعات"); return; }
            if (d.targetType === "مجموعة" && !d.assetGroupId) { alert("اختر المجموعة"); return; }
            add("programs", { lastMeterValue: 0, ...d }); setForm(false);
          }} />
      )}
    </>
  );
}

/* ───────────────────────── الهرميات المنطقية ومسارات الأصول (ف3 §14) ───────────────────────── */
function LogicalHierarchies({ ctx, openAsset }) {
  const { db, add, update, remove, nameOf, can, createWO, assetUsable } = ctx;
  const [form, setForm] = useState(null);
  const topmostOnly = (a) => !a.parentId; /* لا تضف فرعًا ماديًا — الأب الأعلى فقط */
  return (
    <>
      <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 8 }}>
        الهرمية المنطقية تجمع أصولًا عبر المواقع (مصنع، خط، أسطول). فعّل «مسار أصول» لصيانة المجموعة بأمر عمل واحد.
      </div>
      {can.manage && <Btn bg={C.orange} onClick={() => setForm("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ هرمية منطقية / مسار</Btn>}
      {db.logicalHierarchies.length === 0 && <Empty text="مثال مسار: «فحص طفايات المبنى أ» — كل الطفايات في قائمة أمر عمل واحد مع سماح بالتخطي." />}
      {db.logicalHierarchies.map((h) => (
        <div key={h.id} style={{ ...card(), borderRightColor: h.assetRoute ? C.purple : C.ink, opacity: h.disabled ? 0.6 : 1 }}>
          <Row main={(h.code ? h.code + " — " : "") + h.name}
            badge={h.assetRoute ? { text: "مسار أصول", color: C.purple } : h.disabled ? { text: "معطلة", color: C.steel } : undefined}
            sub={[(h.nodes || []).length + " أصل", h.allowSkip ? "يسمح بالتخطي" : ""].filter(Boolean).join(" · ")} />
          <div style={{ display: "flex", gap: 10, marginTop: 6, flexWrap: "wrap" }}>
            {can.manage && <button onClick={() => setForm(h)} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>تعديل</button>}
            {can.manage && h.assetRoute && !h.disabled && (h.nodes || []).length > 0 && (
              <Btn bg={C.purple} onClick={() => {
                const nodes = (h.nodes || []).filter((id) => assetUsable(db.assets.find((x) => x.id === id)));
                if (!nodes.length) { alert("لا أصول صالحة في المسار"); return; }
                createWO({ title: "مسار — " + h.name, assetId: nodes[0], type: "وقائي", priority: "عادية",
                  plannedStart: today(), safetyRequired: true, routeId: h.id,
                  routeAssets: nodes.map((id) => ({ assetId: id, status: "معلق" })) });
                alert("✓ أُنشئ أمر عمل المسار يشمل " + nodes.length + " أصل");
              }}>إنشاء أمر عمل للمسار</Btn>
            )}
            {can.admin && <button onClick={() => { if (confirm("حذف الهرمية؟")) remove("logicalHierarchies", h.id); }} style={{ ...delBtn, marginTop: 0 }}>حذف</button>}
          </div>
        </div>
      ))}
      {form && (
        <FormSheet title={form === "new" ? "هرمية منطقية جديدة" : "تعديل هرمية"} onClose={() => setForm(null)} db={db}
          schema={[
            { k: "name", label: "الاسم (خط الطحن 1، أسطول الرياض…)" }, { k: "code", label: "الكود (فريد)" },
            { k: "description", label: "الوصف", type: "textarea" },
            { k: "assetRoute", label: "مسار أصول (صيانة المجموعة بأمر واحد)", type: "check" },
            { k: "allowSkip", label: "السماح بتخطي أصل أثناء التنفيذ", type: "check" },
            { k: "disabled", label: "معطلة", type: "check" },
            { k: "nodes", label: "الأصول (الأب الأعلى فقط — لا فروع مادية)", type: "multi", from: "assets", fromKey: "name" },
          ]} initial={form === "new" ? { nodes: [] } : form}
          onSave={(d) => {
            if (!String(d.name || "").trim()) { alert("الاسم مطلوب"); return; }
            if (d.code && db.logicalHierarchies.some((x) => x.code === d.code && x.id !== form?.id)) { alert("الكود مستخدم"); return; }
            const bad = (d.nodes || []).map((id) => db.assets.find((a) => a.id === id)).filter((a) => a && a.parentId);
            if (bad.length) { alert("هذه الأصول فروع مادية — أضف الأب الأعلى فقط:\n• " + bad.map((a) => a.name).join("\n• ")); return; }
            form === "new" ? add("logicalHierarchies", d) : update("logicalHierarchies", form.id, d);
            setForm(null);
          }} />
      )}
    </>
  );
}

/* ───────────────────────── مركز ضمان المورد (ف6) ───────────────────────── */
function WarrantyHub({ ctx, openWO }) {
  const { db, add, update, remove, nameOf, can, contractState, contractEffectiveEnd, contractCalcExpiration } = ctx;
  const [sub, setSub] = useState("العقود");
  const [covDetail, setCovDetail] = useState(null);
  const [claimDetail, setClaimDetail] = useState(null);
  const [contractForm, setContractForm] = useState(false);
  const SUBS = ["العقود", "التغطيات", "المطالبات", "الاستحقاقات", "أسعار العمالة", "أزمنة الإصلاح", "الموردون"];
  const stateColor = { "جاهز": C.green, "مسودة": C.steel, "منتهٍ": C.red };
  return (
    <>
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
        {SUBS.map((s) => <Chip key={s} active={sub === s} onClick={() => setSub(s)}>{s}</Chip>)}
      </div>

      {sub === "الموردون" && (
        <Crud ctx={ctx} entity="warrantyProviders" title="موردو الضمان" schema={[
          { k: "name", label: "اسم مورد الضمان / OEM" }, { k: "number", label: "رقم المورد" },
        ]} render={(p) => [p.name, p.number || ""]} />
      )}

      {sub === "أسعار العمالة" && (
        <Crud ctx={ctx} entity="laborRates" title="أسعار تعويض العمالة" schema={[
          { k: "providerId", label: "مورد الضمان", type: "select", from: "warrantyProviders", fromKey: "name" },
          { k: "hourlyRate", label: "سعر الساعة (ر.س)", type: "number" },
          { k: "startDate", label: "بداية السريان (≤ بداية العقد)", type: "date" },
          { k: "endDate", label: "نهاية السريان", type: "date" },
          { k: "active", label: "نشط", type: "check" },
        ]} render={(r) => [nameOf("warrantyProviders", r.providerId) + " — " + money(r.hourlyRate) + "/ساعة",
          fmt(r.startDate) + " ← " + (r.endDate ? fmt(r.endDate) : "مفتوح")]}
          badge={(r) => ({ text: r.active === false ? "موقوف" : "نشط", color: r.active === false ? C.steel : C.green })} />
      )}

      {sub === "أزمنة الإصلاح" && (
        <Crud ctx={ctx} entity="repairTimes" title="أزمنة الإصلاح القياسية" schema={[
          { k: "providerId", label: "مورد الضمان", type: "select", from: "warrantyProviders", fromKey: "name" },
          { k: "stdOpId", label: "العملية القياسية", type: "select", from: "stdOps", fromLabel: (o) => o.code + " — " + o.name },
          { k: "hours", label: "ساعات الإصلاح القابلة للتعويض", type: "number" },
          { k: "startDate", label: "بداية السريان", type: "date" },
          { k: "active", label: "نشط", type: "check" },
        ]} render={(t) => [nameOf("stdOps", t.stdOpId, "name") + " — " + t.hours + " ساعة",
          nameOf("warrantyProviders", t.providerId)]} />
      )}

      {sub === "التغطيات" && (<>
        {can.manage && <Btn bg={C.orange} onClick={() => setCovDetail("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ قالب تغطية جديد</Btn>}
        {db.coverages.length === 0 && <Empty text="التغطية قالب reusable: المدة و/أو فاصل عداد + شروط التعويض + أكواد الإصلاح المغطاة." />}
        {db.coverages.map((v) => (
          <div key={v.id} style={{ ...card(), borderRightColor: v.status === "جاهز" ? C.green : C.steel }} onClick={() => setCovDetail(v.id)}>
            <Row main={v.code + " — " + v.name} badge={{ text: v.status, color: v.status === "جاهز" ? C.green : C.steel }}
              sub={[nameOf("warrantyProviders", v.providerId), v.duration ? v.duration + " " + v.durationUom : "",
                (v.meters || []).length ? (v.meters || []).length + " عداد" : "",
                db.contracts.filter((c) => c.coverageId === v.id).length + " عقد"].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {sub === "العقود" && (<>
        {can.manage && <Btn bg={C.orange} onClick={() => setContractForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ عقد ضمان لأصل</Btn>}
        {db.contracts.length === 0 && <Empty text="العقد ينشأ من تغطية «جاهز» لأصل محدد — وينتهي بالمدة أو العداد أيهما أقرب." />}
        {db.contracts.map((c) => {
          const st = contractState(c);
          const calc = contractCalcExpiration(c);
          return (
            <div key={c.id} style={{ ...card(), borderRightColor: stateColor[st] }}>
              <Row main={c.number + " — " + nameOf("assets", c.assetId)} badge={{ text: st, color: stateColor[st] }}
                sub={[nameOf("coverages", c.coverageId), "يبدأ " + fmt(c.startDate),
                  c.endDate ? "ينتهي " + fmt(c.endDate) : "", calc ? "متوقع بالعداد: " + fmt(calc) : ""].filter(Boolean).join(" · ")} />
              {can.manage && (
                <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
                  {c.status === "مسودة" && <Btn bg={C.green} onClick={() => update("contracts", c.id, { status: "جاهز" })}>جاهز</Btn>}
                  <button onClick={() => { if (confirm("حذف العقد؟")) remove("contracts", c.id); }} style={delBtn}>حذف</button>
                </div>
              )}
            </div>
          );
        })}
      </>)}

      {sub === "المطالبات" && (<>
        {db.claims.length === 0 && <Empty text="المطالبات تُنشأ من زر «توليد الاستحقاقات» داخل أمر العمل ← تبويب الضمان." />}
        {db.claims.map((cl) => {
          const ents = db.entitlements.filter((e) => e.claimId === cl.id);
          const total = ents.reduce((s, e) => s + Number(e.total || 0), 0) + (cl.adjustments || []).reduce((s, a) => s + Number(a.amount || 0), 0);
          return (
            <div key={cl.id} style={card()} onClick={() => setClaimDetail(cl.id)}>
              <Row main={cl.number + " — " + nameOf("warrantyProviders", cl.providerId)}
                badge={{ text: cl.status, color: { "قيد المراجعة": C.amber, "مُقدمة": C.blue, "محلولة": C.green, "مرفوضة": C.red }[cl.status] || C.steel }}
                sub={[db.workOrders.find((w) => w.id === cl.workOrderId)?.number, ents.length + " استحقاق", money(total)].filter(Boolean).join(" · ")} />
            </div>
          );
        })}
      </>)}

      {sub === "الاستحقاقات" && (<>
        {db.entitlements.length === 0 && <Empty text="الاستحقاق = نفقة مادة/مورد/إصلاح قياسي قابلة أو غير قابلة للتعويض." />}
        {db.entitlements.slice().reverse().map((e) => (
          <div key={e.id} style={{ ...card(), borderRightColor: e.included ? C.green : C.steel }}>
            <Row main={e.type + " — " + e.description} badge={e.included ? { text: "ضمن مطالبة", color: C.green } : { text: "مستبعد", color: C.steel }}
              sub={[e.qty + " × " + money(e.unitCost) + " = " + money(e.total),
                db.workOrders.find((w) => w.id === e.workOrderId)?.number,
                e.contractId ? db.contracts.find((c) => c.id === e.contractId)?.number : "بدون عقد (لا مطابقة)"].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {covDetail && <CoverageDetail ctx={ctx} covId={covDetail} onClose={() => setCovDetail(null)} />}
      {claimDetail && <ClaimDetail ctx={ctx} claimId={claimDetail} onClose={() => setClaimDetail(null)} openWO={openWO} />}
      {contractForm && (
        <FormSheet title="عقد ضمان جديد" onClose={() => setContractForm(false)} db={db}
          schema={[
            { k: "assetId", label: "الأصل", type: "select", from: "assets", fromLabel: (a) => a.number + " — " + a.name },
            { k: "coverageId", label: "التغطية (جاهز فقط)", type: "select", from: "coverages", fromLabel: (v) => v.code + " — " + v.name + (v.status !== "جاهز" ? " (مسودة ✗)" : "") },
            { k: "startDate", label: "بداية التغطية", type: "date" },
            { k: "extRef", label: "مرجع خارجي (رقم أمر الشراء…)" },
            { k: "notes", label: "ملاحظات العقد", type: "textarea" },
          ]} initial={{ startDate: today() }}
          onSave={(d) => {
            if (!d.assetId || !d.coverageId) { alert("اختر الأصل والتغطية"); return; }
            const cov = db.coverages.find((v) => v.id === d.coverageId);
            if (cov.status !== "جاهز") { alert("التغطية مسودة — يجب أن تكون «جاهز» لإنشاء عقود (قاعدة ف6)"); return; }
            let endDate = "";
            if (cov.duration) {
              endDate = addDateDays(d.startDate || today(), Number(cov.duration || 0) * (DUR_UOM[cov.durationUom] || 1));
            }
            /* عدادات التغطية يجب أن تطابق عدادات الأصل، وإلا يبقى العقد مسودة للمراجعة */
            const meters = (cov.meters || []).filter((m) => m.enabled !== false).map((m) => ({ ...m }));
            const mismatch = meters.some((m) => !db.assetMeters.some((am) => am.assetId === d.assetId && am.templateId === m.templateId));
            add("contracts", { number: "CW-" + String(1000 + db.contracts.length + 1), status: mismatch ? "مسودة" : "جاهز",
              endDate, meters, ...d });
            if (mismatch) alert("⚠ عدادات التغطية لا تطابق عدادات الأصل — أُنشئ العقد كمسودة للمراجعة");
            setContractForm(false);
          }} />
      )}
    </>
  );
}

function CoverageDetail({ ctx, covId, onClose }) {
  const { db, add, update, nameOf, can } = ctx;
  const isNew = covId === "new";
  const v = isNew ? null : db.coverages.find((x) => x.id === covId);
  const [f, setF] = useState(isNew ? { status: "مسودة", durationUom: "شهر", laborReimb: true, partsReimb: true, startDate: today() } : null);
  const hasContracts = v ? db.contracts.some((c) => c.coverageId === v.id) : false;
  if (isNew) {
    return (
      <FormSheet title="قالب تغطية — الأساسيات" onClose={onClose} db={db}
        schema={[
          { k: "code", label: "الكود (فريد، لا يتغير بعد الإنشاء)" }, { k: "name", label: "اسم التغطية" },
          { k: "description", label: "الوصف", type: "textarea" },
          { k: "providerId", label: "مورد الضمان (إلزامي)", type: "select", from: "warrantyProviders", fromKey: "name" },
          { k: "type", label: "نوع التغطية", type: "select", options: COV_TYPES },
          { k: "startDate", label: "بداية القالب", type: "date" }, { k: "endDate", label: "نهاية القالب (يمنع عقودًا جديدة)", type: "date" },
          { k: "duration", label: "مدة الضمان (اتركها فارغة لو عداد فقط)", type: "number" },
          { k: "durationUom", label: "وحدة المدة", type: "select", options: Object.keys(DUR_UOM) },
          { k: "laborReimb", label: "تعويض العمالة (الموارد تدخل المطالبة)", type: "check" },
          { k: "partsReimb", label: "تعويض القطع (المواد تدخل المطالبة)", type: "check" },
          { k: "terms", label: "شروط الخدمة (نص حر)", type: "textarea" },
        ]} initial={f}
        onSave={(d) => {
          if (!d.code || !d.name) { alert("الكود والاسم مطلوبان"); return; }
          if (db.coverages.some((x) => x.code === d.code)) { alert("الكود مستخدم"); return; }
          if (!d.providerId) { alert("مورد الضمان إلزامي"); return; }
          add("coverages", { status: "مسودة", meters: [], repairCodes: [], items: [], ...d });
          onClose();
        }} />
    );
  }
  if (!v) return null;
  return (
    <Sheet title={v.code + " — " + v.name} onClose={onClose}>
      <div style={{ display: "flex", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
        <Badge text={v.status} color={v.status === "جاهز" ? C.green : C.steel} />
        {can.manage && v.status === "مسودة" && (
          <Btn bg={C.green} onClick={() => {
            if (!v.duration && !(v.meters || []).some((m) => m.enabled !== false)) { alert("«جاهز» يتطلب مدة أو فاصل عداد — العقد يحتاج طريقة انتهاء (قاعدة ف6)"); return; }
            update("coverages", v.id, { status: "جاهز" });
          }}>تحويل إلى جاهز</Btn>
        )}
        {can.manage && v.status === "جاهز" && !hasContracts && <Btn bg={C.steel} onClick={() => update("coverages", v.id, { status: "مسودة" })}>إرجاع لمسودة</Btn>}
        {hasContracts && <span style={{ fontSize: 12, color: C.steel, alignSelf: "center" }}>توجد عقود — لا رجوع لمسودة ولا حذف صفوف (عطّل بدلًا منه)</span>}
      </div>
      <div style={{ ...card(), fontSize: 13.5, lineHeight: 2 }}>
        المورد: <b>{nameOf("warrantyProviders", v.providerId)}</b> · النوع: <b>{v.type || "—"}</b><br />
        المدة: <b>{v.duration ? v.duration + " " + v.durationUom : "—"}</b> · تعويض العمالة: <b>{v.laborReimb ? "نعم" : "لا"}</b> · تعويض القطع: <b>{v.partsReimb ? "نعم" : "لا"}</b>
        {v.terms && <><br />الشروط: {v.terms}</>}
      </div>
      <Section title={"عدادات الاستخدام (" + (v.meters || []).length + ") — ينتهي العقد بالأقرب"}>
        {(v.meters || []).map((m) => (
          <div key={m.id} style={{ ...card(), opacity: m.enabled === false ? 0.5 : 1 }}>
            <Row main={nameOf("meterTemplates", m.templateId)} sub={"من " + m.startValue + " + فاصل " + m.interval + " = نهاية " + (Number(m.startValue || 0) + Number(m.interval || 0))}
              action={can.manage && m.enabled !== false ? <Btn bg={C.steel} onClick={() => update("coverages", v.id, { meters: v.meters.map((x) => x.id === m.id ? { ...x, enabled: false } : x) })}>تعطيل</Btn> : m.enabled === false ? <Badge text="معطل" color={C.steel} /> : null} />
          </div>
        ))}
        {can.manage && <CovMeterForm ctx={ctx} onAdd={(m) => update("coverages", v.id, { meters: [...(v.meters || []), { id: uid(), enabled: true, ...m }] })} />}
      </Section>
      <Section title={"أكواد الإصلاح المغطاة (" + (v.repairCodes || []).length + ")"}>
        <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 6 }}>مثال: 013 فرامل ← 013-001 فرامل أمامية. الكود الأعلى يغطي ما تحته.</div>
        {(v.repairCodes || []).map((r) => (
          <div key={r.id} style={{ ...card(), opacity: r.enabled === false ? 0.5 : 1 }}>
            <Row main={r.code} sub={r.description}
              action={can.manage && r.enabled !== false ? <Btn bg={C.steel} onClick={() => update("coverages", v.id, { repairCodes: v.repairCodes.map((x) => x.id === r.id ? { ...x, enabled: false } : x) })}>تعطيل</Btn> : r.enabled === false ? <Badge text="معطل" color={C.steel} /> : null} />
          </div>
        ))}
        {can.manage && <AddInline placeholder="الكود، الوصف (ELV-BRG، محامل المصاعد)" onAdd={(t) => {
          const seg = t.includes("،") ? t.split("،") : t.split(",");
          update("coverages", v.id, { repairCodes: [...(v.repairCodes || []), { id: uid(), code: (seg[0] || t).trim(), description: (seg[1] || "").trim(), enabled: true }] });
        }} />}
      </Section>
      <Section title={"العقود المنشأة (" + db.contracts.filter((c) => c.coverageId === v.id).length + ")"}>
        {db.contracts.filter((c) => c.coverageId === v.id).map((c) => (
          <div key={c.id} style={card()}><Row main={c.number + " — " + nameOf("assets", c.assetId)} sub={"يبدأ " + fmt(c.startDate)} /></div>
        ))}
      </Section>
    </Sheet>
  );
}

function CovMeterForm({ ctx, onAdd }) {
  const { db } = ctx;
  const [tpl, setTpl] = useState(""); const [start, setStart] = useState("0"); const [intv, setIntv] = useState("");
  return (
    <div style={card()}>
      <div style={{ display: "flex", gap: 8 }}>
        <Field label="قالب العداد">
          <select value={tpl} onChange={(e) => setTpl(e.target.value)} style={input}>
            <option value="">—</option>
            {db.meterTemplates.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.uom})</option>)}
          </select>
        </Field>
        <Field label="البداية"><input type="number" value={start} onChange={(e) => setStart(e.target.value)} style={input} /></Field>
        <Field label="الفاصل (5000…)"><input type="number" value={intv} onChange={(e) => setIntv(e.target.value)} style={input} /></Field>
      </div>
      <Btn bg={C.ink} style={{ width: "100%" }} onClick={() => {
        if (!tpl || !Number(intv)) { alert("اختر العداد وأدخل الفاصل"); return; }
        onAdd({ templateId: tpl, startValue: Number(start || 0), interval: Number(intv) });
        setTpl(""); setStart("0"); setIntv("");
      }}>+ إضافة فاصل عداد</Btn>
    </div>
  );
}

function ClaimDetail({ ctx, claimId, onClose, openWO }) {
  const { db, update, remove, nameOf, can, woCost } = ctx;
  const cl = db.claims.find((x) => x.id === claimId);
  const [adj, setAdj] = useState("");
  if (!cl) return null;
  const wo = db.workOrders.find((w) => w.id === cl.workOrderId);
  const allEnts = db.entitlements.filter((e) => e.workOrderId === cl.workOrderId);
  const inc = allEnts.filter((e) => e.claimId === cl.id);
  const adjTotal = (cl.adjustments || []).reduce((s, a) => s + Number(a.amount || 0), 0);
  const total = inc.reduce((s, e) => s + Number(e.total || 0), 0) + adjTotal;
  const byType = {};
  inc.forEach((e) => { byType[e.type] = (byType[e.type] || 0) + Number(e.total || 0); });
  const woTotal = wo ? woCost(wo).total : 0;
  return (
    <Sheet title={"مطالبة " + cl.number} onClose={onClose}>
      <div style={{ ...card(), fontSize: 13.5, lineHeight: 2 }}>
        المورد: <b>{nameOf("warrantyProviders", cl.providerId)}</b> · الأمر: <b style={{ textDecoration: "underline" }} onClick={() => wo && openWO(wo.id)}>{wo?.number || "—"}</b><br />
        مبلغ المطالبة: <b>{money(total)}</b> · تكلفة الأمر: <b>{money(woTotal)}</b>
        {total !== woTotal && <span style={{ color: C.amber }}> (الفرق = معاملات لم تدخل المطالبة)</span>}
      </div>
      {can.manage && (<>
        <div style={{ display: "flex", gap: 8 }}>
          <Field label="حالة المطالبة">
            <select value={cl.status} onChange={(e) => update("claims", cl.id, { status: e.target.value, ...(e.target.value === "محلولة" ? { resolutionDate: today() } : {}) })} style={input}>
              {CLAIM_STATUS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="موعد التقديم"><input type="date" value={cl.submitBy || ""} onChange={(e) => update("claims", cl.id, { submitBy: e.target.value })} style={input} /></Field>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Field label="المسؤول"><input value={cl.assignedTo || ""} onChange={(e) => update("claims", cl.id, { assignedTo: e.target.value })} style={input} /></Field>
          <Field label="مبلغ التعويض الفعلي"><input type="number" value={cl.reimbursementAmount || ""} onChange={(e) => update("claims", cl.id, { reimbursementAmount: e.target.value })} style={input} /></Field>
        </div>
      </>)}
      <Section title={"الاستحقاقات — إدخال/إخراج (" + inc.length + "/" + allEnts.length + ")"}>
        {allEnts.map((e) => {
          const isIn = e.claimId === cl.id;
          return (
            <div key={e.id} style={{ ...card(), borderRightColor: isIn ? C.green : C.steel, opacity: isIn ? 1 : 0.65 }}>
              <Row main={e.type + " — " + e.description} sub={e.qty + " × " + money(e.unitCost) + " = " + money(e.total) + (e.contractId ? "" : " · بدون عقد")}
                action={can.manage ? (isIn
                  ? <Btn bg={C.steel} onClick={() => update("entitlements", e.id, { claimId: "", included: false })}>إخراج</Btn>
                  : <Btn bg={C.green} onClick={() => update("entitlements", e.id, { claimId: cl.id, included: true })}>إدخال</Btn>) : null} />
            </div>
          );
        })}
      </Section>
      <Section title="مراجعة المبالغ">
        <div style={card()}>
          {Object.entries(byType).map(([t, s]) => (
            <div key={t} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4 }}><span>{t}</span><b>{money(s)}</b></div>
          ))}
          {(cl.adjustments || []).map((a, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4, color: C.amber }}><span>تعديل: {a.desc}</span><b>{money(a.amount)}</b></div>
          ))}
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 15, borderTop: `1px solid ${C.line}`, paddingTop: 6, fontWeight: 800 }}>
            <span>الإجمالي</span><span>{money(total)}</span>
          </div>
        </div>
        {can.manage && (
          <div style={{ display: "flex", gap: 8 }}>
            <input type="number" value={adj} onChange={(e) => setAdj(e.target.value)} placeholder="مبلغ تعديل +/−" style={input} />
            <Btn bg={C.amber} onClick={() => { if (adj !== "") { update("claims", cl.id, { adjustments: [...(cl.adjustments || []), { desc: "تعديل يدوي", amount: Number(adj) }] }); setAdj(""); } }}>إضافة</Btn>
          </div>
        )}
      </Section>
      {can.admin && <Btn bg={C.red} style={{ width: "100%", padding: 12 }} onClick={() => { if (confirm("حذف المطالبة؟ (الاستحقاقات تبقى)")) { db.entitlements.filter((e) => e.claimId === cl.id).forEach((e) => update("entitlements", e.id, { claimId: "", included: false })); remove("claims", cl.id); onClose(); } }}>حذف المطالبة</Btn>}
    </Sheet>
  );
}

/* ───────────────────────── المخزون وقطع الغيار (وثيقة المخزون) ───────────────────────── */
function Inventory({ ctx, openWO }) {
  const { db, add, update, remove, nameOf, can, onHand, reservedQty, availableQty, addTx } = ctx;
  const [sub, setSub] = useState("الرصيد");
  const [txForm, setTxForm] = useState(null); // نوع الحركة
  const [stockCard, setStockCard] = useState(null);
  const SUBS = ["الرصيد", "الأصناف", "المستودعات", "الحركات", "التجهيز والصرف", "تنبيهات", "تقارير"];
  const canStock = can.warehouse; /* لا تعديل مخزون مباشر من الفني */

  /* قوائم التجهيز: أوامر مفتوحة فيها مواد محجوزة لم تُصرف */
  const pickWOs = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status) &&
    (w.materials || []).some((m) => m.itemId && m.reserved && !Number(m.issuedQty || 0)));
  const lowStock = db.items.filter((i) => i.min !== "" && i.min != null && onHand(i.id) <= Number(i.min));
  const valuation = db.items.reduce((s, i) => s + onHand(i.id) * Number(i.unitCost || 0), 0);

  /* استهلاك المواد حسب الأصل */
  const consumptionByAsset = {};
  db.workOrders.forEach((w) => (w.materials || []).forEach((m) => {
    const c = Number(m.usedQty || 0) * Number(m.unitCost || 0);
    if (c > 0) consumptionByAsset[w.assetId] = (consumptionByAsset[w.assetId] || 0) + c;
  }));
  const consumption = Object.entries(consumptionByAsset).map(([id, c]) => ({ name: nameOf("assets", id), c })).sort((a, b) => b.c - a.c).slice(0, 8);

  return (
    <>
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
        {SUBS.map((s) => <Chip key={s} active={sub === s} onClick={() => setSub(s)}>{s}</Chip>)}
      </div>

      {sub === "الأصناف" && (
        <Crud ctx={ctx} entity="items" title="ماستر الأصناف" schema={[
          { k: "code", label: "كود الصنف (BRG-6312…)" }, { k: "name", label: "اسم الصنف" },
          { k: "category", label: "الفئة", type: "select", options: ITEM_CATS },
          { k: "uom", label: "وحدة القياس (قطعة، لتر…)" },
          { k: "unitCost", label: "تكلفة الوحدة (ر.س)", type: "number" },
          { k: "min", label: "الحد الأدنى", type: "number" }, { k: "max", label: "الحد الأقصى", type: "number" },
          { k: "critical", label: "قطعة حرجة", type: "check" },
        ]} render={(i) => [i.code + " — " + i.name,
          [i.category, "رصيد " + onHand(i.id) + " " + (i.uom || ""), money(i.unitCost) + "/وحدة", i.critical ? "⚠ حرجة" : ""].filter(Boolean).join(" · ")]} />
      )}

      {sub === "المستودعات" && (
        <Crud ctx={ctx} entity="warehouses" title="المستودعات والمخازن الفرعية" schema={[
          { k: "name", label: "اسم المستودع/المخزن" }, { k: "code", label: "الرمز" },
          { k: "location", label: "الموقع" },
        ]} render={(w) => [w.name, [w.code, w.location].filter(Boolean).join(" · ")]} />
      )}

      {sub === "الرصيد" && (<>
        {canStock && (
          <div style={{ display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap" }}>
            <Btn bg={C.green} onClick={() => setTxForm("استلام")}>+ استلام</Btn>
            <Btn bg={C.blue} onClick={() => setTxForm("تحويل")}>تحويل</Btn>
            <Btn bg={C.amber} onClick={() => setTxForm("تسوية")}>تسوية</Btn>
            <Btn bg={C.red} onClick={() => setTxForm("إتلاف")}>إتلاف</Btn>
          </div>
        )}
        {db.items.length === 0 && <Empty text="أضف الأصناف أولًا من تبويب «الأصناف» ثم سجّل استلامًا." />}
        {db.items.map((i) => {
          const oh = onHand(i.id), rs = reservedQty(i.id), av = oh - rs;
          const low = i.min !== "" && i.min != null && oh <= Number(i.min);
          return (
            <div key={i.id} style={{ ...card(), borderRightColor: low ? C.red : C.ink }} onClick={() => setStockCard(i)}>
              <Row main={i.code + " — " + i.name}
                sub={"الرصيد: " + oh + " · محجوز: " + rs + " · المتاح: " + av + " " + (i.uom || "") + (low ? " · ⚠ تحت الحد الأدنى (" + i.min + ")" : "")}
                badge={i.critical ? { text: "حرجة", color: C.red } : undefined} />
            </div>
          );
        })}
      </>)}

      {sub === "الحركات" && (<>
        {db.stockTx.length === 0 && <Empty text="لا حركات بعد — الرصيد لا يتغير إلا بحركة (قاعدة النظام)." />}
        {db.stockTx.slice().reverse().slice(0, 50).map((t) => (
          <div key={t.id} style={{ ...card(), borderRightColor: ["صرف لأمر عمل", "إتلاف"].includes(t.type) ? C.red : t.type === "استلام" || t.type === "إرجاع من أمر عمل" ? C.green : C.amber }}>
            <Row main={t.type + " — " + nameOf("items", t.itemId)}
              sub={["كمية " + t.qty, t.at, t.workOrderId ? db.workOrders.find((w) => w.id === t.workOrderId)?.number : "",
                t.warehouseId ? nameOf("warehouses", t.warehouseId) : "", t.note].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {sub === "التجهيز والصرف" && (<>
        {pickWOs.length === 0 && <Empty text="لا مواد محجوزة بانتظار التجهيز. تُحجز المواد من داخل أمر العمل." />}
        {pickWOs.map((w) => (
          <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
            <Row main={"قائمة تجهيز — " + w.number} badge={{ text: w.status, color: WO_COLORS[w.status] }}
              sub={(w.materials || []).filter((m) => m.reserved && !Number(m.issuedQty || 0))
                .map((m) => nameOf("items", m.itemId) + " ×" + m.qty).join("، ")} />
          </div>
        ))}
      </>)}

      {sub === "تنبيهات" && (<>
        {lowStock.length === 0 && <Empty text="لا أصناف تحت الحد الأدنى. 👌" />}
        {lowStock.map((i) => (
          <div key={i.id} style={{ ...card(), borderRightColor: C.red }}>
            <Row main={i.code + " — " + i.name}
              sub={"الرصيد " + onHand(i.id) + " ≤ الحد الأدنى " + i.min + " — أنشئ طلب شراء"}
              badge={i.critical ? { text: "حرجة ⚠", color: C.red } : { text: "إعادة طلب", color: C.amber }} />
          </div>
        ))}
      </>)}

      {sub === "تقارير" && (<>
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          <Stat n={money(valuation)} label="قيمة المخزون" color={C.blue} small />
          <Stat n={db.items.length} label="أصناف" color={C.ink} />
          <Stat n={lowStock.length} label="تحت الحد" color={lowStock.length ? C.red : C.steel} />
        </div>
        <Section title="استهلاك المواد حسب الأصل (ر.س)">
          {consumption.length === 0 && <Empty text="سيظهر عند صرف واستخدام مواد على أوامر العمل." />}
          <div style={card()}>
            {consumption.map((x) => (
              <div key={x.name} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4 }}>
                <span>{x.name}</span><b>{money(x.c)}</b>
              </div>
            ))}
          </div>
        </Section>
      </>)}

      {txForm && (
        <FormSheet title={"حركة مخزون — " + txForm} onClose={() => setTxForm(null)} db={db}
          schema={[
            { k: "itemId", label: "الصنف", type: "select", from: "items", fromLabel: (i) => i.code + " — " + i.name },
            { k: "qty", label: txForm === "تسوية" ? "الكمية (+/−)" : "الكمية", type: "number" },
            ...(db.warehouses.length ? [{ k: "warehouseId", label: txForm === "تحويل" ? "من مستودع" : "المستودع", type: "select", from: "warehouses", fromKey: "name" }] : []),
            ...(txForm === "تحويل" ? [{ k: "toWarehouseId", label: "إلى مستودع", type: "select", from: "warehouses", fromKey: "name" }] : []),
            { k: "note", label: "ملاحظة" },
          ]} initial={{ qty: 1 }}
          onSave={(d) => {
            if (!d.itemId) { alert("اختر الصنف"); return; }
            if (["صرف لأمر عمل", "إتلاف"].includes(txForm) && Number(d.qty) > onHand(d.itemId)) { alert("الكمية أكبر من الرصيد"); return; }
            if (txForm === "إتلاف" && Number(d.qty) > onHand(d.itemId)) { alert("الكمية أكبر من الرصيد"); return; }
            addTx({ type: txForm, ...d }); setTxForm(null);
          }} />
      )}
      {stockCard && (
        <Sheet title={"بطاقة صنف — " + stockCard.code} onClose={() => setStockCard(null)}>
          <div style={{ ...card(), fontSize: 14, lineHeight: 2 }}>
            <b>{stockCard.name}</b> · {stockCard.category || "—"}<br />
            الرصيد: <b>{onHand(stockCard.id)}</b> · محجوز: <b>{reservedQty(stockCard.id)}</b> · المتاح: <b>{availableQty(stockCard.id)}</b> {stockCard.uom || ""}<br />
            تكلفة الوحدة: {money(stockCard.unitCost)} · قيمة الرصيد: <b>{money(onHand(stockCard.id) * Number(stockCard.unitCost || 0))}</b>
          </div>
          <Section title="يُستخدم في الأصول">
            {db.assets.filter((a) => (a.parts || []).some((p) => p.itemId === stockCard.id || p.name === stockCard.name)).map((a) => (
              <div key={a.id} style={card()}><Row main={a.number + " — " + a.name} sub={a.location} /></div>
            ))}
            {db.assets.filter((a) => (a.parts || []).some((p) => p.itemId === stockCard.id || p.name === stockCard.name)).length === 0 &&
              <Empty text="غير مربوط بأصول — اربطه من ملف الأصل ← قطع الغيار." />}
          </Section>
          <Section title="الحركات (بطاقة الصنف)">
            {db.stockTx.filter((t) => t.itemId === stockCard.id).slice().reverse().map((t) => (
              <div key={t.id} style={{ fontSize: 13, color: C.steel, marginBottom: 4, borderBottom: `1px dashed ${C.line}`, paddingBottom: 4 }}>
                <b style={{ color: C.ink }}>{t.type}</b> · {t.qty} · {t.at}
                {t.workOrderId ? " · " + (db.workOrders.find((w) => w.id === t.workOrderId)?.number || "") : ""}
              </div>
            ))}
            {db.stockTx.filter((t) => t.itemId === stockCard.id).length === 0 && <Empty text="لا حركات لهذا الصنف." />}
          </Section>
        </Sheet>
      )}
    </>
  );
}

/* ───────────────────────── الأصول ───────────────────────── */
/* ───────────────────────── مجموعات الأصول: قواعد ← مجموعات ← تعيينات (ف4) ───────────────────────── */
function AssetGroups({ ctx }) {
  const { db, add, update, remove, nameOf, can, groupRule, groupActive, activeAssignments } = ctx;
  const [sub, setSub] = useState("المجموعات");
  const [q, setQ] = useState("");
  const [ruleForm, setRuleForm] = useState(null);
  const [groupForm, setGroupForm] = useState(null);
  const [detail, setDetail] = useState(null);
  const stdRule = () => {
    let r = db.assetGroupRules.find((x) => x.code === "STD");
    if (!r) r = add("assetGroupRules", { name: "التصنيف القياسي", code: "STD", description: "", attributes: [], usages: ["عام (صيانة وبرامج)"], enforceUnique: false, inactiveOn: "" });
    return r;
  };
  const missing = STANDARD_GROUPS.filter(([code]) => !db.assetGroups.some((g) => g.code === code));
  const seed = () => {
    const r = stdRule();
    missing.forEach(([code, name], i) => add("assetGroups", { code, name, ruleId: r.id,
      number: "AG-" + String(100 + db.assetGroups.length + i + 1), description: "", attrValues: {},
      excludeFromRequests: false, excludeFromWO: false, inactiveOn: "", assignments: [], assetIds: [] }));
  };
  const ruleHasGroups = (rid) => db.assetGroups.some((g) => g.ruleId === rid);
  const ruleHasAssignments = (rid) => db.assetGroups.some((g) => g.ruleId === rid && (g.assignments || []).length > 0);
  const isStatusRule = (r) => (r.usages || []).includes("حالة الأصل (قاعدة تحقق)");

  const ruleSchema = (editing) => [
    { k: "name", label: "اسم القاعدة" }, { k: "code", label: "الكود (فريد)" },
    { k: "description", label: "الوصف", type: "textarea" },
    { k: "usages", label: "الاستخدامات", type: "multi-static", options: RULE_USAGES },
    { k: "attributes", label: "خصائص التجميع" + (editing && ruleHasGroups(editing.id) ? " — مقفلة (توجد مجموعات)" : ""), type: "multi-static", options: GROUP_ATTRS.map(([, l]) => l) },
    { k: "enforceUnique", label: "تعيين فريد (الأصل في مجموعة واحدة ضمن القاعدة)" + (editing && ruleHasAssignments(editing.id) ? " — مقفل (توجد تعيينات)" : ""), type: "check" },
    { k: "inactiveOn", label: "تعطيل اعتبارًا من (لا مجموعات جديدة بعده)", type: "date" },
  ];
  const attrKeyByLabel = (l) => GROUP_ATTRS.find(([, lab]) => lab === l)?.[0] || l;
  const validateRule = (d, editing) => {
    if (!String(d.name || "").trim() || !String(d.code || "").trim()) return "الاسم والكود مطلوبان";
    if (db.assetGroupRules.some((r) => r.code === d.code && r.id !== editing?.id)) return "الكود مستخدم";
    if (!(d.usages || []).length) return "اختر استخدامًا واحدًا على الأقل";
    if ((d.usages || []).includes("حالة الأصل (قاعدة تحقق)")) {
      if ((d.usages || []).length > 1) return "«حالة الأصل» لا يجتمع مع استخدامات أخرى (قاعدة ف4)";
      if ((d.attributes || []).length) return "«حالة الأصل»: خصائص التجميع معطلة — أي أصل يمكن تعيينه";
      d.enforceUnique = true; /* إجباري */
      if (db.assetGroupRules.some((r) => r.id !== editing?.id && (r.usages || []).includes("حالة الأصل (قاعدة تحقق)")))
        return "قاعدة واحدة فقط من نوع «حالة الأصل» مسموحة";
    }
    if (editing) {
      const oldAttrs = JSON.stringify((editing.attributes || []).slice().sort());
      if (JSON.stringify((d.attributes || []).slice().sort()) !== oldAttrs && ruleHasGroups(editing.id)) return "لا تغيّر خصائص التجميع — توجد مجموعات تحت القاعدة";
      if (!!d.enforceUnique !== !!editing.enforceUnique && ruleHasAssignments(editing.id)) return "لا تغيّر «التعيين الفريد» — توجد أصول معينة";
    }
    return null;
  };

  let groups = db.assetGroups.filter((g) => !q || ((g.name || "") + (g.number || "") + (g.code || "") + (groupRule(g)?.name || "")).includes(q));

  return (
    <>
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        <Chip active={sub === "المجموعات"} onClick={() => setSub("المجموعات")}>المجموعات ({db.assetGroups.length})</Chip>
        <Chip active={sub === "القواعد"} onClick={() => setSub("القواعد")}>القواعد ({db.assetGroupRules.length})</Chip>
      </div>

      {sub === "القواعد" && (<>
        {can.manage && <Btn bg={C.orange} onClick={() => setRuleForm("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ قاعدة مجموعات جديدة</Btn>}
        {db.assetGroupRules.length === 0 && <Empty text="ابدأ بالقاعدة: «مركبات حسب الموقع» بخاصية الموقع، ثم أنشئ مجموعاتها." />}
        {db.assetGroupRules.map((r) => (
          <div key={r.id} style={{ ...card(), borderRightColor: isStatusRule(r) ? C.red : C.ink, opacity: (!r.inactiveOn || r.inactiveOn >= today()) ? 1 : 0.6 }}
            onClick={() => can.manage && setRuleForm(r)}>
            <Row main={r.code + " — " + r.name}
              badge={isStatusRule(r) ? { text: "حالة الأصل", color: C.red } : r.enforceUnique ? { text: "فريد", color: C.purple } : undefined}
              sub={[(r.attributes || []).length ? "خصائص: " + (r.attributes || []).join("، ") : "بلا خصائص",
                db.assetGroups.filter((g) => g.ruleId === r.id).length + " مجموعة",
                r.inactiveOn && r.inactiveOn < today() ? "معطلة" : ""].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {sub === "المجموعات" && (<>
        {missing.length > 0 && (
          <div style={{ ...card(), borderRightColor: C.blue, marginBottom: 12 }}>
            <Row main="مجموعات المطاحن القياسية" sub={missing.length + " مجموعة جاهزة تحت قاعدة «التصنيف القياسي»"}
              action={<Btn bg={C.blue} onClick={seed}>إضافتها دفعة واحدة</Btn>} />
          </div>
        )}
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث بالرقم/الاسم/القاعدة…" style={{ ...input, marginBottom: 10 }} />
        {can.manage && <Btn bg={C.orange} onClick={() => {
          if (!db.assetGroupRules.length) { alert("أنشئ قاعدة أولًا — لا مجموعة بدون قاعدة (قاعدة ف4)"); setSub("القواعد"); return; }
          setGroupForm("new");
        }} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ مجموعة جديدة</Btn>}
        {groups.length === 0 && <Empty text="لا مجموعات مطابقة." />}
        {groups.map((g) => (
          <div key={g.id} style={{ ...card(), opacity: groupActive(g) ? 1 : 0.6 }} onClick={() => setDetail(g.id)}>
            <Row main={(g.number ? g.number + " — " : "") + g.name}
              badge={(g.excludeFromWO || g.excludeFromRequests) ? { text: "استبعاد ⛔", color: C.red } : !groupActive(g) ? { text: "معطلة", color: C.steel } : undefined}
              sub={[groupRule(g)?.name || "بدون قاعدة", activeAssignments(g).length + " أصل معين",
                Object.entries(g.attrValues || {}).filter(([, v]) => v).map(([k, v]) => (GROUP_ATTRS.find(([kk]) => kk === k)?.[1] || k) + ": " + (k === "workCenterId" ? nameOf("workCenters", v) : v)).join("، ")].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {ruleForm && (
        <RuleFormSheet ctx={ctx} schema={ruleSchema(ruleForm === "new" ? null : ruleForm)} initial={ruleForm === "new" ? { usages: ["عام (صيانة وبرامج)"], attributes: [] } : { ...ruleForm }}
          title={ruleForm === "new" ? "قاعدة جديدة" : "تعديل قاعدة"} onClose={() => setRuleForm(null)}
          onDelete={ruleForm !== "new" && can.admin && !ruleHasGroups(ruleForm.id) ? () => { remove("assetGroupRules", ruleForm.id); setRuleForm(null); } : undefined}
          deleteBlockedMsg={ruleForm !== "new" && ruleHasGroups(ruleForm?.id) ? "توجد مجموعات تحت القاعدة — لا حذف؛ استخدم التعطيل" : ""}
          onSave={(d) => {
            const err = validateRule(d, ruleForm === "new" ? null : ruleForm);
            if (err) { alert(err); return; }
            ruleForm === "new" ? add("assetGroupRules", d) : update("assetGroupRules", ruleForm.id, d);
            setRuleForm(null);
          }} />
      )}
      {groupForm && (
        <GroupForm ctx={ctx} g={groupForm === "new" ? null : groupForm} onClose={() => setGroupForm(null)} />
      )}
      {detail && <GroupDetail ctx={ctx} groupId={detail} onClose={() => setDetail(null)} onEdit={(g) => { setDetail(null); setGroupForm(g); }} />}
    </>
  );
}

/* نموذج قاعدة مع خيارات ثابتة multi-static */
function RuleFormSheet({ ctx, schema, initial, title, onClose, onSave, onDelete, deleteBlockedMsg }) {
  const [f, setF] = useState(initial);
  const set = (k, v) => setF({ ...f, [k]: v });
  return (
    <Sheet title={title} onClose={onClose}>
      {schema.map((s) => (
        <Field key={s.k} label={s.label}>
          {s.type === "multi-static" && (
            <div style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, padding: 8, background: "#fff" }}>
              {s.options.map((o) => (
                <label key={o} style={{ display: "flex", gap: 8, alignItems: "center", padding: "4px 0" }}>
                  <input type="checkbox" checked={(f[s.k] || []).includes(o)}
                    onChange={(e) => set(s.k, e.target.checked ? [...(f[s.k] || []), o] : (f[s.k] || []).filter((x) => x !== o))} />
                  <span style={{ fontSize: 14 }}>{o}</span>
                </label>
              ))}
            </div>
          )}
          {s.type === "check" && <input type="checkbox" checked={!!f[s.k]} onChange={(e) => set(s.k, e.target.checked)} style={{ width: 22, height: 22 }} />}
          {s.type === "textarea" && <textarea value={f[s.k] || ""} onChange={(e) => set(s.k, e.target.value)} rows={2} style={{ ...input, resize: "vertical" }} />}
          {(!s.type || ["text", "date"].includes(s.type)) && <input type={s.type || "text"} value={f[s.k] ?? ""} onChange={(e) => set(s.k, e.target.value)} style={input} />}
        </Field>
      ))}
      {deleteBlockedMsg && <div style={{ fontSize: 12, color: C.steel, marginBottom: 8 }}>{deleteBlockedMsg}</div>}
      <div style={{ display: "flex", gap: 8 }}>
        <Btn bg={C.orange} style={{ flex: 1, padding: 13 }} onClick={() => onSave(f)}>حفظ</Btn>
        {onDelete && <Btn bg={C.red} style={{ padding: 13 }} onClick={onDelete}>حذف</Btn>}
      </div>
    </Sheet>
  );
}

/* إنشاء/تعديل مجموعة: القاعدة تحدد الخصائص المطلوب تعبئتها */
function GroupForm({ ctx, g, onClose }) {
  const { db, add, update, nameOf, activeAssignments } = ctx;
  const [f, setF] = useState(g ? { ...g } : { ruleId: db.assetGroupRules[0]?.id || "", attrValues: {}, excludeFromRequests: false, excludeFromWO: false });
  const rule = db.assetGroupRules.find((r) => r.id === f.ruleId);
  const hasAssigned = g && activeAssignments(g).length > 0;
  const isStatus = (rule?.usages || []).includes("حالة الأصل (قاعدة تحقق)");
  const attrKey = (label) => GROUP_ATTRS.find(([, l]) => l === label)?.[0] || label;
  const set = (k, v) => setF({ ...f, [k]: v });
  return (
    <Sheet title={g ? "تعديل مجموعة" : "مجموعة جديدة"} onClose={onClose}>
      <Field label={"القاعدة" + (g ? " — لا تتغير" : "")}>
        <select value={f.ruleId} disabled={!!g} onChange={(e) => set("ruleId", e.target.value)} style={input}>
          {db.assetGroupRules.map((r) => {
            const inactive = r.inactiveOn && r.inactiveOn < today();
            return <option key={r.id} value={r.id} disabled={inactive}>{r.name}{inactive ? " (معطلة ✗)" : ""}</option>;
          })}
        </select>
      </Field>
      <Field label="اسم المجموعة"><input value={f.name || ""} onChange={(e) => set("name", e.target.value)} style={input} /></Field>
      <Field label="الوصف"><input value={f.description || ""} onChange={(e) => set("description", e.target.value)} style={input} /></Field>
      {(rule?.attributes || []).map((label) => {
        const k = attrKey(label);
        return (
          <Field key={k} label={"خاصية: " + label + (hasAssigned ? " — مقفلة (توجد أصول)" : "")}>
            {k === "workCenterId" ? (
              <select value={(f.attrValues || {})[k] || ""} disabled={hasAssigned}
                onChange={(e) => set("attrValues", { ...(f.attrValues || {}), [k]: e.target.value })} style={input}>
                <option value="">—</option>
                {db.workCenters.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            ) : k === "type" ? (
              <select value={(f.attrValues || {})[k] || ""} disabled={hasAssigned}
                onChange={(e) => set("attrValues", { ...(f.attrValues || {}), [k]: e.target.value })} style={input}>
                <option value="">—</option>
                {["معدات", "مركبة", "مبنى", "أداة", "أخرى"].map((t) => <option key={t}>{t}</option>)}
              </select>
            ) : (
              <input value={(f.attrValues || {})[k] || ""} disabled={hasAssigned}
                onChange={(e) => set("attrValues", { ...(f.attrValues || {}), [k]: e.target.value })} style={input} />
            )}
          </Field>
        );
      })}
      {isStatus && (<>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <input type="checkbox" checked={!!f.excludeFromWO} disabled={hasAssigned} onChange={(e) => set("excludeFromWO", e.target.checked)} style={{ width: 20, height: 20 }} />
          <span style={{ fontSize: 14 }}>استبعاد أصول المجموعة من أوامر العمل{hasAssigned ? " (مقفل)" : ""}</span>
        </label>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <input type="checkbox" checked={!!f.excludeFromRequests} disabled={hasAssigned} onChange={(e) => set("excludeFromRequests", e.target.checked)} style={{ width: 20, height: 20 }} />
          <span style={{ fontSize: 14 }}>استبعاد أصول المجموعة من طلبات العمل{hasAssigned ? " (مقفل)" : ""}</span>
        </label>
      </>)}
      <Field label="تعطيل اعتبارًا من (لا تعيينات جديدة بعده)"><input type="date" value={f.inactiveOn || ""} onChange={(e) => set("inactiveOn", e.target.value)} style={input} /></Field>
      <Btn bg={C.orange} style={{ width: "100%", padding: 13 }} onClick={() => {
        if (!String(f.name || "").trim()) { alert("الاسم مطلوب"); return; }
        if (!f.ruleId) { alert("اختر القاعدة"); return; }
        const r = db.assetGroupRules.find((x) => x.id === f.ruleId);
        if (r?.inactiveOn && r.inactiveOn < today() && !g) { alert("القاعدة معطلة — لا مجموعات جديدة"); return; }
        for (const label of (r?.attributes || [])) {
          if (!((f.attrValues || {})[attrKey(label)])) { alert("أدخل قيمة خاصية «" + label + "» — إلزامية حسب القاعدة"); return; }
        }
        if (g) update("assetGroups", g.id, f);
        else add("assetGroups", { number: "AG-" + String(100 + db.assetGroups.length + 1), assignments: [], assetIds: [], code: "", ...f });
        onClose();
      }}>حفظ</Btn>
    </Sheet>
  );
}

/* تفاصيل المجموعة: التعيينات + إضافة المؤهلين + إعادة التحقق */
function GroupDetail({ ctx, groupId, onClose, onEdit }) {
  const { db, update, remove, nameOf, can, groupRule, groupActive, activeAssignments, canAssignAsset, assignAsset, unassignAsset, revalidateGroup } = ctx;
  const g = db.assetGroups.find((x) => x.id === groupId);
  const [showEnded, setShowEnded] = useState(false);
  const [pick, setPick] = useState("");
  if (!g) return null;
  const rule = groupRule(g);
  const act = activeAssignments(g);
  const ended = (g.assignments || []).filter((x) => x.end);
  const eligible = db.assets.filter((a) => !canAssignAsset(a, g));
  return (
    <Sheet title={(g.number ? g.number + " — " : "") + g.name} onClose={onClose}>
      <div style={{ ...card(), fontSize: 13.5, lineHeight: 2 }}>
        القاعدة: <b>{rule?.name || "—"}</b>{rule?.enforceUnique ? " · تعيين فريد" : ""}<br />
        {(rule?.attributes || []).length > 0 && <>الخصائص: <b>{Object.entries(g.attrValues || {}).filter(([, v]) => v).map(([k, v]) => (GROUP_ATTRS.find(([kk]) => kk === k)?.[1] || k) + " = " + (k === "workCenterId" ? nameOf("workCenters", v) : v)).join("، ")}</b><br /></>}
        {(g.excludeFromWO || g.excludeFromRequests) && <span style={{ color: C.red, fontWeight: 700 }}>⛔ تحقق: {[g.excludeFromWO ? "مستبعدة من أوامر العمل" : "", g.excludeFromRequests ? "مستبعدة من طلبات العمل" : ""].filter(Boolean).join(" و")}<br /></span>}
        {!groupActive(g) && <span style={{ color: C.steel }}>معطلة منذ {fmt(g.inactiveOn)} — لا تعيينات جديدة</span>}
      </div>
      {can.manage && (
        <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
          <Btn bg={C.blue} onClick={() => onEdit(g)}>تعديل</Btn>
          <Btn bg={C.amber} onClick={() => {
            const bad = revalidateGroup(g);
            alert(bad.length ? "⚠ أُنهيت تعيينات غير مطابقة:\n• " + bad.join("\n• ") : "✓ كل التعيينات مطابقة");
          }}>إعادة التحقق من التطابق</Btn>
          {can.admin && (act.length === 0
            ? <Btn bg={C.red} onClick={() => { if (confirm("حذف المجموعة؟")) { remove("assetGroups", g.id); onClose(); } }}>حذف</Btn>
            : <span style={{ fontSize: 12, color: C.steel, alignSelf: "center" }}>توجد أصول معينة — لا حذف</span>)}
        </div>
      )}
      <Section title={"الأصول المعينة (" + act.length + ")"}>
        {act.map((x) => {
          const a = db.assets.find((z) => z.id === x.assetId);
          return (
            <div key={x.id} style={card()}>
              <Row main={(a?.number ? a.number + " — " : "") + (a?.name || "أصل محذوف")} sub={"منذ " + fmt(x.start) + " · " + (x.by || "")}
                action={can.manage ? <Btn bg={C.red} onClick={() => unassignAsset(g, x.id, "إلغاء يدوي")}>إلغاء التعيين</Btn> : null} />
            </div>
          );
        })}
        {act.length === 0 && <Empty text="لا أصول معينة بعد." />}
        {can.manage && groupActive(g) && (
          <div style={{ display: "flex", gap: 8 }}>
            <select value={pick} onChange={(e) => setPick(e.target.value)} style={input}>
              <option value="">— الأصول المؤهلة فقط ({eligible.length}) —</option>
              {eligible.map((a) => <option key={a.id} value={a.id}>{a.number} — {a.name}</option>)}
            </select>
            <Btn bg={C.green} onClick={() => { if (!pick) return; const e = assignAsset(g, pick); if (e) alert(e); setPick(""); }}>تعيين</Btn>
          </div>
        )}
      </Section>
      {ended.length > 0 && (
        <Section title={"تعيينات منتهية (" + ended.length + ")"}>
          <button onClick={() => setShowEnded(!showEnded)} style={{ ...delBtn, color: C.blue }}>{showEnded ? "إخفاء" : "عرض"}</button>
          {showEnded && ended.map((x) => {
            const a = db.assets.find((z) => z.id === x.assetId);
            return (
              <div key={x.id} style={{ ...card(), opacity: 0.6 }}>
                <Row main={a?.name || "أصل"} sub={fmt(x.start) + " ← " + fmt(x.end) + " · السبب: " + (x.endReason || "—")} />
              </div>
            );
          })}
        </Section>
      )}
    </Sheet>
  );
}

function normalizeSearchText(v) {
  return String(v || "").toLowerCase().replace(/[.\-_\/،,;:]+/g, " ").replace(/\s+/g, " ").trim();
}
function parseSearchChip(chip) {
  const quoted = String(chip || "").match(/"([^"]+)"|“([^”]+)”/g);
  if (quoted?.length) return quoted.map((x) => x.replace(/["“”]/g, "").toLowerCase());
  return normalizeSearchText(chip).split(" ").filter(Boolean);
}
function assetSearchBlob(a) {
  return normalizeSearchText([a.number, a.name, a.description, a.itemName, a.itemId, a.serial, a.lotNumber, a.location, a.locationType, a.type, a.ownership, a.customer, a.contact, a.project, a.task, a.countryOfOrigin, ...(a.flexfields || []).map((f) => f.name + " " + f.value)].join(" "));
}
function smartAssetMatch(a, chips) {
  if (!chips.length) return true;
  const blob = assetSearchBlob(a);
  return chips.every((chip) => parseSearchChip(chip).some((term) => blob.includes(normalizeSearchText(term))));
}

function Assets({ ctx, openAsset }) {
  const { db, nameOf, can, exportAssetsCSV, assetUsable } = ctx;
  const [q, setQ] = useState("");
  const [chips, setChips] = useState([]);
  const [wizard, setWizard] = useState(false);
  const [groupFilter, setGroupFilter] = useState("");
  const [showEnded, setShowEnded] = useState(false);
  const [includeChildren, setIncludeChildren] = useState(false);
  const [flag, setFlag] = useState("الكل");
  const addChip = () => { const v = q.trim(); if (v && !chips.includes(v)) setChips([...chips, v]); setQ(""); };
  let list = db.assets.filter((a) => smartAssetMatch(a, [...chips, ...(q.trim() ? [q] : [])]));
  if (groupFilter) {
    const g = db.assetGroups.find((x) => x.id === groupFilter);
    const ids = new Set(g?.assetIds || []);
    if (includeChildren) db.assets.filter((a) => ids.has(a.parentId)).forEach((a) => ids.add(a.id));
    list = list.filter((a) => ids.has(a.id));
  }
  if (!showEnded) list = list.filter((a) => assetUsable(a));
  if (flag === "أوامر مسموحة") list = list.filter((a) => a.allowWO !== false);
  if (flag === "برامج مسموحة") list = list.filter((a) => a.allowPrograms !== false);
  if (flag === "IoT") list = list.filter((a) => a.enableIoT);
  if (flag === "أصول عملاء") list = list.filter((a) => a.ownership === "عميل");
  if (flag === "أصول مؤسسة") list = list.filter((a) => a.ownership !== "عميل");
  return (
    <>
      <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") addChip(); }}
          placeholder='🔍 بحث ذكي: اكتب كلمة أو "عبارة حرفية" ثم Enter' style={{ ...input, flex: 1 }} />
        <Btn bg={C.ink} onClick={addChip}>شريحة</Btn>
      </div>
      <div style={{ fontSize: 11.5, color: C.steel, marginBottom: 6 }}>البحث الذكي: OR داخل الشريحة الواحدة، AND بين الشرائح، ويبحث في الرقم/الوصف/الصنف/السيريال/الموقع/العميل/Flexfields.</div>
      {chips.length > 0 && (
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
          {chips.map((c) => <Chip key={c} active onClick={() => setChips(chips.filter((x) => x !== c))}>{c} ×</Chip>)}
        </div>
      )}
      {db.assetGroups.length > 0 && (
        <select value={groupFilter} onChange={(e) => setGroupFilter(e.target.value)} style={{ ...input, marginBottom: 10, padding: "8px 12px" }}>
          <option value="">كل المجموعات</option>
          {db.assetGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
        </select>
      )}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 8 }}>
        {["الكل", "أصول مؤسسة", "أصول عملاء", "أوامر مسموحة", "برامج مسموحة", "IoT"].map((f) => <Chip key={f} active={flag === f} onClick={() => setFlag(f)}>{f}</Chip>)}
      </div>
      <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12.5, marginBottom: 5 }}>
        <input type="checkbox" checked={showEnded} onChange={(e) => setShowEnded(e.target.checked)} /> إظهار الأصول المنتهية/الموقوفة
      </label>
      <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12.5, marginBottom: 8 }}>
        <input type="checkbox" checked={includeChildren} onChange={(e) => setIncludeChildren(e.target.checked)} /> عند فلترة مجموعة: تضمين الأصول الفرعية
      </label>
      {can.manage && (
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <Btn bg={C.orange} onClick={() => setWizard(true)} style={{ flex: 1, padding: 12 }}>+ تسجيل أصل (معالج)</Btn>
          <Btn bg={C.blue} onClick={exportAssetsCSV} style={{ padding: 12 }}>CSV</Btn>
        </div>
      )}
      {list.length === 0 && <Empty text="لا أصول مطابقة." />}
      {list.map((a) => (
        <div key={a.id} style={card()} onClick={() => openAsset(a.id)}>
          <Row main={a.number + " — " + a.name}
            sub={[a.location, a.locationType && a.locationType !== "UNKNOWN" ? a.locationType : "", a.type, a.itemName ? "Item: " + a.itemName : "", a.ownership === "عميل" ? "عميل: " + (a.customer || "—") : "مؤسسة", Number(a.quantity) > 1 ? "كمية " + a.quantity : "",
              a.critical ? "⚠ حرج" : "", a.allowWO === false ? "🚫 أوامر" : "", a.enableIoT ? "📡 IoT" : "",
              a.parentId ? "تابع لـ " + nameOf("assets", a.parentId) : ""].filter(Boolean).join(" · ")}
            badge={!assetUsable(a) ? { text: a.endDate && a.endDate < today() ? "منتهٍ" : "موقوف", color: C.steel } : undefined} />
        </div>
      ))}
      {wizard && <AssetWizard ctx={ctx} onClose={() => setWizard(false)} />}
    </>
  );
}

/* معالج إنشاء الأصل خطوة بخطوة (وثيقة الأصول §تدفق الإنشاء) */
function AssetWizard({ ctx, onClose }) {
  const { db, save } = ctx;
  const [step, setStep] = useState(0);
  const [a, setA] = useState({ active: true, critical: false, type: "معدات", ownership:"مؤسسة", itemRequired:true, locationType:"UNKNOWN", quantity:1, allowWO:true, allowPrograms:true });
  const [meterTplId, setMeterTplId] = useState(""); const [meterInit, setMeterInit] = useState("0");
  const [partsText, setPartsText] = useState("");
  const [warr, setWarr] = useState({ supplier: "", start: "", end: "" });
  const set = (k, v) => setA({ ...a, [k]: v });
  const STEPS = ["الأساسيات والموقع", "التصنيف", "البيانات الفنية", "الهيكل", "العدادات", "قطع الغيار", "الضمان"];
  const next = () => {
    if (step === 0) {
      if (!String(a.name || "").trim()) return alert("أدخل اسم الأصل");
      if (!String(a.location || "").trim()) return alert("لا أصل بدون موقع (قاعدة النظام)");
      const err = ctx.assetSaveErrors(a, null);
      if (err) return alert(err);
    }
    setStep(step + 1);
  };
  const finish = () => {
    const err = ctx.assetSaveErrors(a, null);
    if (err) return alert(err);
    const parts = partsText.split("\n").filter(Boolean).map((l) => {
      const seg = l.includes("،") ? l.split("،") : l.split(",");
      return { id: uid(), name: (seg[0] || l).trim(), qty: (seg[1] || "1").trim(), itemId:"", uom:"" };
    });
    const groupId = a._groupId; const data = { ...a }; delete data._groupId;
    if (!String(data.number || "").trim()) data.number = ctx.nextAssetNumber();
    const created = { id: uid(), ...data, assetType: data.ownership === "عميل" ? "CUSTOMER" : "ENTERPRISE", parts, docs: [], photos: [], specs: data.specs || "",
      quantity: Number(data.quantity || 1), notes: [], flexfields: [], serviceRequests: [],
      history: [{ action: "إنشاء عبر المعالج", at: now(), by: ctx.role }] };
    let next = { ...db, assets: [...db.assets, created] };
    if (groupId) {
      next.assetGroups = db.assetGroups.map((g) => g.id === groupId ? { ...g, assetIds: [...(g.assetIds || []), created.id], assignments: [...(g.assignments || []), { id: uid(), assetId: created.id, start: today(), end:"", endReason:"", by: ctx.role }] } : g);
    }
    if (meterTplId) next.assetMeters = [...db.assetMeters, { id: uid(), assetId: created.id, templateId: meterTplId, initial: Number(meterInit || 0), recordAtWO:"", endDate:"", estDailyRate:"", readingsForRate:"" }];
    if (warr.supplier && warr.end) next.warranties = [...db.warranties, { id: uid(), assetId: created.id, ...warr }];
    if (created.enableIoT) next.assetIotSyncEvents = [...(db.assetIotSyncEvents || []), { id: uid(), assetId: created.id, at: now(), trigger:"إنشاء الأصل", status:"Queued", message:"مزامنة Digital Twin مطلوبة" }];
    save(next);
    alert("✓ أُنشئ ملف الأصل — جاهز للصيانة والتكاليف");
    onClose();
  };
  return (
    <Sheet title={"تسجيل أصل — " + (step + 1) + "/" + STEPS.length + ": " + STEPS[step]} onClose={onClose}>
      <div style={{ display: "flex", gap: 4, marginBottom: 14 }}>
        {STEPS.map((s, i) => <div key={s} style={{ flex: 1, height: 5, borderRadius: 3, background: i <= step ? C.orange : C.line }} />)}
      </div>
      {step === 0 && (<>
        <Field label="رقم الأصل (فارغ = توليد تلقائي)"><input value={a.number || ""} onChange={(e) => set("number", e.target.value)} placeholder="ELA-01" style={input} /></Field>
        <Field label="اسم الأصل"><input value={a.name || ""} onChange={(e) => set("name", e.target.value)} style={input} /></Field>
        <Field label="ملكية الأصل"><select value={a.ownership || "مؤسسة"} onChange={(e) => set("ownership", e.target.value)} style={input}>{ASSET_OWNERSHIP.map((x) => <option key={x}>{x}</option>)}</select></Field>
        {a.ownership === "عميل" && <Field label="العميل"><input value={a.customer || ""} onChange={(e) => set("customer", e.target.value)} placeholder="اسم العميل" style={input} /></Field>}
        <label style={{ display:"flex", gap:8, alignItems:"center", marginBottom:10 }}><input type="checkbox" checked={!!a.itemRequired} onChange={(e) => set("itemRequired", e.target.checked)} /> <span>الصنف Item مطلوب لهذا الأصل</span></label>
        {a.itemRequired && <Field label="Item / الصنف المرتبط"><input value={a.itemName || ""} onChange={(e) => set("itemName", e.target.value)} placeholder="مثال: Bucket Elevator Assembly" style={input} /></Field>}
        <Field label="منظمة التشغيل/الصيانة"><select value={a.operatingOrganizationId || ""} onChange={(e) => set("operatingOrganizationId", e.target.value)} style={input}><option value="">—</option>{db.maintenanceOrganizations.map((o) => <option key={o.id} value={o.id}>{o.name || o.code}</option>)}</select></Field>
        <Field label="نوع الموقع"><select value={a.locationType || "UNKNOWN"} onChange={(e) => set("locationType", e.target.value)} style={input}>{LOCATION_TYPES.map((x) => <option key={x}>{x}</option>)}</select></Field>
        <Field label="الموقع (إلزامي — المصنع/المنطقة)"><input value={a.location || ""} onChange={(e) => set("location", e.target.value)} placeholder="طابق الطحن — خط 1" style={input} /></Field>
      </>)}
      {step === 1 && (<>
        <Field label="نوع الأصل">
          <select value={a.type} onChange={(e) => set("type", e.target.value)} style={input}>
            {["معدات", "مركبة", "مبنى", "أداة", "أخرى"].map((t) => <option key={t}>{t}</option>)}
          </select>
        </Field>
        <div style={{ display:"flex", gap:8 }}><Field label="الكمية"><input type="number" value={a.quantity || 1} onChange={(e) => set("quantity", e.target.value)} style={input} /></Field><Field label="UOM"><input value={a.uom || ""} onChange={(e) => set("uom", e.target.value)} placeholder="EA" style={input} /></Field></div>
        <Field label="المجموعة (مصاعد قواديس، مراوح…)">
          <select value={a._groupId || ""} onChange={(e) => set("_groupId", e.target.value)} style={input}>
            <option value="">— بدون —</option>
            {db.assetGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </Field>
        <Field label="SubType افتراضي لأمر العمل"><select value={a.defaultWOSubtype || ""} onChange={(e) => set("defaultWOSubtype", e.target.value)} style={input}>{DEFAULT_WO_SUBTYPES.map((x) => <option key={x}>{x}</option>)}</select></Field>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}><input type="checkbox" checked={!!a.critical} onChange={(e) => set("critical", e.target.checked)} style={{ width: 20, height: 20 }} /><span>أصل حرج</span></label>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}><input type="checkbox" checked={!!a.enableIoT} onChange={(e) => set("enableIoT", e.target.checked)} style={{ width: 20, height: 20 }} /><span>تفعيل IoT / Digital Twin</span></label>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}><input type="checkbox" checked={!!a.competitorAsset} onChange={(e) => set("competitorAsset", e.target.checked)} style={{ width: 20, height: 20 }} /><span>أصل منافس لا يتوقع صيانته</span></label>
      </>)}
      {step === 2 && (<>
        <Field label="الرقم التسلسلي"><input value={a.serial || ""} onChange={(e) => set("serial", e.target.value)} style={input} /></Field>
        <Field label="المواصفات الفنية (سطر لكل مواصفة)">
          <textarea value={a.specs || ""} onChange={(e) => set("specs", e.target.value)} rows={4} placeholder={"القدرة: 15 kW\nالسرعة: 1450 rpm\nالمصنّع: Buhler"} style={{ ...input, resize: "vertical" }} />
        </Field>
      </>)}
      {step === 3 && (
        <Field label="الأصل الأب (الهيكل الفيزيائي)">
          <select value={a.parentId || ""} onChange={(e) => set("parentId", e.target.value)} style={input}>
            <option value="">— أصل رئيسي —</option>
            {db.assets.map((x) => <option key={x.id} value={x.id}>{x.number} — {x.name}</option>)}
          </select>
        </Field>
      )}
      {step === 4 && (<>
        <Field label="ربط عداد (اختياري)">
          <select value={meterTplId} onChange={(e) => setMeterTplId(e.target.value)} style={input}>
            <option value="">— بدون عداد —</option>
            {db.meterTemplates.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.uom})</option>)}
          </select>
        </Field>
        {meterTplId && <Field label="القراءة الابتدائية"><input type="number" value={meterInit} onChange={(e) => setMeterInit(e.target.value)} style={input} /></Field>}
        {db.meterTemplates.length === 0 && <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 10 }}>لا قوالب عدادات بعد — أنشئها من تبويب العدادات لاحقًا.</div>}
      </>)}
      {step === 5 && (
        <Field label="قطع الغيار (سطر لكل قطعة: الاسم، الكمية)">
          <textarea value={partsText} onChange={(e) => setPartsText(e.target.value)} rows={4} placeholder={"سير ناقل، 2\nمحمل 6205، 4\nشحم ليثيوم، 1"} style={{ ...input, resize: "vertical" }} />
        </Field>
      )}
      {step === 6 && (<>
        <Field label="مورد الضمان (اتركه فارغًا إن لا يوجد)"><input value={warr.supplier} onChange={(e) => setWarr({ ...warr, supplier: e.target.value })} style={input} /></Field>
        <div style={{ display: "flex", gap: 8 }}>
          <Field label="البداية"><input type="date" value={warr.start} onChange={(e) => setWarr({ ...warr, start: e.target.value })} style={input} /></Field>
          <Field label="النهاية"><input type="date" value={warr.end} onChange={(e) => setWarr({ ...warr, end: e.target.value })} style={input} /></Field>
        </div>
      </>)}
      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        {step > 0 && <Btn bg={C.steel} style={{ padding: 12 }} onClick={() => setStep(step - 1)}>السابق</Btn>}
        {step < STEPS.length - 1
          ? <Btn bg={C.orange} style={{ flex: 1, padding: 12 }} onClick={next}>التالي</Btn>
          : <Btn bg={C.green} style={{ flex: 1, padding: 12 }} onClick={finish}>✓ إنشاء ملف الأصل</Btn>}
      </div>
    </Sheet>
  );
}

function AssetGroupJoin({ a, db, canAssignAsset, assignAsset }) {
  const [pick, setPick] = useState("");
  const eligible = db.assetGroups.filter((g) => !canAssignAsset(a, g));
  if (!eligible.length) return null;
  return (
    <div style={{ display: "flex", gap: 8 }}>
      <select value={pick} onChange={(e) => setPick(e.target.value)} style={input}>
        <option value="">— ضمّه لمجموعة مؤهلة ({eligible.length}) —</option>
        {eligible.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
      </select>
      <Btn bg={C.green} onClick={() => { if (!pick) return; const g = db.assetGroups.find((x) => x.id === pick); const e = assignAsset(g, a.id); if (e) alert(e); setPick(""); }}>تعيين</Btn>
    </div>
  );
}

function DocForm({ onAdd }) {
  const [name, setName] = useState(""); const [type, setType] = useState(DOC_TYPES[0]); const [url, setUrl] = useState("");
  return (
    <div style={card()}>
      <Field label="اسم المستند"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="دليل تشغيل المصعد" style={input} /></Field>
      <Field label="النوع">
        <select value={type} onChange={(e) => setType(e.target.value)} style={input}>{DOC_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
      </Field>
      <Field label="رابط الملف (Drive/سيرفر — اختياري)"><input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" style={input} /></Field>
      <Btn bg={C.ink} style={{ width: "100%" }} onClick={() => { if (name.trim()) { onAdd({ name, type, url }); setName(""); setUrl(""); } }}>+ إضافة مستند</Btn>
    </div>
  );
}

function AssetDetail({ ctx, assetId, onClose, openWO }) {
  const { db, add, update, remove, nameOf, ltd, can, woCost, activeWarranty, activeAssignments, canAssignAsset, assignAsset, unassignAsset, copyAsset, splitAsset, assetSaveErrors, propagateLocation, logAsset, descendants, assetUsable } = ctx;
  const a = db.assets.find((x) => x.id === assetId);
  const [sub, setSub] = useState("عام");
  const [edit, setEdit] = useState(false);
  if (!a) return null;
  const children = db.assets.filter((x) => x.parentId === a.id);
  const wos = db.workOrders.filter((w) => w.assetId === a.id);
  const meters = db.assetMeters.filter((m) => m.assetId === a.id);
  const warr = db.warranties.filter((w) => w.assetId === a.id);
  const aw = activeWarranty(a.id);
  const totalCost = wos.reduce((s, w) => s + woCost(w).total, 0);
  const failures = wos.filter((w) => w.failure);
  const TABS = ["Asset 360", "عام", "الهيكل", "قطع الغيار", "المستندات", "الصور", "التكاليف", "التاريخ", "ملاحظات", "Flexfields", "الأصل المالي", "الخدمة", "IoT"];
  const addDoc = (d) => update("assets", a.id, { docs: [...(a.docs || []), { id: uid(), ...d }] });
  const addPhoto = async (file) => {
    try { const data = await resizeImage(file); update("assets", a.id, { photos: [...(a.photos || []), { id: uid(), data, at: today() }] }); }
    catch (e) { alert("تعذر معالجة الصورة"); }
  };
  return (
    <Sheet title={a.number} onClose={onClose}>
      <div style={{ marginBottom: 10 }}>
        <div style={{ fontWeight: 800, fontSize: 18 }}>{a.name} {a.critical && <span style={{ color: C.red }}>⚠</span>}</div>
        <div style={{ fontSize: 13, color: C.steel }}>
          {[a.type, a.location, a.serial ? "تسلسلي " + a.serial : ""].filter(Boolean).join(" · ")}
        </div>
        {aw && <div style={{ fontSize: 13, color: C.green, fontWeight: 700, marginTop: 4 }}>🛡 تحت ضمان «{aw.supplier}» حتى {fmt(aw.end)} — راجعه قبل أي إصلاح داخلي</div>}
        {!assetUsable(a) && <div style={{ fontSize: 13, color: C.steel, fontWeight: 700, marginTop: 4 }}>⛔ {a.endDate && a.endDate < today() ? "أصل منتهٍ منذ " + fmt(a.endDate) : "موقوف"} — لا أوامر ولا برامج</div>}
        {can.manage && (
          <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
            <Btn bg={C.blue} onClick={() => setEdit(true)}>تعديل</Btn>
            <Btn bg={C.purple} onClick={() => {
              const withMeters = db.assetMeters.some((m) => m.assetId === a.id) && confirm("نسخ عدادات الأصل أيضًا؟ (بقراءة ابتدائية 0)");
              const c = copyAsset(a, withMeters);
              alert("✓ أُنشئت النسخة " + c.number);
            }}>نسخ</Btn>
            {!a.serial && Number(a.quantity || 1) > 1 && (
              <Btn bg={C.amber} onClick={() => {
                if (!confirm("تقسيم الأصل إلى " + a.quantity + " وحدات مستقلة (كمية كل وحدة = 1)؟")) return;
                const e = splitAsset(a);
                alert(e ? "⛔ " + e : "✓ تم التقسيم — راجع قائمة الأصول");
              }}>تقسيم ({a.quantity})</Btn>
            )}
            <Btn bg={a.active === false ? C.green : C.steel} onClick={() => update("assets", a.id, { active: a.active === false })}>
              {a.active === false ? "تفعيل" : "إيقاف"}
            </Btn>
            {can.admin && <Btn bg={C.red} onClick={() => { remove("assets", a.id); onClose(); }}>حذف</Btn>}
          </div>
        )}
      </div>
      <div style={{ display: "flex", gap: 5, overflowX: "auto", marginBottom: 10 }}>
        {TABS.map((t) => <Chip key={t} active={sub === t} onClick={() => setSub(t)}>{t}</Chip>)}
      </div>

      {sub === "Asset 360" && (
        <Section title="Asset 360 — مؤشرات وروابط الأصل">
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:10 }}>
            <Stat n={wos.length} label="أوامر عمل" color={C.blue} />
            <Stat n={children.length} label="أصول فرعية" color={C.purple} />
            <Stat n={meters.length} label="عدادات" color={C.green} />
            <Stat n={money(totalCost)} label="تكلفة" color={C.orange} small />
          </div>
          <div style={card()}>
            <Row main="الارتباطات" sub={[aw ? "ضمان فعال" : "لا ضمان فعال", "مجموعات: " + db.assetGroups.filter((g) => (g.assetIds || []).includes(a.id)).length, a.fixedAssetNumber ? "أصل مالي: " + a.fixedAssetNumber : "لا أصل مالي", a.enableIoT ? "IoT مفعل" : "IoT غير مفعل"].filter(Boolean).join(" · ")} />
          </div>
          <div style={{ fontSize:12.5, color:C.steel }}>هذا التبويب يجمع روابط الفصل 3: أوامر العمل، المجموعات، العقود، التاريخ، التكاليف، العدادات، والهيكل.</div>
        </Section>
      )}

      {sub === "عام" && (<>
        <Section title="البيانات الفنية">
          <div style={card()}>
            {(a.specs || "").split("\n").filter(Boolean).map((l, i) => <div key={i} style={{ fontSize: 14, marginBottom: 3 }}>{l}</div>)}
            {!a.specs && <span style={{ color: C.steel, fontSize: 13 }}>لا مواصفات مسجلة — عدّل الأصل لإضافتها.</span>}
          </div>
        </Section>
        <Section title={"العدادات (" + meters.length + ")"}>
          {meters.map((m) => (
            <div key={m.id} style={card()}>
              <Row main={nameOf("meterTemplates", m.templateId)} sub={"إجمالي العمر: " + ltd(m) + " " + nameOf("meterTemplates", m.templateId, "uom")} />
            </div>
          ))}
          {meters.length === 0 && <Empty text="لا عدادات — اربطها من تبويب العدادات." />}
        </Section>
        <Section title={"الضمانات (" + warr.length + ")"}>
          {warr.map((w) => (
            <div key={w.id} style={card()}>
              <Row main={w.supplier} sub={(daysUntil(w.end) >= 0 ? "ساري حتى " : "منتهي منذ ") + fmt(w.end)}
                badge={{ text: daysUntil(w.end) >= 0 ? "ساري" : "منتهي", color: daysUntil(w.end) >= 0 ? C.green : C.red }} />
            </div>
          ))}
          {warr.length === 0 && <Empty text="لا ضمانات مسجلة." />}
        </Section>
        <Section title="مجموعات هذا الأصل">
          {db.assetGroups.filter((g) => activeAssignments(g).some((x) => x.assetId === a.id)).map((g) => {
            const asn = activeAssignments(g).find((x) => x.assetId === a.id);
            return (
              <div key={g.id} style={card()}>
                <Row main={g.name} sub={"منذ " + fmt(asn.start)}
                  badge={(g.excludeFromWO || g.excludeFromRequests) ? { text: "تحقق ⛔", color: C.red } : undefined}
                  action={can.manage ? <Btn bg={C.red} onClick={() => unassignAsset(g, asn.id, "إلغاء يدوي")}>إلغاء</Btn> : null} />
              </div>
            );
          })}
          {db.assetGroups.filter((g) => activeAssignments(g).some((x) => x.assetId === a.id)).length === 0 && <Empty text="غير معين لأي مجموعة." />}
          {can.manage && (
            <AssetGroupJoin a={a} db={db} canAssignAsset={canAssignAsset} assignAsset={assignAsset} />
          )}
        </Section>
      </>)}

      {sub === "الهيكل" && (
        <Section title="الهرمية المادية — الفرع يرث موقع الأب الأعلى">
          {a.parentId && <div style={card()}><Row main={"⬆ الأب: " + nameOf("assets", a.parentId)}
            action={can.manage ? <Btn bg={C.steel} onClick={() => { update("assets", a.id, { parentId: "" }); logAsset(a.id, "فصل عن الأب"); }}>فصل</Btn> : null} /></div>}
          {children.map((c) => (
            <div key={c.id} style={card()}>
              <Row main={"⬇ " + c.number + " — " + c.name} sub={c.location} />
              {can.manage && (
                <div style={{ display: "flex", gap: 10, marginTop: 4, alignItems: "center", flexWrap: "wrap" }}>
                  <button onClick={() => update("assets", c.id, { parentId: "" })} style={{ ...delBtn, marginTop: 0 }}>إزالة من الهيكل</button>
                  <select defaultValue="" onChange={(e) => { if (e.target.value) { update("assets", c.id, { parentId: e.target.value, location: db.assets.find((x) => x.id === e.target.value)?.location || c.location }); e.target.value = ""; } }} style={{ ...input, width: "auto", padding: "4px 8px", fontSize: 12 }}>
                    <option value="">نقل تحت أب آخر…</option>
                    {db.assets.filter((x) => x.id !== c.id && x.id !== a.id && !descendants(c.id).some((d) => d.id === x.id)).map((x) => <option key={x.id} value={x.id}>{x.number} — {x.name}</option>)}
                  </select>
                </div>
              )}
            </div>
          ))}
          {!a.parentId && children.length === 0 && <Empty text="أصل مستقل — لا أب ولا مكونات تابعة." />}
          {can.manage && (<>
            <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
              <select defaultValue="" id={"addch-" + a.id} onChange={(e) => {
                if (!e.target.value) return;
                const child = db.assets.find((x) => x.id === e.target.value);
                update("assets", child.id, { parentId: a.id, location: a.location || child.location });
                logAsset(a.id, "إضافة فرع: " + child.number);
                e.target.value = "";
              }} style={input}>
                <option value="">+ إضافة أصل موجود كفرع (يرث الموقع)…</option>
                {db.assets.filter((x) => x.id !== a.id && x.parentId !== a.id && !descendants(a.id).some((d) => d.id === x.id) && x.id !== a.parentId).map((x) => <option key={x.id} value={x.id}>{x.number} — {x.name}</option>)}
              </select>
            </div>
            <AddInline placeholder="+ إنشاء فرع جديد سريع (الاسم فقط)" onAdd={(t) => {
              add("assets", { number: ctx.nextAssetNumber(), name: t, type: a.type, location: a.location, parentId: a.id,
                parts: [], docs: [], photos: [], specs: "", allowWO: true, allowPrograms: true, quantity: 1, active: true,
                notes: [], history: [{ action: "إنشاء كفرع لـ " + a.number, at: now(), by: ctx.role }] });
            }} />
          </>)}
        </Section>
      )}

      {sub === "قطع الغيار" && (
        <Section title={"قطع الغيار المرتبطة (" + (a.parts || []).length + ")"}>
          {(a.parts || []).map((p) => (
            <div key={p.id} style={card()}>
              <Row main={p.name} sub={"الكمية الموصى بها: " + p.qty}
                action={can.manage ? <Btn bg={C.red} onClick={() => update("assets", a.id, { parts: a.parts.filter((x) => x.id !== p.id) })}>حذف</Btn> : null} />
            </div>
          ))}
          {can.manage && <AddInline placeholder="اسم القطعة، الكمية (محمل 6205، 4)" onAdd={(t) => {
            const seg = t.includes("،") ? t.split("،") : t.split(",");
            update("assets", a.id, { parts: [...(a.parts || []), { id: uid(), name: (seg[0] || t).trim(), qty: (seg[1] || "1").trim() }] });
          }} />}
        </Section>
      )}

      {sub === "المستندات" && (
        <Section title={"المستندات (" + (a.docs || []).length + ")"}>
          {(a.docs || []).map((d) => (
            <div key={d.id} style={card()}>
              <Row main={"📄 " + d.name} sub={d.type + (d.url ? "" : " · بدون رابط")}
                action={d.url ? <Btn bg={C.blue} onClick={() => window.open(d.url, "_blank")}>فتح</Btn> : null} />
              {can.manage && <button onClick={() => update("assets", a.id, { docs: a.docs.filter((x) => x.id !== d.id) })} style={delBtn}>حذف</button>}
            </div>
          ))}
          {can.manage && <DocForm onAdd={addDoc} />}
        </Section>
      )}

      {sub === "الصور" && (
        <Section title={"صور الأصل (" + (a.photos || []).length + ")"}>
          {can.manage && (
            <div style={{ ...card() }}>
              <input type="file" accept="image/*" capture="environment" onChange={(e) => e.target.files[0] && addPhoto(e.target.files[0])} style={{ fontSize: 14 }} />
            </div>
          )}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {(a.photos || []).map((p) => (
              <div key={p.id} style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, overflow: "hidden", background: "#fff" }}>
                <img src={p.data} alt="" style={{ width: "100%", display: "block" }} />
                <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 8px", fontSize: 12 }}>
                  <span style={{ color: C.steel }}>{fmt(p.at)}</span>
                  {can.manage && <button onClick={() => update("assets", a.id, { photos: a.photos.filter((x) => x.id !== p.id) })} style={{ ...delBtn, marginTop: 0 }}>حذف</button>}
                </div>
              </div>
            ))}
          </div>
          {(a.photos || []).length === 0 && <Empty text="لا صور للأصل بعد." />}
        </Section>
      )}

      {sub === "التكاليف" && (
        <Section title="سجل التكاليف">
          <div style={{ ...card(), fontSize: 15, fontWeight: 800 }}>إجمالي تكلفة صيانة هذا الأصل: {money(totalCost)}</div>
          {wos.filter((w) => woCost(w).total > 0).map((w) => (
            <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
              <Row main={w.number + " — " + w.title} sub={w.type + " · " + fmt(w.completedAt || w.plannedStart)}
                badge={{ text: money(woCost(w).total), color: C.orange }} />
            </div>
          ))}
        </Section>
      )}

      {sub === "التاريخ" && (<>
        <Section title={"تاريخ الصيانة (" + wos.length + ")"}>
          {wos.slice().reverse().map((w) => (
            <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
              <Row main={w.number + " — " + w.title} sub={w.type + " · " + fmt(w.plannedStart)} badge={{ text: w.status, color: WO_COLORS[w.status] }} />
            </div>
          ))}
          {wos.length === 0 && <Empty text="لا أوامر عمل على هذا الأصل." />}
        </Section>
        <Section title={"تاريخ الأعطال (" + failures.length + ")"}>
          {failures.map((w) => (
            <div key={w.id} style={{ ...card(), borderRightColor: C.red }} onClick={() => openWO(w.id)}>
              <Row main={w.failure.mode} sub={w.failure.cause + " · " + w.failure.downtime + " د توقف"} />
            </div>
          ))}
          {failures.length === 0 && <Empty text="لا أعطال مسجلة لهذا الأصل." />}
        </Section>
        <Section title={"سجل تغييرات الأصل (" + (a.history || []).length + ")"}>
          {(a.history || []).slice().reverse().map((h, i) => (
            <div key={i} style={{ fontSize: 13, color: C.steel, marginBottom: 4, borderBottom: `1px dashed ${C.line}`, paddingBottom: 4 }}>
              <b style={{ color: C.ink }}>{h.action}</b> — {h.at} — {h.by}
            </div>
          ))}
          {(a.history || []).length === 0 && <Empty text="لا تغييرات مسجلة." />}
        </Section>
      </>)}

      {sub === "ملاحظات" && (
        <Section title={"ملاحظات الأصل (" + (a.notes || []).length + ")"}>
          {(a.notes || []).slice().reverse().map((n) => (
            <div key={n.id} style={card()}>
              <Row main={n.text} sub={n.at + " · " + n.by}
                action={can.manage ? <Btn bg={C.red} onClick={() => update("assets", a.id, { notes: a.notes.filter((x) => x.id !== n.id) })}>حذف</Btn> : null} />
            </div>
          ))}
          {(a.notes || []).length === 0 && <Empty text="لا ملاحظات." />}
          {can.execute && <AddInline placeholder="ملاحظة جديدة…" onAdd={(t) =>
            update("assets", a.id, { notes: [...(a.notes || []), { id: uid(), text: t, at: now(), by: ctx.role }] })} />}
        </Section>
      )}

      {sub === "Flexfields" && (
        <Section title="Flexfields / معلومات إضافية مرنة">
          {(a.flexfields || []).map((f) => <div key={f.id} style={card()}><Row main={f.name} sub={f.value} action={can.manage ? <Btn bg={C.red} onClick={() => update("assets", a.id, { flexfields: a.flexfields.filter((x) => x.id !== f.id) })}>حذف</Btn> : null} /></div>)}
          {(a.flexfields || []).length === 0 && <Empty text="لا حقول إضافية." />}
          {can.manage && <AddInline placeholder="اسم الحقل = القيمة" onAdd={(t) => { const [name, ...rest] = t.split("="); update("assets", a.id, { flexfields: [...(a.flexfields || []), { id: uid(), name: (name || "حقل").trim(), value: rest.join("=").trim() }] }); }} />}
        </Section>
      )}

      {sub === "الأصل المالي" && (
        <Section title="Fixed Assets — الربط المالي">
          <div style={card()}><Row main={a.fixedAssetNumber || "غير مربوط بأصل مالي"} sub={[a.fixedAssetBook ? "دفتر: " + a.fixedAssetBook : "", a.countryOfOrigin ? "بلد المنشأ: " + a.countryOfOrigin : "", a.project ? "مشروع: " + a.project : ""].filter(Boolean).join(" · ")} /></div>
          {can.manage && <Btn bg={C.blue} onClick={() => setEdit(true)}>تعديل الربط من شاشة تعديل الأصل</Btn>}
        </Section>
      )}

      {sub === "الخدمة" && (
        <Section title="Service Logistics / B2B Service / Service Mapping">
          <div style={card()}><Row main="آخر عملية بيع / خدمة" sub={a.lastSalesOrderDetails || "لا توجد بيانات مبيعات/خدمة محفوظة"} /></div>
          {(db.assetServiceMappings || []).filter((m) => m.assetId === a.id).map((m) => <div key={m.id} style={card()}><Row main={m.source + " → " + m.targetField} sub={m.rule || "—"} /></div>)}
          {can.manage && <ServiceMappingForm db={db} assetId={a.id} save={ctx.save} />}
        </Section>
      )}

      {sub === "IoT" && (
        <Section title="IoT / Digital Twin Sync Events">
          <div style={card()}><Row main={a.enableIoT ? "IoT مفعل" : "IoT غير مفعل"} sub="تغيير Item / Serial / Enable IoT / Location يحفز سجل مزامنة" /></div>
          {(db.assetIotSyncEvents || []).filter((e) => e.assetId === a.id).slice().reverse().map((e) => <div key={e.id} style={card()}><Row main={e.trigger + " — " + e.status} sub={e.at + " · " + (e.message || "")} /></div>)}
          {can.manage && <Btn bg={C.purple} onClick={() => ctx.save({ ...db, assetIotSyncEvents: [...(db.assetIotSyncEvents || []), { id: uid(), assetId:a.id, at:now(), trigger:"مزامنة يدوية", status:"Queued", message:"طلب مزامنة من شاشة الأصل" }] })}>+ تسجيل حدث مزامنة</Btn>}
        </Section>
      )}

      {edit && (
        <FormSheet title="تعديل الأصل" onClose={() => setEdit(false)} db={db} schema={assetSchema()}
          initial={a} onSave={(d) => {
            const err = assetSaveErrors(d, a.id);
            if (err) { alert(err); return; }
            if (!String(d.number || "").trim()) d.number = ctx.nextAssetNumber();
            const locChanged = d.location !== a.location;
            update("assets", a.id, { ...d, history: [...(a.history || []), { action: "تعديل البيانات" + (locChanged ? " (الموقع ← " + d.location + ")" : ""), at: now(), by: ctx.role }] });
            setEdit(false);
            if (locChanged) {
              const n = propagateLocation(a.id, d.location);
              if (n > 0) alert("ℹ حُدّث موقع " + n + " أصل تابع (وراثة موقع الأب الأعلى)");
            }
          }} />
      )}
    </Sheet>
  );
}

/* ───────────────────────── العدادات ───────────────────────── */
/* ───────────────────────── العدادات (ف5) ───────────────────────── */
function Meters({ ctx }) {
  const { db, nameOf, add, update, remove, lastReading, ltd, currentValue, addReading, meterReadings, activeReadings, meterRows,
    calcUtilRate, utilRate, disableReading, can, pmCheckAfterReading, generateWO } = ctx;
  const [sub, setSub] = useState("meters");
  const [q, setQ] = useState("");
  const [tplForm, setTplForm] = useState(null); // null | "new" | tpl
  const [amForm, setAmForm] = useState(false);
  const [amSettings, setAmSettings] = useState(null);
  const [reading, setReading] = useState(null);
  const [history, setHistory] = useState(null);
  const [massTpl, setMassTpl] = useState(null);
  const tplLinked = (tplId) => db.assetMeters.filter((m) => m.templateId === tplId).length;
  const tplActive = (t) => (!t.startDate || t.startDate <= today()) && (!t.endDate || t.endDate >= today());
  const amActive = (m) => !m.endDate || m.endDate >= today();

  const tplSchema = (editing) => {
    const locked = editing && editing !== "new" && tplLinked(editing.id) > 0;
    return [
      { k: "name", label: "اسم القالب" }, { k: "code", label: "الكود (فريد)" },
      { k: "description", label: "الوصف" }, { k: "uom", label: "وحدة القياس (ساعة، كم، درجة…)" },
      { k: "meterType", label: "نوع العداد" + (locked ? " — مقفل (مرتبط بأصول)" : ""), type: "select", options: ["مستمر", "مقياس"] },
      { k: "readingType", label: "نوع القراءة" + (locked ? " — مقفل" : ""), type: "select", options: ["مطلق", "تغير"] },
      { k: "direction", label: "الاتجاه (المقياس = ثنائي)" + (locked ? " — مقفل" : ""), type: "select", options: ["تصاعدي", "تنازلي", "ثنائي"] },
      { k: "startDate", label: "بداية الفعالية", type: "date" }, { k: "endDate", label: "نهاية الفعالية", type: "date" },
      { k: "initial", label: "القيمة الابتدائية (تصبح أول قراءة عند الربط)", type: "number" },
      { k: "min", label: "حد أدنى (للتغير/المقياس)", type: "number" }, { k: "max", label: "حد أقصى (للتغير/المقياس)", type: "number" },
      { k: "recordAtWO", label: "التسجيل عند إكمال أمر العمل", type: "select", options: ["لا يسمح", "اختياري", "إلزامي"] },
      { k: "resetAllowed", label: "السماح بالتصفير (تصاعدي فقط)", type: "check" },
      { k: "resetValue", label: "قيمة التصفير (0 أو 1)", type: "number" },
      { k: "rolloverAllowed", label: "السماح بالتدوير Rollover (مستمر مطلق تصاعدي)", type: "check" },
      { k: "rolloverMax", label: "أقصى قيمة قبل التدوير", type: "number" },
      { k: "rolloverMin", label: "قيمة البداية بعد التدوير", type: "number" },
      { k: "allowSchedule", label: "يصلح لبرامج الصيانة (لا ينطبق على المقياس)", type: "check" },
      { k: "estDailyRate", label: "معدل الاستخدام اليومي المقدّر", type: "number" },
      { k: "readingsForRate", label: "عدد القراءات لحساب المعدل تلقائيًا (≥2)", type: "number" },
    ];
  };
  const validateTpl = (d, editing) => {
    if (!String(d.name || "").trim() || !String(d.code || "").trim()) return "الاسم والكود مطلوبان";
    if (db.meterTemplates.some((t) => t.code === d.code && t.id !== editing?.id)) return "الكود مستخدم — يجب أن يكون فريدًا";
    if (d.meterType === "مقياس") { d.direction = "ثنائي"; d.allowSchedule = false; d.resetAllowed = false; d.rolloverAllowed = false; }
    if (d.rolloverAllowed && !(d.meterType === "مستمر" && d.readingType === "مطلق" && d.direction === "تصاعدي"))
      return "التدوير: مستمر + مطلق + تصاعدي فقط (قاعدة ف5)";
    if (d.rolloverAllowed && !Number(d.rolloverMax)) return "حدد أقصى قيمة قبل التدوير";
    if (d.rolloverAllowed && d.resetAllowed && Number(d.rolloverMin || 0) !== Number(d.resetValue || 0))
      return "مع وجود تصفير: قيمة البداية بعد التدوير يجب أن تساوي قيمة التصفير";
    if (d.resetAllowed && d.direction !== "تصاعدي") return "التصفير للعدادات التصاعدية فقط";
    if (d.allowSchedule && d.direction !== "تصاعدي") return "يوصى ببرامج الصيانة للتصاعدي فقط — غيّر الاتجاه أو عطّل الخيار";
    if (editing && editing !== "new" && tplLinked(editing.id) > 0) {
      if (d.meterType !== editing.meterType || d.readingType !== editing.readingType || d.direction !== editing.direction)
        return "النوع/القراءة/الاتجاه مقفلة — القالب مرتبط بعدادات أصول";
    }
    return null;
  };
  const associate = (assetId, tpl, silent) => {
    if (db.assetMeters.some((m) => m.assetId === assetId && m.templateId === tpl.id && amActive(m))) return "موجود";
    const am = add("assetMeters", { assetId, templateId: tpl.id, initial: Number(tpl.initial || 0),
      recordAtWO: "", endDate: "", estDailyRate: "", readingsForRate: "" });
    if (tpl.initial !== "" && tpl.initial != null)
      add("readings", { assetMeterId: am.id, value: Number(tpl.initial), at: tpl.startDate || today(),
        source: "ربط", isReset: false, rollover: false, status: "أولية", comments: "قراءة أولية من القالب", workOrderId: "" });
    return "جديد";
  };

  const tpls = db.meterTemplates.filter((t) => !q ||
    ((t.name || "") + (t.code || "") + (t.description || "") + (t.uom || "") + (t.meterType || "") + (t.readingType || "")).includes(q));

  return (
    <>
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        <Chip active={sub === "meters"} onClick={() => setSub("meters")}>عدادات الأصول</Chip>
        <Chip active={sub === "templates"} onClick={() => setSub("templates")}>القوالب</Chip>
      </div>

      {sub === "templates" && (<>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث بالكود/الاسم/الوصف/الوحدة/النوع…" style={{ ...input, marginBottom: 10 }} />
        {can.manage && <Btn bg={C.orange} onClick={() => setTplForm("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ قالب عداد</Btn>}
        {tpls.map((t) => (
          <div key={t.id} style={{ ...card(), opacity: tplActive(t) ? 1 : 0.6 }} onClick={() => can.manage && setTplForm(t)}>
            <Row main={(t.code ? t.code + " — " : "") + t.name + " (" + t.uom + ")"}
              badge={tplLinked(t.id) ? { text: tplLinked(t.id) + " أصل", color: C.blue } : undefined}
              sub={[t.meterType, t.readingType, t.direction, t.recordAtWO !== "لا يسمح" ? "عند الإكمال: " + t.recordAtWO : "",
                t.rolloverAllowed ? "تدوير عند " + t.rolloverMax : "", !tplActive(t) ? "غير فعّال" : ""].filter(Boolean).join(" · ")} />
            {can.manage && db.assetGroups.length > 0 && (
              <button onClick={(e) => { e.stopPropagation(); setMassTpl(t); }} style={{ ...delBtn, color: C.purple }}>ربط جماعي بمجموعة…</button>
            )}
          </div>
        ))}
        {tpls.length === 0 && <Empty text="أمثلة: عداد ساعات (مستمر/مطلق/تصاعدي)، عداد رحلة (+ تصفير)، حرارة (مقياس)." />}
      </>)}

      {sub === "meters" && (<>
        <Btn bg={C.orange} onClick={() => setAmForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ ربط عداد بأصل</Btn>
        {db.assetMeters.length === 0 && <Empty text="أنشئ قالبًا ثم اربطه — كل علاقة أصل×قالب لها تاريخ قراءات مستقل." />}
        {db.assetMeters.map((m) => {
          const tpl = db.meterTemplates.find((t) => t.id === m.templateId);
          const rows = meterRows(m);
          const last = rows[rows.length - 1];
          const cr = calcUtilRate(m), ur = utilRate(m);
          return (
            <div key={m.id} style={{ ...card(), opacity: amActive(m) ? 1 : 0.55 }}>
              <Row main={nameOf("assets", m.assetId) + " — " + (tpl?.name || "عداد")}
                badge={!amActive(m) ? { text: "معطل", color: C.steel } : undefined}
                sub={["المعروض: " + (last ? last.displayed : m.initial), "العمر LTD: " + ltd(m) + " " + (tpl?.uom || ""),
                  ur ? "معدل/يوم: " + (Math.round(ur * 100) / 100) + (cr != null ? " (محسوب)" : "") : ""].filter(Boolean).join(" · ")}
                action={amActive(m) ? <Btn bg={C.blue} onClick={() => setReading(m)}>قراءة</Btn> : null} />
              <div style={{ display: "flex", gap: 10, marginTop: 6, flexWrap: "wrap" }}>
                <button onClick={() => setHistory(m)} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>السجل ({activeReadings(m.id).length})</button>
                {can.manage && <button onClick={() => setAmSettings(m)} style={{ ...delBtn, color: C.purple, marginTop: 0 }}>إعدادات</button>}
                {can.admin && (
                  <button onClick={() => {
                    const ops = activeReadings(m.id).filter((r) => r.status !== "أولية");
                    if (ops.length) { alert("توجد قراءات تشغيلية — لا حذف؛ استخدم «إعدادات ← تاريخ نهاية» للتعطيل (قاعدة ف5)"); return; }
                    if (confirm("حذف عداد الأصل وقراءته الأولية؟")) {
                      meterReadings(m.id).forEach((r) => remove("readings", r.id));
                      remove("assetMeters", m.id);
                    }
                  }} style={{ ...delBtn, marginTop: 0 }}>حذف</button>
                )}
              </div>
            </div>
          );
        })}
      </>)}

      {tplForm && (
        <FormSheet title={tplForm === "new" ? "قالب عداد جديد" : "تعديل قالب — " + tplForm.name} onClose={() => setTplForm(null)} db={db}
          schema={tplSchema(tplForm)}
          initial={tplForm === "new"
            ? { meterType: "مستمر", readingType: "مطلق", direction: "تصاعدي", recordAtWO: "لا يسمح", resetAllowed: true, resetValue: 0, rolloverMin: 0, allowSchedule: true, startDate: today() }
            : tplForm}
          onDelete={tplForm !== "new" && can.admin && tplLinked(tplForm.id) === 0 ? () => { remove("meterTemplates", tplForm.id); setTplForm(null); } : undefined}
          onSave={(d) => {
            const err = validateTpl(d, tplForm);
            if (err) { alert(err); return; }
            tplForm === "new" ? add("meterTemplates", d) : update("meterTemplates", tplForm.id, d);
            setTplForm(null);
          }} />
      )}
      {amForm && (
        <FormSheet title="ربط عداد بأصل" onClose={() => setAmForm(false)} db={db}
          schema={[
            { k: "assetId", label: "الأصل", type: "select", from: "assets", fromLabel: (a) => a.number + " — " + a.name },
            { k: "templateId", label: "القالب (الفعّال فقط)", type: "select", from: "meterTemplates",
              fromLabel: (t) => t.code + " — " + t.name + (tplActive(t) ? "" : " (غير فعّال ✗)") },
          ]} initial={{}}
          onSave={(d) => {
            if (!d.assetId || !d.templateId) { alert("اختر الأصل والقالب"); return; }
            const tpl = db.meterTemplates.find((t) => t.id === d.templateId);
            if (!tplActive(tpl)) { alert("القالب غير فعّال — لا يُنشأ عداد منه"); return; }
            const res = associate(d.assetId, tpl);
            if (res === "موجود") { alert("الأصل مرتبط بهذا القالب مسبقًا — العلاقة فريدة (قاعدة ف5)"); return; }
            setAmForm(false);
          }} />
      )}
      {massTpl && (
        <FormSheet title={"ربط جماعي — " + massTpl.name} onClose={() => setMassTpl(null)} db={db}
          schema={[{ k: "groupId", label: "مجموعة الأصول", type: "select", from: "assetGroups", fromKey: "name" }]}
          initial={{}}
          onSave={(d) => {
            const g = db.assetGroups.find((x) => x.id === d.groupId);
            if (!g) { alert("اختر المجموعة"); return; }
            let added = 0, existed = 0;
            (g.assetIds || []).forEach((aid) => { associate(aid, massTpl) === "جديد" ? added++ : existed++; });
            alert("سجل الربط الجماعي:\n• أصول رُبطت حديثًا: " + added + "\n• مرتبطة مسبقًا: " + existed);
            setMassTpl(null);
          }} />
      )}
      {amSettings && (
        <FormSheet title={"إعدادات عداد — " + nameOf("assets", amSettings.assetId)} onClose={() => setAmSettings(null)} db={db}
          schema={[
            { k: "recordAtWO", label: "التسجيل عند إكمال الأمر (فارغ = من القالب)", type: "select", options: ["", "لا يسمح", "اختياري", "إلزامي"] },
            { k: "estDailyRate", label: "معدل الاستخدام اليومي المقدّر", type: "number" },
            { k: "readingsForRate", label: "عدد القراءات للمعدل المحسوب (≥2)", type: "number" },
            { k: "endDate", label: "تاريخ نهاية (تعطيل العداد مع حفظ التاريخ)", type: "date" },
          ]} initial={amSettings}
          onSave={(d) => {
            update("assetMeters", amSettings.id, d);
            const cr = calcUtilRate({ ...amSettings, ...d });
            setAmSettings(null);
            if (cr != null) alert("المعدل المحسوب الحالي: " + (Math.round(cr * 100) / 100) + "/يوم — سيُستخدم في التوقعات بدل المقدّر");
          }} />
      )}
      {reading && <ReadingSheet ctx={ctx} am={reading} onClose={() => setReading(null)} pmCheckAfterReading={pmCheckAfterReading} generateWO={generateWO} />}
      {history && <ReadingHistory ctx={ctx} am={history} onClose={() => setHistory(null)} />}
    </>
  );
}

/* إدخال قراءة: تدوير/تصفير/تاريخية/ملاحظات (ف5 §9) */
function ReadingSheet({ ctx, am, onClose, pmCheckAfterReading, generateWO }) {
  const { db, nameOf, addReading, currentValue } = ctx;
  const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
  const [val, setVal] = useState(""); const [at, setAt] = useState(today());
  const [isReset, setIsReset] = useState(false); const [rollover, setRollover] = useState(false);
  const [historical, setHistorical] = useState(false); const [comments, setComments] = useState("");
  const [err, setErr] = useState("");
  const canReset = tpl.resetAllowed && tpl.direction === "تصاعدي" && tpl.meterType !== "مقياس";
  const canRoll = tpl.rolloverAllowed && tpl.meterType === "مستمر" && tpl.readingType === "مطلق" && tpl.direction === "تصاعدي";
  return (
    <Sheet title={"قراءة — " + tpl.name + " (المعروض: " + currentValue(am) + ")"} onClose={onClose}>
      <Field label={"القيمة الجديدة (" + (tpl.uom || "") + ")"}><input type="number" value={val} onChange={(e) => setVal(e.target.value)} style={input} /></Field>
      <Field label="تاريخ القراءة"><input type="date" value={at} onChange={(e) => setAt(e.target.value)} style={input} /></Field>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 10 }}>
        {canReset && (
          <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="checkbox" checked={isReset} onChange={(e) => { setIsReset(e.target.checked); setRollover(false); if (e.target.checked) setVal(String(tpl.resetValue ?? 0)); }} style={{ width: 20, height: 20 }} />
            <span style={{ fontSize: 14 }}>تصفير ← {tpl.resetValue ?? 0}</span>
          </label>
        )}
        {canRoll && (
          <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="checkbox" checked={rollover} onChange={(e) => { setRollover(e.target.checked); setIsReset(false); }} style={{ width: 20, height: 20 }} />
            <span style={{ fontSize: 14 }}>تدوير (تجاوز {tpl.rolloverMax})</span>
          </label>
        )}
        <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <input type="checkbox" checked={historical} onChange={(e) => setHistorical(e.target.checked)} style={{ width: 20, height: 20 }} />
          <span style={{ fontSize: 14 }}>قراءة تاريخية (بين القراءات)</span>
        </label>
      </div>
      <Field label="ملاحظات"><input value={comments} onChange={(e) => setComments(e.target.value)} style={input} /></Field>
      {historical && <div style={{ fontSize: 12, color: C.amber, marginBottom: 8 }}>سيعاد حساب المعروض والعمر لكل القراءات اللاحقة تلقائيًا.</div>}
      {err && <div style={{ color: C.red, fontSize: 13, marginBottom: 8 }}>⚠ {err}</div>}
      <Btn bg={C.orange} style={{ width: "100%", padding: 12 }} onClick={() => {
        if (val === "") return setErr("أدخل قيمة");
        const alerts = (isReset || rollover) ? [] : pmCheckAfterReading(am, val);
        const e = addReading(am, val, at, { isReset, rollover, historical, comments });
        if (e) { setErr(e); return; }
        onClose();
        alerts.forEach((x) => {
          if (x.program) { if (confirm(x.msg + "؟")) generateWO(x.program); }
          else alert(x.msg);
        });
      }}>حفظ القراءة</Btn>
    </Sheet>
  );
}

/* سجل القراءات: Net/المعروض/العمر + الحالة + تعديل الأخيرة + تعطيل (ف5 §13) */
function ReadingHistory({ ctx, am, onClose }) {
  const { db, nameOf, meterRows, meterReadings, update, disableReading, can } = ctx;
  const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
  const [editLatest, setEditLatest] = useState(false);
  const [v, setV] = useState(""); const [d, setD] = useState("");
  const rows = meterRows(am);
  const disabled = meterReadings(am.id).filter((r) => ["معطلة", "ملغاة"].includes(r.status));
  const latest = rows[rows.length - 1];
  const STATUS_COLOR = { "مسجلة": C.ink, "أولية": C.blue, "تصفير": C.amber, "تدوير": C.purple, "معدلة": C.steel, "معطلة": C.steel };
  return (
    <Sheet title={"سجل القراءات — " + tpl.name} onClose={onClose}>
      {rows.slice().reverse().map((r) => {
        const isLatest = latest && r.id === latest.id;
        return (
          <div key={r.id} style={{ ...card(), borderRightColor: STATUS_COLOR[r.status] || C.ink }}>
            <Row main={"المعروض: " + r.displayed + " · العمر: " + r.ltd}
              badge={{ text: r.status, color: STATUS_COLOR[r.status] || C.ink }}
              sub={[r.at, "القيمة: " + r.value, "التغير: " + (Math.round(r.net * 100) / 100), r.source,
                r.workOrderId ? db.workOrders.find((w) => w.id === r.workOrderId)?.number : "", r.comments].filter(Boolean).join(" · ")} />
            {can.manage && (
              <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
                {isLatest && r.status !== "أولية" && <button onClick={() => { setEditLatest(r); setV(String(r.value)); setD(r.at); }} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>تعديل (الأخيرة فقط)</button>}
                {r.status !== "أولية" && <button onClick={() => { const e = disableReading(am, r); if (e) alert(e); }} style={{ ...delBtn, marginTop: 0 }}>تعطيل</button>}
              </div>
            )}
          </div>
        );
      })}
      {rows.length === 0 && <Empty text="لا قراءات فعالة." />}
      {disabled.length > 0 && (
        <Section title={"قراءات معطلة (" + disabled.length + ") — مستبعدة من الحساب"}>
          {disabled.map((r) => (
            <div key={r.id} style={{ ...card(), opacity: 0.5 }}>
              <Row main={"القيمة: " + r.value} sub={r.at + (r.comments ? " · " + r.comments : "")} badge={{ text: r.status, color: C.steel }} />
            </div>
          ))}
        </Section>
      )}
      {editLatest && (
        <Sheet title="تعديل آخر قراءة" onClose={() => setEditLatest(false)}>
          <Field label="القيمة"><input type="number" value={v} onChange={(e) => setV(e.target.value)} style={input} /></Field>
          <Field label="التاريخ"><input type="date" value={d} onChange={(e) => setD(e.target.value)} style={input} /></Field>
          <Btn bg={C.green} style={{ width: "100%", padding: 12 }} onClick={() => {
            update("readings", editLatest.id, { value: Number(v), at: d, status: "معدلة" });
            setEditLatest(false);
          }}>حفظ التعديل</Btn>
        </Sheet>
      )}
    </Sheet>
  );
}

/* ───────────────────────── منظمة الصيانة ───────────────────────── */
function Organization({ ctx }) {
  const { db } = ctx;
  const [sub, setSub] = useState("orgs");
  const resourceLocked = (r) => db.workCenters.some((wc) => wc.id === r.workCenterId) || db.resourceInstances.some((i) => i.resourceId === r.id);
  const orgReady = db.maintenanceOrganizations.length > 0 && db.workAreas.length > 0 && db.workCenters.length > 0;
  return (
    <>
      <div style={{ display: "flex", gap: 6, marginBottom: 12, overflowX: "auto" }}>
        <Chip active={sub === "orgs"} onClick={() => setSub("orgs")}>المنظمة</Chip>
        <Chip active={sub === "plant"} onClick={() => setSub("plant")}>Plant Parameters</Chip>
        <Chip active={sub === "areas"} onClick={() => setSub("areas")}>مناطق العمل</Chip>
        <Chip active={sub === "centers"} onClick={() => setSub("centers")}>مراكز العمل</Chip>
        <Chip active={sub === "resources"} onClick={() => setSub("resources")}>الموارد</Chip>
        <Chip active={sub === "instances"} onClick={() => setSub("instances")}>Resource Instances</Chip>
        <Chip active={sub === "shifts"} onClick={() => setSub("shifts")}>الورديات</Chip>
        <Chip active={sub === "exceptions"} onClick={() => setSub("exceptions")}>الاستثناءات</Chip>
      </div>
      <div style={{ ...card(), borderRightColor: orgReady ? C.green : C.amber, fontSize:13, marginBottom:12 }}>
        حالة التشغيل: {orgReady ? "جاهزة تشغيليًا" : "غير مكتملة — تحتاج منظمة + منطقة عمل + مركز عمل"}
      </div>
      {sub === "orgs" && <Crud ctx={ctx} entity="maintenanceOrganizations" title="منظمات الصيانة" schema={[
        { k:"code", label:"كود المنظمة" }, { k:"name", label:"اسم المنظمة" },
        { k:"status", label:"الحالة", type:"select", options: MAINT_ORG_STATUS },
        { k:"isMaintenanceEnabled", label:"مفعلة للصيانة", type:"check" },
        { k:"isProjectTracked", label:"Project Tracked", type:"check" },
        { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d, form) => !String(d.code||"").trim() ? "كود المنظمة مطلوب" : db.maintenanceOrganizations.some((o) => o.code === d.code && o.id !== form?.id) ? "كود المنظمة مستخدم" : null}
      render={(o) => [o.name || o.code, [o.code, o.status, o.isMaintenanceEnabled ? "Maintenance Enabled" : "غير مفعلة", o.isProjectTracked ? "Project" : ""].filter(Boolean).join(" · ")]} />}
      {sub === "plant" && <Crud ctx={ctx} entity="plantParameters" title="Plant Parameters" schema={[
        { k:"organizationId", label:"منظمة الصيانة", type:"select", from:"maintenanceOrganizations", fromKey:"name" },
        { k:"assetCreationMode", label:"Asset Creation Mode", type:"select", options: ASSET_CREATION_MODES },
        { k:"autoAssetPrefix", label:"بادئة أرقام الأصول" },
        { k:"requireItemForEnterpriseAssets", label:"Item مطلوب لأصول المؤسسة", type:"check" },
        { k:"requireFullLifecycleForWO", label:"Full Lifecycle مطلوب لأوامر العمل", type:"check" },
        { k:"defaultUnknownLocation", label:"اجعل الموقع Unknown عند النقص", type:"check" },
        { k:"projectTrackingEnabled", label:"Project Driven Supply Chain", type:"check" },
        { k:"inventoryIssuePolicy", label:"سياسة صرف المواد" },
      ]} validate={(d) => !d.organizationId ? "اختر منظمة الصيانة" : null}
      render={(p) => [ctx.nameOf("maintenanceOrganizations", p.organizationId), [p.assetCreationMode, p.inventoryIssuePolicy, p.projectTrackingEnabled ? "Project" : ""].filter(Boolean).join(" · ")]} />}
      {sub === "areas" && <Crud ctx={ctx} entity="workAreas" title="مناطق العمل" schema={[
        { k: "organizationId", label:"المنظمة", type:"select", from:"maintenanceOrganizations", fromKey:"name" },
        { k: "name", label: "الاسم" }, { k: "code", label: "الرمز" }, { k: "description", label: "الوصف" }, { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d, form) => !d.organizationId ? "منطقة العمل يجب أن تتبع منظمة" : !String(d.name||"").trim() ? "الاسم مطلوب" : db.workAreas.some((x) => x.organizationId === d.organizationId && x.code === d.code && x.id !== form?.id) ? "رمز منطقة العمل مستخدم داخل نفس المنظمة" : null}
      render={(a) => [a.name, [a.code, ctx.nameOf("maintenanceOrganizations", a.organizationId)].filter(Boolean).join(" · ")]} />}
      {sub === "centers" && <Crud ctx={ctx} entity="workCenters" title="مراكز العمل" schema={[
        { k: "organizationId", label:"المنظمة", type:"select", from:"maintenanceOrganizations", fromKey:"name" },
        { k: "name", label: "الاسم (الورشة الميكانيكية…)" }, { k: "code", label: "الرمز" },
        { k: "workAreaId", label: "منطقة العمل", type: "select", from: "workAreas", fromKey: "name" },
        { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d) => !d.workAreaId ? "مركز العمل يجب أن يتبع منطقة عمل" : null}
      render={(a) => [a.name, "ضمن " + ctx.nameOf("workAreas", a.workAreaId)]} />}
      {sub === "resources" && <Crud ctx={ctx} entity="resources" title="الموارد" schema={[
        { k: "code", label:"كود المورد" }, { k: "name", label: "الاسم" },
        { k: "type", label: "النوع", type: "select", options: RESOURCE_TYPES },
        { k: "usageUom", label: "UOM الاستخدام", type:"select", options: RESOURCE_UOMS },
        { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
        { k: "qty", label: "العدد المتاح", type: "number" },
        { k:"available24h", label:"متاح 24 ساعة", type:"check" },
        { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d, form) => form?.id && resourceLocked(form) && d.usageUom !== form.usageUom ? "UOM المورد لا يغيّر بعد ربطه بمركز عمل أو Instance" : null}
      validateDelete={(r) => resourceLocked(r) ? "لا يمكن حذف المورد لأنه مرتبط بمركز عمل أو Resource Instance نشط" : null}
      render={(r) => [r.name, [r.code, r.type, r.usageUom, ctx.nameOf("workCenters", r.workCenterId), r.available24h ? "24h" : "ورديات"].filter((x) => x && x !== "—").join(" · ")]} />}
      {sub === "instances" && <Crud ctx={ctx} entity="resourceInstances" title="Resource Instances" schema={[
        { k:"identifier", label:"معرّف فريد للـ Instance" },
        { k:"resourceId", label:"المورد", type:"select", from:"resources", fromKey:"name" },
        { k:"instanceType", label:"مصدر الإنشاء", type:"select", options:["شخص", "أصل", "يدوي"] },
        { k:"personName", label:"اسم الشخص / اليدوي" },
        { k:"assetId", label:"الأصل المرتبط للمعدات", type:"select", from:"assets", fromKey:"name" },
        { k:"qualifications", label:"المؤهلات", type:"textarea" },
        { k:"active", label:"نشط", type:"check" },
        { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d, form) => !String(d.identifier||"").trim() ? "المعرّف مطلوب" : db.resourceInstances.some((x) => x.identifier === d.identifier && x.id !== form?.id) ? "المعرّف مستخدم" : (db.resources.find((r) => r.id === d.resourceId)?.type === "معدات" && d.instanceType === "أصل" && !d.assetId) ? "تأهيل المعدات يتطلب ربط Asset Number" : null}
      render={(i) => [i.identifier, [ctx.nameOf("resources", i.resourceId), i.instanceType, i.assetId ? "Asset: " + ctx.nameOf("assets", i.assetId) : i.personName].filter(Boolean).join(" · ")]} />}
      {sub === "shifts" && <Crud ctx={ctx} entity="shifts" title="الورديات" schema={[
        { k:"name", label:"اسم الوردية" }, { k:"code", label:"الكود" },
        { k:"shiftType", label:"النوع", type:"select", options: SHIFT_TYPES },
        { k:"startTime", label:"وقت البداية" }, { k:"endTime", label:"وقت النهاية" },
        { k:"days", label:"الأيام" }, { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} render={(s) => [s.name, [s.code, s.shiftType, s.startTime + "-" + s.endTime, s.days].filter(Boolean).join(" · ")]} />}
      {sub === "exceptions" && <Crud ctx={ctx} entity="resourceExceptions" title="استثناءات تقويم المورد" schema={[
        { k:"workCenterId", label:"مركز العمل", type:"select", from:"workCenters", fromKey:"name" },
        { k:"resourceId", label:"المورد", type:"select", from:"resources", fromKey:"name" },
        { k:"date", label:"التاريخ", type:"date" },
        { k:"exceptionType", label:"نوع الاستثناء", type:"select", options: EXCEPTION_TYPES },
        { k:"startTime", label:"من" }, { k:"endTime", label:"إلى" },
        { k:"reason", label:"السبب", type:"textarea" },
      ]} validate={(d) => db.resources.find((r) => r.id === d.resourceId)?.available24h ? "لا تنشئ استثناء لمورد متاح 24 ساعة" : null}
      render={(e) => [ctx.nameOf("resources", e.resourceId), [e.exceptionType, fmt(e.date), e.reason].filter(Boolean).join(" · ")]} />}
    </>
  );
}

function OracleCompliance({ ctx, setTab }) {
  const { db, save } = ctx;
  const checks = [
    ["Maintenance Organization", db.maintenanceOrganizations.length > 0, "org"],
    ["Plant Parameters", db.plantParameters.length > 0, "org"],
    ["Work Area", db.workAreas.length > 0, "org"],
    ["Work Center", db.workCenters.length > 0, "org"],
    ["Resources", db.resources.length > 0, "org"],
    ["Resource Instances", db.resourceInstances.length > 0, "org"],
    ["Shifts", db.shifts.length > 0, "org"],
    ["Smart Asset Search", true, "assets"],
    ["Asset 360", true, "assets"],
    ["Flexfields / Fixed Assets / Service / IoT", true, "assets"],
    ["Asset Import/Export", true, "data"],
  ];
  const seed = () => {
    const orgId = db.maintenanceOrganizations[0]?.id || uid();
    const areaId = db.workAreas[0]?.id || uid();
    const wcId = db.workCenters[0]?.id || uid();
    const resId = db.resources[0]?.id || uid();
    save({ ...db,
      maintenanceOrganizations: db.maintenanceOrganizations.length ? db.maintenanceOrganizations : [{ id:orgId, code:"MAIN", name:"Main Maintenance Organization", status:"عاملة", isMaintenanceEnabled:true, isProjectTracked:false, inactiveOn:"" }],
      plantParameters: db.plantParameters.length ? db.plantParameters : [{ id:uid(), organizationId:orgId, assetCreationMode:"IMMEDIATE", autoAssetPrefix:"AST", requireItemForEnterpriseAssets:false, requireFullLifecycleForWO:false, defaultUnknownLocation:true, projectTrackingEnabled:false, inventoryIssuePolicy:"لا صرف مواد بدون أمر عمل" }],
      workAreas: db.workAreas.length ? db.workAreas : [{ id:areaId, organizationId:orgId, code:"MILL", name:"Mill Maintenance Area", description:"منطقة صيانة المطحن", inactiveOn:"" }],
      workCenters: db.workCenters.length ? db.workCenters : [{ id:wcId, organizationId:orgId, workAreaId:areaId, code:"MECH", name:"Mechanical Workshop", inactiveOn:"" }],
      resources: db.resources.length ? db.resources : [{ id:resId, code:"LAB-MECH", name:"Mechanical Labor", type:"عمالة", usageUom:"ساعة", workCenterId:wcId, qty:4, available24h:false, inactiveOn:"" }],
      resourceInstances: db.resourceInstances.length ? db.resourceInstances : [{ id:uid(), resourceId:resId, identifier:"TECH-001", instanceType:"يدوي", personName:"Technician 001", assetId:"", active:true, qualifications:"عام", inactiveOn:"" }],
      shifts: db.shifts.length ? db.shifts : [{ id:uid(), name:"Day Shift", code:"DAY", shiftType:"صباحي", startTime:"08:00", endTime:"17:00", days:"الأحد,الاثنين,الثلاثاء,الأربعاء,الخميس", inactiveOn:"" }],
    });
  };
  return (
    <>
      <Section title="مطابقة الملفات المرفوعة — Chapters 01, 02, 03">
        <div style={card()}>
          <div style={{ fontWeight:800, marginBottom:6 }}>تمت إضافة المتطلبات الناقصة كوظائف داخل التطبيق.</div>
          <div style={{ fontSize:13, color:C.steel }}>هذه الشاشة تعطيك Audit سريع: هل توجد بيانات تشغيلية لكل وحدة، وأين تفتحها.</div>
        </div>
        {checks.map(([name, ok, tab]) => <div key={name} style={{ ...card(), borderRightColor: ok ? C.green : C.amber }} onClick={() => setTab(tab)}>
          <Row main={name} sub={ok ? "موجود / جاهز" : "الواجهة موجودة وتحتاج بيانات"} badge={{ text: ok ? "✓" : "بيانات", color: ok ? C.green : C.amber }} />
        </div>)}
        <Btn bg={C.orange} style={{ width:"100%", padding:12 }} onClick={seed}>+ إنشاء إعدادات صيانة افتراضية</Btn>
      </Section>
      <Section title="قائمة الميزات المضافة من الملفات">
        {ORACLE_FEATURES.map(([feature, ch, tab]) => <div key={feature} style={card()} onClick={() => setTab(tab)}><Row main={feature} sub={ch + " · اضغط للانتقال"} /></div>)}
      </Section>
    </>
  );
}

function ServiceMappingForm({ db, assetId, save }) {
  const [source, setSource] = useState("Sales Order");
  const [targetField, setTargetField] = useState("customer");
  const [rule, setRule] = useState("");
  return <div style={card()}>
    <Field label="المصدر"><select value={source} onChange={(e) => setSource(e.target.value)} style={input}>{["Sales Order", "Service Request", "Field Service Work Order", "Subscription", "Manual"].map((x) => <option key={x}>{x}</option>)}</select></Field>
    <Field label="الحقل الهدف في الأصل"><input value={targetField} onChange={(e) => setTargetField(e.target.value)} style={input} /></Field>
    <Field label="قاعدة النقل"><textarea value={rule} onChange={(e) => setRule(e.target.value)} rows={2} style={{ ...input, resize:"vertical" }} /></Field>
    <Btn bg={C.green} style={{ width:"100%" }} onClick={() => { if (!targetField.trim()) return; save({ ...db, assetServiceMappings: [...(db.assetServiceMappings || []), { id:uid(), assetId, source, targetField, rule }] }); setRule(""); }}>+ إضافة Service Mapping</Btn>
  </div>;
}

/* ───────────────────────── الحوكمة والرقابة ───────────────────────── */
function GovernanceHub({ ctx }) {
  const { db, save, can, role, firebaseEnabled } = ctx;
  const [sub, setSub] = useState("dashboard");

  const plusDays = (n) => addDateDays(today(), Number(n || 0));
  const auditCount = (db.governanceAuditEvents || []).length
    + db.workOrders.reduce((n, w) => n + (w.execLog || []).length + (w.history || []).length, 0)
    + db.assets.reduce((n, a) => n + (a.history || []).length, 0);
  const orgReady = db.maintenanceOrganizations.length > 0 && db.workAreas.length > 0 && db.workCenters.length > 0;
  const activePolicies = (db.governancePolicies || []).filter((p) => p.status === "سارية");
  const activeApprovals = (db.approvalMatrix || []).filter((a) => a.active);
  const openApprovalRequests = (db.governanceApprovalRequests || []).filter((r) => r.status === "مفتوح");
  const highRisks = (db.governanceRisks || []).filter((r) => ["عال", "حرج"].includes(r.level) && r.status !== "مغلق").length;
  const overdueReviews = (db.governanceReviews || []).filter((r) => r.nextReview && daysUntil(r.nextReview) < 0 && r.status !== "مغلق").length;
  const overduePolicies = activePolicies.filter((p) => p.reviewDate && daysUntil(p.reviewDate) < 0).length;

  const duplicateAssetNumbers = db.assets
    .filter((a) => a.number)
    .filter((a, i, arr) => arr.findIndex((x) => x.number === a.number) !== i).length;
  const duplicateSerials = db.assets
    .filter((a) => a.serial && a.operatingOrganizationId)
    .filter((a, i, arr) => arr.findIndex((x) => x.serial === a.serial && x.operatingOrganizationId === a.operatingOrganizationId) !== i).length;

  const qualityFindings = [];
  if (!db.maintenanceOrganizations.length) qualityFindings.push({ severity:"حرج", area:"منظمة الصيانة", issue:"لا توجد Maintenance Organization", fix:"أنشئ منظمة صيانة ثم Work Area وWork Center." });
  if (db.maintenanceOrganizations.length && !db.workAreas.length) qualityFindings.push({ severity:"عال", area:"منظمة الصيانة", issue:"لا توجد Work Areas", fix:"أضف منطقة عمل واحدة على الأقل لكل منظمة تشغيلية." });
  if (db.workAreas.length && !db.workCenters.length) qualityFindings.push({ severity:"عال", area:"منظمة الصيانة", issue:"لا توجد Work Centers", fix:"أضف مركز عمل داخل منطقة العمل." });
  if (duplicateAssetNumbers) qualityFindings.push({ severity:"حرج", area:"الأصول", issue:"أرقام أصول مكررة: " + duplicateAssetNumbers, fix:"اجعل Asset Number فريدًا قبل التشغيل." });
  if (duplicateSerials) qualityFindings.push({ severity:"عال", area:"الأصول", issue:"Serial Number مكرر داخل نفس منظمة التشغيل: " + duplicateSerials, fix:"صحح الرقم التسلسلي أو منظمة التشغيل." });
  db.assets.forEach((a) => {
    const ref = a.number || a.name || "أصل بدون رقم";
    if (!a.number) qualityFindings.push({ severity:"عال", area:"الأصول", ref, issue:"أصل بدون Asset Number", fix:"أضف رقمًا أو استخدم التوليد التلقائي." });
    if (!a.location && a.locationType !== "UNKNOWN") qualityFindings.push({ severity:"متوسط", area:"الأصول", ref, issue:"نوع الموقع محدد لكن الموقع فارغ", fix:"أدخل الموقع أو اجعل Location Type = UNKNOWN بمبرر." });
    if (a.itemRequired && !a.itemName && !a.itemId) qualityFindings.push({ severity:"عال", area:"الأصول", ref, issue:"Item مطلوب وغير محدد", fix:"اربط الأصل بصنف أو ألغِ Item Required إذا كان مناسبًا." });
    if (a.allowWO !== false && a.assetType === "ENTERPRISE" && a.itemRequired && a.fullLifecycleTracked === false) qualityFindings.push({ severity:"متوسط", area:"الأصول", ref, issue:"أوامر العمل مسموحة مع Item غير Full Lifecycle", fix:"فعّل Full Lifecycle أو امنع أوامر العمل على هذا الأصل." });
    if (a.endDate && ACTIVE_STATES.some((s) => db.workOrders.some((w) => w.assetId === a.id && w.status === s))) qualityFindings.push({ severity:"عال", area:"الأصول", ref, issue:"أصل منتهي وله أمر عمل مفتوح", fix:"أغلق الأمر أو أعد تفعيل/تصحيح تاريخ الأصل." });
  });
  db.workOrders.forEach((w) => {
    const ref = w.number || w.title || "أمر عمل";
    if (!w.assetId) qualityFindings.push({ severity:"عال", area:"أوامر العمل", ref, issue:"أمر عمل بدون أصل", fix:"اربط الأمر بأصل صالح." });
    if (w.status === "مغلق" && !(w.history || []).some((h) => h.to === "مغلق")) qualityFindings.push({ severity:"منخفض", area:"أوامر العمل", ref, issue:"أمر مغلق بدون أثر حالة واضح", fix:"راجع سجل الحالة أو أعد الإغلاق عبر المسار النظامي." });
    if (["تصحيحي", "طارئ"].includes(w.type) && w.status === "مغلق" && !w.failure) qualityFindings.push({ severity:"متوسط", area:"أوامر العمل", ref, issue:"أمر تصحيحي/طارئ مغلق بدون Failure", fix:"سجل نمط العطل وزمن التوقف وسبب الإصلاح." });
    if (w.status === "بانتظار المراجعة" && !(w.execLog || []).length) qualityFindings.push({ severity:"متوسط", area:"أوامر العمل", ref, issue:"بانتظار مراجعة بدون سجل تنفيذ", fix:"راجع سجل التنفيذ قبل الاعتماد." });
  });
  db.resources.forEach((r) => { if (!r.workCenterId) qualityFindings.push({ severity:"متوسط", area:"الموارد", ref:r.name, issue:"مورد غير مربوط بمركز عمل", fix:"اربط المورد بمركز العمل المناسب." }); });
  db.stockTx.forEach((t) => { if (Number(t.qty || 0) <= 0) qualityFindings.push({ severity:"متوسط", area:"المخزون", ref:t.type, issue:"حركة مخزون بكمية غير صحيحة", fix:"صحح الكمية أو احذف الحركة الخاطئة." }); });
  db.assetMeters.forEach((m) => { if (!m.assetId || !m.templateId) qualityFindings.push({ severity:"متوسط", area:"العدادات", issue:"عداد أصل ناقص الربط", fix:"اربط العداد بأصل وقالب عداد." }); });

  const checks = [
    ["سياسات حوكمة موثقة", activePolicies.length >= 3, "أضف سياسات سارية للأصول، أوامر العمل، المخزون، البيانات."],
    ["مصفوفة اعتماد", activeApprovals.length >= 3, "عرّف من يعتمد الإغلاق، الحذف، التسوية، الاستيراد، وتغيير الصلاحيات."],
    ["طلبات اعتماد قابلة للتتبع", (db.governanceApprovalRequests || []).length > 0 || activeApprovals.length >= 3, "أضف طلبات اعتماد أو اربط المصفوفة بالإجراءات الحساسة."],
    ["سجل تدقيق", auditCount > 0, "التطبيق يسجل أوامر العمل والأصول؛ أضف أحداث حوكمة عامة."],
    ["إدارة مخاطر", (db.governanceRisks || []).length > 0, "أضف سجل مخاطر تشغيلية ومالكية لكل خطر."],
    ["مراجعات دورية", (db.governanceReviews || []).length > 0, "حدد مراجعة شهرية/ربع سنوية للبيانات والصلاحيات."],
    ["قواعد جودة بيانات", (db.governanceDataQualityRules || []).length > 0, "أضف قواعد جودة بيانات قابلة للمراجعة."],
    ["منظمة صيانة جاهزة", orgReady, "أنشئ Organization + Work Area + Work Center."],
    ["جودة بيانات الأصول", qualityFindings.filter((x) => ["عال", "حرج"].includes(x.severity)).length === 0, "صحح الملاحظات عالية الخطورة في تبويب جودة البيانات."],
    ["حوكمة Backend", firebaseEnabled || !String(API).includes("localhost"), "فعّل Firebase أو استخدم رابط API خارجي HTTPS بدل localhost."],
  ];
  const okCount = checks.filter((c) => c[1]).length;
  const penalty = highRisks * 4 + overdueReviews * 4 + overduePolicies * 4 + openApprovalRequests.length * 2;
  const score = Math.max(0, Math.min(100, Math.round((okCount / checks.length) * 100) - penalty));
  const scoreColor = score >= 85 ? C.green : score >= 65 ? C.amber : C.red;

  const addAudit = (action, area = "الحوكمة", extra = {}) => save({ ...db, governanceAuditEvents: [...(db.governanceAuditEvents || []), { id: uid(), at: now(), by: role, area, action, ...extra }] });
  const decideRequest = (r, status) => {
    save({ ...db,
      governanceApprovalRequests: (db.governanceApprovalRequests || []).map((x) => x.id === r.id ? { ...x, status, decisionBy:role, decisionAt:now() } : x),
      governanceAuditEvents: [...(db.governanceAuditEvents || []), { id:uid(), at:now(), by:role, area:r.area || "اعتماد", action:"قرار طلب اعتماد " + (r.number || r.title || "") + ": " + status }]
    });
  };
  const seed = () => {
    const todayDate = today();
    save({ ...db,
      governancePolicies: (db.governancePolicies || []).length ? db.governancePolicies : [
        { id:uid(), code:"GOV-AM-001", title:"سياسة إدارة الأصول", type:"سياسة", scope:"كل الأصول", ownerRole:"مدير", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(180), controlObjective:"ضمان إنشاء الأصول وتعديلها وتتبعها ضمن قواعد موحدة.", evidenceRequired:"سجل الأصل، سجل التغييرات، Asset 360" },
        { id:uid(), code:"GOV-WO-001", title:"سياسة أوامر العمل والاعتماد", type:"إجراء", scope:"أوامر العمل", ownerRole:"مشرف", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(180), controlObjective:"منع إغلاق أوامر العمل قبل اكتمال السلامة والعمليات والساعات والمواد.", evidenceRequired:"سجل التنفيذ، مراجعة المشرف" },
        { id:uid(), code:"GOV-INV-001", title:"سياسة صرف وتسوية المخزون", type:"ضابط رقابي", scope:"المخزون", ownerRole:"مخزن", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(90), controlObjective:"ربط الصرف بأمر عمل وتقليل التسويات غير المبررة.", evidenceRequired:"حركات المخزون وأمر العمل" },
        { id:uid(), code:"GOV-DATA-001", title:"سياسة جودة بيانات الأصول", type:"تعليمات تشغيل", scope:"بيانات الأصول", ownerRole:"مدير", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(90), controlObjective:"استكمال الموقع ونوع الموقع والرقم التسلسلي/الصنف للأصول المطلوبة.", evidenceRequired:"تقرير جودة الأصول" },
        { id:uid(), code:"GOV-SEC-001", title:"سياسة التحكم بالصلاحيات", type:"سياسة", scope:"الأدوار والمستخدمون", ownerRole:"مدير", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(90), controlObjective:"تطبيق أقل صلاحية وفصل المسؤوليات بين التنفيذ والاعتماد والمخزون.", evidenceRequired:"مراجعة صلاحيات شهرية" },
      ],
      approvalMatrix: (db.approvalMatrix || []).length ? db.approvalMatrix : [
        { id:uid(), process:"أمر عمل", action:"إصدار", requesterRole:"مشرف", approverRole:"مشرف", minPriority:"عادي", amountLimit:"", requiresSecondApproval:false, active:true, notes:"إصدار أوامر العمل المخططة." },
        { id:uid(), process:"أمر عمل", action:"إغلاق", requesterRole:"فني", approverRole:"مشرف", minPriority:"عادي", amountLimit:"", requiresSecondApproval:false, active:true, notes:"لا إغلاق نهائي بدون مراجعة المشرف." },
        { id:uid(), process:"مخزون", action:"تسوية", requesterRole:"مخزن", approverRole:"مدير", minPriority:"", amountLimit:"", requiresSecondApproval:true, active:true, notes:"التسويات تحتاج سبب واعتماد إداري." },
        { id:uid(), process:"أصل", action:"حذف", requesterRole:"مشرف", approverRole:"مدير", minPriority:"", amountLimit:"", requiresSecondApproval:true, active:true, notes:"يفضل التعطيل بدل الحذف عند وجود تاريخ." },
        { id:uid(), process:"صلاحيات", action:"تغيير صلاحية", requesterRole:"مدير", approverRole:"مدير", minPriority:"", amountLimit:"", requiresSecondApproval:false, active:true, notes:"مراجعة صلاحيات شهرية." },
        { id:uid(), process:"بيانات", action:"استيراد", requesterRole:"مدير", approverRole:"مدير", minPriority:"", amountLimit:"", requiresSecondApproval:true, active:true, notes:"استيراد البيانات أو مسحها يحتاج اعتمادًا وتوثيقًا." },
      ],
      governanceDataQualityRules: (db.governanceDataQualityRules || []).length ? db.governanceDataQualityRules : [
        { id:uid(), code:"DQ-ORG-001", title:"المنظمة التشغيلية مكتملة", entity:"maintenanceOrganizations", severity:"عال", ownerRole:"مدير", active:true, description:"Organization + Work Area + Work Center قبل التشغيل." },
        { id:uid(), code:"DQ-AST-001", title:"رقم الأصل فريد وموجود", entity:"assets", severity:"حرج", ownerRole:"مشرف", active:true, description:"لا يسمح بتكرار Asset Number أو تركه فارغًا." },
        { id:uid(), code:"DQ-AST-002", title:"موقع الأصل واضح", entity:"assets", severity:"متوسط", ownerRole:"مشرف", active:true, description:"الأصل التشغيلي يحتاج Location Type وموقع أو UNKNOWN مبرر." },
        { id:uid(), code:"DQ-WO-001", title:"بوابات إغلاق أمر العمل", entity:"workOrders", severity:"عال", ownerRole:"مشرف", active:true, description:"سلامة، عمليات، ساعات، مواد، قراءات، وفشل عند التصحيحي/الطارئ." },
        { id:uid(), code:"DQ-INV-001", title:"حركات المخزون بكمية صحيحة", entity:"stockTx", severity:"متوسط", ownerRole:"مخزن", active:true, description:"كل حركة مخزون يجب أن تكون بكمية موجبة وسبب واضح." },
      ],
      governanceRisks: (db.governanceRisks || []).length ? db.governanceRisks : [
        { id:uid(), area:"الصلاحيات", risk:"تغيير الدور من الواجهة لا يمثل تحكمًا أمنيًا حقيقيًا بدون تسجيل دخول Backend.", level:"حرج", owner:"مدير", mitigation:"إضافة Auth حقيقي وصلاحيات من الخادم.", status:"مفتوح", dueDate:plusDays(30) },
        { id:uid(), area:"البيانات", risk:"حفظ كل البيانات كـ JSON واحد مناسب مؤقتًا لكنه يصعب التدقيق والتحكم طويلًا.", level:"عال", owner:"مدير", mitigation:"تحويل الكيانات الأساسية إلى جداول PostgreSQL مستقلة.", status:"مفتوح", dueDate:plusDays(60) },
        { id:uid(), area:"المرفقات", risk:"تخزين الصور Base64 داخل البيانات يرفع الحجم ويصعب النسخ الاحتياطي.", level:"متوسط", owner:"مدير", mitigation:"نقل الصور إلى Storage وحفظ الروابط فقط.", status:"مفتوح", dueDate:plusDays(60) },
      ],
      governanceReviews: (db.governanceReviews || []).length ? db.governanceReviews : [
        { id:uid(), name:"مراجعة صلاحيات المستخدمين", frequency:"شهري", owner:"مدير", lastReview:"", nextReview:plusDays(30), status:"مفتوح", notes:"تأكد من أدوار المدير/المشرف/المخزن/الفني." },
        { id:uid(), name:"مراجعة جودة بيانات الأصول", frequency:"ربع سنوي", owner:"مشرف", lastReview:"", nextReview:plusDays(90), status:"مفتوح", notes:"الأصول بدون موقع أو نوع موقع أو رقم تسلسلي." },
        { id:uid(), name:"مراجعة التسويات وحركات المخزون", frequency:"شهري", owner:"مخزن", lastReview:"", nextReview:plusDays(30), status:"مفتوح", notes:"راجع التسويات والإتلاف والصرف بدون أمر عمل." },
        { id:uid(), name:"مراجعة المخاطر المفتوحة", frequency:"شهري", owner:"مدير", lastReview:"", nextReview:plusDays(30), status:"مفتوح", notes:"أغلق أو حدّث المخاطر المفتوحة." },
      ],
      governanceApprovalRequests: (db.governanceApprovalRequests || []).length ? db.governanceApprovalRequests : [
        { id:uid(), number:"APR-1001", title:"اعتماد تحويل الحوكمة للإنتاج", area:"Backend", requesterRole:"مدير", approverRole:"مدير", status:"مفتوح", riskLevel:"عال", requestedAt:now(), justification:"تأكيد جاهزية الصلاحيات والنسخ الاحتياطي قبل التشغيل." },
      ],
      governanceAuditEvents: [...(db.governanceAuditEvents || []), { id:uid(), at:now(), by:role, area:"الحوكمة", action:"إنشاء حزمة حوكمة افتراضية متقدمة" }]
    });
  };
  const tabs = [["dashboard","الملخص"],["policies","السياسات"],["approvals","المصفوفة"],["requests","طلبات الاعتماد"],["quality","جودة البيانات"],["risks","المخاطر"],["changes","التغييرات"],["reviews","المراجعات"],["audit","التدقيق"]];
  return (
    <>
      <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:8, marginBottom:12 }}>
        {tabs.map(([id, label]) => <Chip key={id} active={sub === id} onClick={() => setSub(id)}>{label}</Chip>)}
      </div>
      {sub === "dashboard" && (
        <>
          <div style={{ display:"flex", gap:8, marginBottom:16 }}>
            <Stat n={score + "%"} label="نضج الحوكمة" color={scoreColor} />
            <Stat n={highRisks} label="مخاطر عالية" color={highRisks ? C.red : C.green} />
            <Stat n={overdueReviews + overduePolicies} label="متأخر" color={(overdueReviews + overduePolicies) ? C.red : C.green} />
            <Stat n={auditCount} label="أحداث تدقيق" color={C.blue} small />
          </div>
          <Section title="تقييمي للحالة الحالية">
            <div style={{ ...card(), borderRightColor: scoreColor, fontSize:13, lineHeight:1.8 }}>
              الحوكمة الموجودة جيدة جدًا كنموذج MVP، لكنها لا تصل إلى ممتازة إنتاجيًا إلا بعد تفعيل Backend خارجي، مصادقة حقيقية، وربط الاعتمادات بالإجراءات الحساسة من الخادم. أضفت هنا طبقة أقوى: طلبات اعتماد، قواعد جودة بيانات، فحص آلي، ومراجعات دورية بجانب السياسات والمخاطر.
            </div>
          </Section>
          <Section title="حالة الحوكمة">
            {checks.map(([name, ok, hint]) => <div key={name} style={{ ...card(), borderRightColor: ok ? C.green : C.amber }}>
              <Row main={name} sub={ok ? "مكتمل / جيد" : hint} badge={{ text: ok ? "✓" : "تحسين", color: ok ? C.green : C.amber }} />
            </div>)}
            {can.manage && <Btn bg={C.orange} style={{ width:"100%", padding:12 }} onClick={seed}>+ إنشاء/تحديث حوكمة افتراضية متقدمة</Btn>}
          </Section>
          <Section title="مصفوفة صلاحيات مختصرة">
            {[
              ["مدير", "إعدادات، حوكمة، حذف، اعتماد عالي، نسخ واستيراد"],
              ["مشرف", "أوامر العمل، مراجعة، أصول، برامج، جودة بيانات"],
              ["فني", "تنفيذ الأعمال، ساعات، قراءات، صور، إكمال عمليات"],
              ["مخزن", "استلام، صرف، إرجاع، تجهيز مواد، مخزون"],
              ["طالب خدمة", "رفع طلبات عمل ومتابعتها فقط"],
            ].map(([r, desc]) => <div key={r} style={card()}><Row main={r} sub={desc} /></div>)}
          </Section>
        </>
      )}
      {sub === "policies" && <Crud ctx={ctx} entity="governancePolicies" title="سياسات الحوكمة" schema={[
        { k:"code", label:"الكود" }, { k:"title", label:"العنوان" },
        { k:"type", label:"النوع", type:"select", options:GOV_POLICY_TYPES },
        { k:"scope", label:"النطاق" }, { k:"ownerRole", label:"المالك", type:"select", options:[...ROLES, "السلامة", "المدقق"] },
        { k:"status", label:"الحالة", type:"select", options:GOV_POLICY_STATUS }, { k:"version", label:"الإصدار" },
        { k:"effectiveDate", label:"تاريخ السريان", type:"date" }, { k:"reviewDate", label:"تاريخ المراجعة", type:"date" },
        { k:"controlObjective", label:"هدف الضابط", type:"textarea" }, { k:"evidenceRequired", label:"الدليل المطلوب", type:"textarea" },
      ]} validate={(d, form) => !String(d.code||"").trim() ? "الكود مطلوب" : db.governancePolicies.some((x) => x.code === d.code && x.id !== form?.id) ? "كود السياسة مستخدم" : null}
      render={(p) => [p.code + " — " + p.title, [p.type, p.ownerRole, p.status, p.reviewDate ? "مراجعة: " + fmt(p.reviewDate) : ""].filter(Boolean).join(" · ")]} badge={(p) => ({ text:p.status || "—", color:p.status === "سارية" ? C.green : p.status === "مؤرشفة" ? C.steel : C.amber })} />}
      {sub === "approvals" && <Crud ctx={ctx} entity="approvalMatrix" title="مصفوفة الاعتماد" schema={[
        { k:"process", label:"العملية", type:"select", options:GOV_PROCESSES }, { k:"action", label:"الإجراء", type:"select", options:GOV_ACTIONS },
        { k:"requesterRole", label:"الدور الطالب", type:"select", options:ROLES }, { k:"approverRole", label:"الدور المعتمد", type:"select", options:ROLES },
        { k:"minPriority", label:"أدنى أولوية" }, { k:"amountLimit", label:"حد مبلغ/تكلفة" },
        { k:"requiresSecondApproval", label:"يتطلب اعتمادًا ثانيًا", type:"check" }, { k:"active", label:"نشط", type:"check" },
        { k:"notes", label:"ملاحظات", type:"textarea" },
      ]} validate={(d) => !d.process || !d.action || !d.approverRole ? "العملية والإجراء والمعتمد مطلوبة" : null}
      render={(a) => [a.process + " — " + a.action, ["الطالب: " + (a.requesterRole || "—"), "المعتمد: " + (a.approverRole || "—"), a.requiresSecondApproval ? "اعتماد ثانٍ" : ""].filter(Boolean).join(" · ")]} badge={(a) => ({ text:a.active ? "نشط" : "معطل", color:a.active ? C.green : C.steel })} />}
      {sub === "requests" && (
        <>
          <Crud ctx={ctx} entity="governanceApprovalRequests" title="طلبات الاعتماد" schema={[
            { k:"number", label:"رقم الطلب" }, { k:"title", label:"العنوان" },
            { k:"area", label:"المجال", type:"select", options:GOV_PROCESSES },
            { k:"requesterRole", label:"الطالب", type:"select", options:ROLES }, { k:"approverRole", label:"المعتمد", type:"select", options:ROLES },
            { k:"status", label:"الحالة", type:"select", options:GOV_REQUEST_STATUS }, { k:"riskLevel", label:"المخاطر", type:"select", options:GOV_RISK_LEVELS },
            { k:"requestedAt", label:"تاريخ الطلب" }, { k:"justification", label:"المبرر", type:"textarea" },
            { k:"decisionBy", label:"قرار بواسطة" }, { k:"decisionAt", label:"وقت القرار" },
          ]} validate={(d, form) => !String(d.number||"").trim() ? "رقم الطلب مطلوب" : db.governanceApprovalRequests.some((x) => x.number === d.number && x.id !== form?.id) ? "رقم الطلب مستخدم" : null}
          render={(r) => [r.number + " — " + r.title, [r.area, "طالب: " + (r.requesterRole || "—"), "معتمد: " + (r.approverRole || "—"), r.justification].filter(Boolean).join(" · ")]} badge={(r) => ({ text:r.status || "مفتوح", color:r.status === "معتمد" || r.status === "منفذ" ? C.green : r.status === "مرفوض" ? C.red : C.amber })} />
          <Section title="قرارات سريعة">
            {(db.governanceApprovalRequests || []).filter((r) => r.status === "مفتوح").map((r) => <div key={r.id} style={card()}><Row main={r.number + " — " + r.title} sub={[r.area, r.riskLevel, r.justification].filter(Boolean).join(" · ")} /><div style={{ display:"flex", gap:8, marginTop:8 }}><Btn bg={C.green} onClick={() => decideRequest(r, "معتمد")}>اعتماد</Btn><Btn bg={C.red} onClick={() => decideRequest(r, "مرفوض")}>رفض</Btn></div></div>)}
            {openApprovalRequests.length === 0 && <Empty text="لا توجد طلبات اعتماد مفتوحة." />}
          </Section>
        </>
      )}
      {sub === "quality" && (
        <>
          <Section title="قواعد جودة البيانات">
            <Crud ctx={ctx} entity="governanceDataQualityRules" title="قواعد جودة البيانات" schema={[
              { k:"code", label:"الكود" }, { k:"title", label:"اسم القاعدة" }, { k:"entity", label:"الكيان" },
              { k:"severity", label:"الخطورة", type:"select", options:GOV_DATA_SEVERITY }, { k:"ownerRole", label:"المالك", type:"select", options:ROLES },
              { k:"active", label:"نشطة", type:"check" }, { k:"description", label:"الوصف", type:"textarea" },
            ]} render={(r) => [r.code + " — " + r.title, [r.entity, r.ownerRole, r.description].filter(Boolean).join(" · ")]} badge={(r) => ({ text:r.active ? r.severity : "معطلة", color:r.active ? (["عال", "حرج"].includes(r.severity) ? C.red : r.severity === "متوسط" ? C.amber : C.green) : C.steel })} />
          </Section>
          <Section title={"فحص آلي حالي — " + qualityFindings.length + " ملاحظة"}>
            {qualityFindings.map((q, i) => <div key={i} style={{ ...card(), borderRightColor:["عال", "حرج"].includes(q.severity) ? C.red : q.severity === "متوسط" ? C.amber : C.steel }}><Row main={q.issue} sub={[q.area, q.ref, "الإجراء: " + q.fix].filter(Boolean).join(" · ")} badge={{ text:q.severity, color:["عال", "حرج"].includes(q.severity) ? C.red : q.severity === "متوسط" ? C.amber : C.steel }} /></div>)}
            {qualityFindings.length === 0 && <Empty text="لا توجد ملاحظات جودة بيانات ضمن الفحص الأساسي." />}
          </Section>
        </>
      )}
      {sub === "risks" && <Crud ctx={ctx} entity="governanceRisks" title="سجل مخاطر الحوكمة" schema={[
        { k:"area", label:"المجال" }, { k:"risk", label:"وصف الخطر", type:"textarea" },
        { k:"level", label:"المستوى", type:"select", options:GOV_RISK_LEVELS }, { k:"owner", label:"المالك", type:"select", options:[...ROLES, "السلامة", "المدقق"] },
        { k:"mitigation", label:"خطة المعالجة", type:"textarea" }, { k:"status", label:"الحالة", type:"select", options:GOV_RISK_STATUS },
        { k:"dueDate", label:"تاريخ مستهدف", type:"date" },
      ]} validate={(d) => !d.area || !d.risk ? "المجال ووصف الخطر مطلوبان" : null}
      render={(r) => [r.area + " — " + r.risk, [r.owner, r.status, r.dueDate ? "استحقاق: " + fmt(r.dueDate) : ""].filter(Boolean).join(" · ")]} badge={(r) => ({ text:r.level || "—", color:r.level === "حرج" ? C.red : r.level === "عال" ? C.amber : r.level === "متوسط" ? C.blue : C.green })} />}
      {sub === "changes" && <Crud ctx={ctx} entity="governanceChangeRequests" title="طلبات التغيير" schema={[
        { k:"number", label:"رقم الطلب" }, { k:"title", label:"العنوان" },
        { k:"area", label:"المجال", type:"select", options:GOV_PROCESSES }, { k:"requestedBy", label:"الطالب", type:"select", options:ROLES },
        { k:"status", label:"الحالة", type:"select", options:GOV_CHANGE_STATUS }, { k:"riskLevel", label:"مستوى الخطر", type:"select", options:GOV_RISK_LEVELS },
        { k:"impact", label:"الأثر", type:"textarea" }, { k:"approver", label:"المعتمد", type:"select", options:ROLES },
        { k:"plannedDate", label:"تاريخ التنفيذ المخطط", type:"date" }, { k:"notes", label:"ملاحظات", type:"textarea" },
      ]} validate={(d, form) => !String(d.number||"").trim() ? "رقم الطلب مطلوب" : db.governanceChangeRequests.some((x) => x.number === d.number && x.id !== form?.id) ? "رقم الطلب مستخدم" : null}
      render={(c) => [c.number + " — " + c.title, [c.area, c.requestedBy, c.approver ? "اعتماد: " + c.approver : "", c.plannedDate ? fmt(c.plannedDate) : ""].filter(Boolean).join(" · ")]} badge={(c) => ({ text:c.status || "—", color:c.status === "معتمد" || c.status === "منفذ" || c.status === "مغلق" ? C.green : c.status === "مرفوض" ? C.red : C.amber })} />}
      {sub === "reviews" && <Crud ctx={ctx} entity="governanceReviews" title="المراجعات الدورية" schema={[
        { k:"name", label:"اسم المراجعة" }, { k:"frequency", label:"التكرار", type:"select", options:GOV_REVIEW_FREQ },
        { k:"owner", label:"المالك", type:"select", options:[...ROLES, "السلامة", "المدقق"] }, { k:"lastReview", label:"آخر مراجعة", type:"date" },
        { k:"nextReview", label:"المراجعة القادمة", type:"date" }, { k:"status", label:"الحالة", type:"select", options:["مفتوح", "مكتمل", "متأخر", "مغلق"] },
        { k:"notes", label:"ملاحظات", type:"textarea" },
      ]} validate={(d) => !d.name ? "اسم المراجعة مطلوب" : null}
      render={(r) => [r.name, [r.frequency, r.owner, r.nextReview ? "القادمة: " + fmt(r.nextReview) : ""].filter(Boolean).join(" · ")]} badge={(r) => ({ text:r.nextReview && daysUntil(r.nextReview) < 0 && r.status !== "مغلق" ? "متأخر" : (r.status || "—"), color:r.nextReview && daysUntil(r.nextReview) < 0 && r.status !== "مغلق" ? C.red : r.status === "مكتمل" || r.status === "مغلق" ? C.green : C.amber })} />}
      {sub === "audit" && (
        <Section title="سجل تدقيق الحوكمة">
          {can.manage && <div style={card()}>
            <Btn bg={C.blue} style={{ width:"100%", padding:12 }} onClick={() => addAudit("مراجعة يدوية للحكومة والضوابط")}>+ تسجيل مراجعة يدوية الآن</Btn>
          </div>}
          {(db.governanceAuditEvents || []).slice().reverse().map((e) => <div key={e.id} style={card()}><Row main={e.action} sub={[e.area, e.by, e.at].filter(Boolean).join(" · ")} /></div>)}
          {(db.governanceAuditEvents || []).length === 0 && <Empty text="لا توجد أحداث حوكمة بعد. استخدم زر إنشاء الحوكمة الافتراضية أو سجل مراجعة يدوية." />}
          <div style={{ ...card(), fontSize:13, color:C.steel }}>ملاحظة: أوامر العمل والأصول لديها سجلات تنفيذ وتغييرات منفصلة. هذه الشاشة تضيف طبقة تدقيق إدارية عامة.</div>
        </Section>
      )}
    </>
  );
}



/* ───────────────────────── حوكمة CMMS 100% ───────────────────────── */
function Governance100Hub({ ctx }) {
  const { db, save, can, role, firebaseEnabled, firebaseProfile, nameOf } = ctx;
  const [sub, setSub] = useState("dashboard");
  const [filter, setFilter] = useState("الكل");
  const tabs = [["dashboard","النضج"],["controls","الضوابط"],["tests","اختبار الضوابط"],["approvals","الاعتمادات"],["sod","SoD"],["raci","RACI"],["kpi","KPI/SLA"],["exceptions","الاستثناءات"],["capa","CAPA"],["readiness","الجاهزية"],["evidence","الأدلة"]];

  const roleLabel = role || "—";
  const openWos = (db.workOrders || []).filter((w)=>ACTIVE_STATES.includes(w.status));
  const closedWos = (db.workOrders || []).filter((w)=>w.status === "مغلق");
  const activePolicies = (db.governancePolicies || []).filter((p)=>p.status !== "ملغاة" && p.active !== false);
  const latestTests = (db.governanceControlTests || []).slice().reverse();
  const pass = latestTests.filter((t)=>t.result === "Pass" || t.result === "نجح" || t.result === "ناجح").length;
  const warn = latestTests.filter((t)=>t.result === "Warning" || t.result === "تحذير").length;
  const fail = latestTests.filter((t)=>t.result === "Fail" || t.result === "فشل").length;
  const testScore = latestTests.length ? Math.max(0, Math.round(((pass + warn * 0.5) / latestTests.length) * 100)) : 0;
  const foundationScore = Math.min(100, Math.round(
    (firebaseEnabled ? 15 : 0) +
    Math.min(15, (db.governanceControlLibrary || []).length * 0.75) +
    Math.min(10, (db.governanceSoDRules || []).length * 1.25) +
    Math.min(10, (db.governanceRaciMatrix || []).length * 0.8) +
    Math.min(10, (db.governanceKpiDefinitions || []).length) +
    ((db.governanceBackupPolicies || []).length ? 10 : 0) +
    ((db.governanceRetentionRules || []).length ? 5 : 0) +
    ((db.governanceAccessCertifications || []).length ? 5 : 0) +
    ((db.governanceReadinessChecklist || []).length ? 5 : 0) +
    ((db.governanceAuditEvents || []).length ? 5 : 0) +
    ((db.governanceReleaseGates || []).length ? 5 : 0) +
    (testScore ? 5 : 0)
  ));
  const maturity = Math.round((foundationScore * 0.45) + (testScore * 0.55));
  const maturityColor = maturity >= 90 ? C.green : maturity >= 70 ? C.amber : C.red;
  const readinessDone = (db.governanceReadinessChecklist || []).filter((x)=>x.status === "مكتمل" || x.status === "موافق").length;
  const readinessPct = (db.governanceReadinessChecklist || []).length ? Math.round(readinessDone / (db.governanceReadinessChecklist || []).length * 100) : 0;

  const addAudit = (action, area="حوكمة 100%", extra={}) => ({ id:uid(), at:now(), by:roleLabel, area, action, ...extra });
  const upsertMany = (rows, newRows, key="code") => {
    const existing = new Map((rows || []).map((r)=>[r[key], r]));
    const out = [...(rows || [])];
    newRows.forEach((nr)=>{ if (!existing.has(nr[key])) out.push(nr); });
    return out;
  };
  const defaultControls = () => ([
    ["CTRL-001","Firebase Auth مفعل ومستخدم","Access & RBAC","مسؤول النظام","مستمر","تلقائي","حرج","دليل تسجيل دخول وحالة Firestore"],
    ["CTRL-002","الأدوار مفروضة من Backend وليس من واجهة فقط","Access & RBAC","مسؤول النظام","شهري","شبه آلي","حرج","Firestore Rules + User Profiles"],
    ["CTRL-003","لا أمر عمل بدون أصل","Work Control","مشرف","يومي","تلقائي","حرج","فحص أوامر العمل"],
    ["CTRL-004","لا إصدار أمر عمل قبل فحص المواد","Inventory Control","مخزن","يومي","شبه آلي","عال","Material Availability Check"],
    ["CTRL-005","لا تنفيذ بدون قائمة سلامة عند الحاجة","Safety & Execution","مشرف","يومي","تلقائي","حرج","Safety Checklist Answers"],
    ["CTRL-006","لا إكمال فني قبل العمليات والمواد والعمالة","Safety & Execution","مشرف","يومي","تلقائي","حرج","Completion Gaps"],
    ["CTRL-007","لا إغلاق نهائي بدون موافقة مشرف","Approvals","مشرف","يومي","تلقائي","حرج","Supervisor Review"],
    ["CTRL-008","لا تكلفة مواد بدون حركة مخزون/استخدام","Financial Control","مخزن","أسبوعي","تلقائي","عال","Stock/Material Usage"],
    ["CTRL-009","لا تكلفة عمالة بدون Labor Transaction","Financial Control","مشرف","أسبوعي","تلقائي","عال","Labor Transactions"],
    ["CTRL-010","كل تغيير حالة له سجل تدقيق","Audit & Evidence","مسؤول النظام","يومي","تلقائي","حرج","Status History"],
    ["CTRL-011","الفني يرى وينفذ أعماله المسندة فقط","Segregation of Duties","مشرف","شهري","شبه آلي","حرج","Assignments + Rules"],
    ["CTRL-012","طالب الخدمة لا يحوّل أو يوافق على الطلبات","Segregation of Duties","مسؤول النظام","شهري","يدوي","عال","Role Matrix"],
    ["CTRL-013","المخزن يصرف ويرجع المواد ولا يغلق أوامر العمل","Segregation of Duties","مدير الصيانة","شهري","يدوي","عال","SoD Matrix"],
    ["CTRL-014","الصيانة الوقائية لها برنامج أو تعريف عمل","Forecast & Scheduling","مخطط الصيانة","أسبوعي","تلقائي","عال","PM Program/Work Definition"],
    ["CTRL-015","التوقعات مفحوصة قبل توليد أوامر PM","Forecast & Scheduling","مخطط الصيانة","أسبوعي","تلقائي","متوسط","Forecast Validation"],
    ["CTRL-016","الأصول الحرجة لها برنامج صيانة أو خطة فحص","Data Quality","مهندس موثوقية","شهري","شبه آلي","عال","Critical Assets Review"],
    ["CTRL-017","لا أرقام أصول مكررة أو فارغة","Data Quality","مالك بيانات الأصول","يومي","تلقائي","عال","Asset Registry Quality"],
    ["CTRL-018","التقارير المهمة لها مالك وجدولة","Reporting","مدير الصيانة","شهري","يدوي","متوسط","Report Schedules"],
    ["CTRL-019","نسخ احتياطي وخطة استعادة موثقة","Backup & Continuity","مسؤول النظام","شهري","يدوي","حرج","Backup Policy"],
    ["CTRL-020","سياسة احتفاظ وسجل قانوني للبيانات الحساسة","Retention","مسؤول النظام","سنوي","يدوي","عال","Retention Rules"],
    ["CTRL-021","مراجعة صلاحيات دورية","Access & RBAC","مسؤول النظام","شهري","يدوي","حرج","Access Certification"],
    ["CTRL-022","طلبات تغيير مؤثرة لها تقييم أثر واعتماد","Change Control","مدير الصيانة","عند الحاجة","يدوي","عال","Change Impact Assessment"],
    ["CTRL-023","كل فشل متكرر له CAPA أو RCA","Work Control","مهندس موثوقية","شهري","شبه آلي","عال","Failure Analysis/CAPA"],
    ["CTRL-024","قبل/بعد الصور إلزامية لأنواع العمل المحددة","Audit & Evidence","مشرف","يومي","تلقائي","متوسط","Photo Evidence"],
    ["CTRL-025","Go-Live Gate لا يغلق إلا بعد تحقق الضوابط الأساسية","Approvals","مدير","عند الإصدار","يدوي","حرج","Release Gate"],
  ]).map(([code,name,domain,ownerRole,frequency,automation,criticality,evidence])=>({ id:uid(), code, name, domain, ownerRole, frequency, automation, criticality, evidenceRequired:evidence, status:"نشط", lastTestedAt:"", lastResult:"لم يفحص" }));
  const seedGovernance100 = () => {
    if (!can?.admin && !can?.manage) return alert("هذه العملية للمدير أو المشرف فقط.");
    const controls = defaultControls();
    const sod = [
      ["SOD-001","منشئ أمر العمل لا يعتمد إغلاقه", "Create_WorkOrders", "Approve_WorkOrder_Completion", "حرج"],
      ["SOD-002","الفني لا يغلق أمر العمل نهائيًا", "Execute_WorkOrders", "Close_WorkOrders", "حرج"],
      ["SOD-003","طالب الخدمة لا يحوّل طلبه إلى أمر عمل", "Create_WorkRequests", "Convert_WorkRequest_To_WorkOrder", "عال"],
      ["SOD-004","المخزن لا يقرّر استخدام المواد الفعلي بدل الفني", "Material_Issue", "Record_Material_Usage", "عال"],
      ["SOD-005","من يعدّل أسعار المواد لا يعتمد التكلفة", "Manage_Items_Cost", "Approve_WorkOrder_Cost", "عال"],
      ["SOD-006","مراجع جودة البيانات لا يحذف السجلات محل الفحص", "Data_Quality_Review", "Delete_Master_Data", "متوسط"],
      ["SOD-007","من يغيّر الصلاحيات لا يعتمد مراجعته الخاصة", "Manage_Users", "Approve_Access_Review", "حرج"],
      ["SOD-008","من يرفع استثناء لا يوافق عليه", "Create_Exception", "Approve_Exception", "عال"],
    ].map(([code,name,permissionA,permissionB,risk])=>({ id:uid(), code, name, permissionA, permissionB, risk, status:"نشط", mitigation:"يتطلب اعتماد دور مستقل أو مدير أعلى" }));
    const raci = [
      ["إنشاء طلب عمل","طالب خدمة","مشرف","فني,مخزن","مدير"], ["تحويل طلب إلى أمر عمل","مشرف","مدير الصيانة","طالب خدمة,فني","مدير المصنع"],
      ["تخطيط أمر العمل","مشرف","مدير الصيانة","مخزن,فني","مدير المصنع"], ["إصدار أمر العمل","مشرف","مدير الصيانة","مخزن","مدير المصنع"],
      ["صرف المواد","مخزن","رئيس المخزن","فني,مشرف","مدير الصيانة"], ["تنفيذ العمل","فني","مشرف","مخزن","مدير الصيانة"],
      ["تسجيل العطل","فني","مشرف","مهندس موثوقية","مدير الصيانة"], ["اعتماد الإكمال","مشرف","مدير الصيانة","فني","مدير المصنع"],
      ["إغلاق أمر العمل","مدير الصيانة","مدير المصنع","مشرف","المالية/الإدارة"], ["تعديل الأصول","مالك بيانات الأصول","مدير الصيانة","مشرف","مدير المصنع"],
      ["مراجعة الصلاحيات","مسؤول النظام","مدير النظام","المديرون","الإدارة"], ["اعتماد الاستثناءات","مدير الصيانة","مدير المصنع","مسؤول النظام","الإدارة"],
    ].map(([process,responsible,accountable,consulted,informed])=>({ id:uid(), process, responsible, accountable, consulted, informed, status:"معتمد" }));
    const kpis = [
      ["KPI-001","PM Compliance","نسبة أوامر PM المغلقة في موعدها","%",">=90","شهري","مدير الصيانة"],
      ["KPI-002","Backlog by Criticality","الأوامر المفتوحة حسب الحرجية","WO","مراقبة","أسبوعي","مشرف"],
      ["KPI-003","Schedule Compliance","الالتزام بجدول اليوم","%",">=85","أسبوعي","مشرف"],
      ["KPI-004","MTTR","متوسط زمن الإصلاح","ساعة","تحسن مستمر","شهري","مهندس موثوقية"],
      ["KPI-005","MTBF","متوسط الزمن بين الأعطال","ساعة","تحسن مستمر","شهري","مهندس موثوقية"],
      ["KPI-006","Material Return Rate","نسبة المواد المصروفة غير المستخدمة","%","<=10","شهري","رئيس المخزن"],
      ["KPI-007","Data Quality Score","اكتمال بيانات الأصول وأوامر العمل","%",">=95","أسبوعي","مالك البيانات"],
      ["KPI-008","Supervisor Review Aging","عمر أوامر بانتظار المراجعة","يوم","<=2","يومي","مشرف"],
      ["KPI-009","Emergency Ratio","نسبة الأعمال الطارئة","%","اتجاه هابط","شهري","مدير الصيانة"],
      ["KPI-010","Governance Control Pass Rate","نسبة ضوابط الحوكمة الناجحة","%",">=95","شهري","مسؤول النظام"],
    ].map(([code,name,definition,uom,target,frequency,ownerRole])=>({ id:uid(), code, name, definition, uom, target, frequency, ownerRole, active:true }));
    const sla = [
      ["SLA-EMG","طارئ/حرج","15 دقيقة","4 ساعات","مدير الصيانة"], ["SLA-HIGH","عالية","2 ساعة","24 ساعة","مشرف"],
      ["SLA-NORMAL","عادية","1 يوم","5 أيام","مشرف"], ["SLA-LOW","منخفضة","3 أيام","15 يوم","مشرف"],
    ].map(([code,priority,responseTime,resolutionTarget,ownerRole])=>({ id:uid(), code, priority, responseTime, resolutionTarget, ownerRole, escalation:"تنبيه ثم تصعيد للمدير" }));
    const dataOwners = [
      ["الأصول","مالك بيانات الأصول","مشرف","رقم الأصل، الموقع، الحالة، الحرجية"], ["أوامر العمل","مشرف الصيانة","مدير الصيانة","الحالة، الفني، العمليات، الإغلاق"],
      ["المخزون","رئيس المخزن","مدير الصيانة","الأرصدة، الصرف، الإرجاع، التكلفة"], ["العدادات","مهندس موثوقية","مشرف","القراءات، المعايرة، تعطيل القراءة"],
      ["الضمانات","منسق الضمان","مدير الصيانة","العقود، المطالبات، الاستحقاقات"], ["الصلاحيات","مسؤول النظام","مدير المصنع","الأدوار، المراجعات، الإقرارات"],
    ].map(([domain,ownerRole,stewardRole,keyFields])=>({ id:uid(), domain, ownerRole, stewardRole, keyFields, reviewFrequency:"شهري" }));
    const authority = [
      ["AUTH-001","إغلاق أمر عمل عادي","0","مشرف","لا"], ["AUTH-002","إغلاق أمر عمل حرج أو طارئ","0","مدير الصيانة","نعم"],
      ["AUTH-003","تسوية مخزون","500","رئيس المخزن","نعم"], ["AUTH-004","مطالبة ضمان","0","مدير الصيانة","نعم"],
      ["AUTH-005","حذف أصل","0","مسؤول النظام","نعم"], ["AUTH-006","تغيير صلاحيات","0","مسؤول النظام","نعم"],
    ].map(([code,action,amountLimit,approverRole,eSignatureRequired])=>({ id:uid(), code, action, amountLimit, approverRole, eSignatureRequired, status:"نشط" }));
    const backup = [
      { id:uid(), code:"BKP-001", name:"تصدير يومي للبيانات الحرجة", scope:"Firestore + إعدادات Firebase + قواعد Firestore", frequency:"يومي", ownerRole:"مسؤول النظام", retention:"30 يوم", restoreTestFrequency:"شهري", status:"نشط" },
      { id:uid(), code:"BKP-002", name:"نسخة قبل أي تحديث APK أو قواعد", scope:"ZIP + APK + rules", frequency:"عند التغيير", ownerRole:"مسؤول النظام", retention:"12 شهر", restoreTestFrequency:"ربع سنوي", status:"نشط" },
    ];
    const retention = [
      ["RET-001","Work Orders / Execution History","7 سنوات","قفل بعد الإغلاق إلا باستثناء معتمد"], ["RET-002","Audit & Approvals","10 سنوات","غير قابل للحذف من المستخدمين"],
      ["RET-003","Photos & Attachments","3 سنوات","يحفظ الرابط والدليل لا الصورة الضخمة"], ["RET-004","Warranty Claims","10 سنوات","حسب سياسة المورد"],
      ["RET-005","User Access Reviews","5 سنوات","يدقق شهريًا"],
    ].map(([code,recordType,retentionPeriod,rule])=>({ id:uid(), code, recordType, retentionPeriod, rule, legalHold:false, status:"نشط" }));
    const readiness = [
      ["RDY-001","Firebase Auth مفعل والمستخدمون بأدوار صحيحة","مسؤول النظام","حرج"], ["RDY-002","Firestore Rules منشورة لأحدث نسخة","مسؤول النظام","حرج"],
      ["RDY-003","Backup/Restore مختبر","مسؤول النظام","حرج"], ["RDY-004","سجل الأصول مستورد ومراجع","مالك بيانات الأصول","عال"],
      ["RDY-005","الفنيون ومراكز العمل والموارد مكتملة","مشرف","عال"], ["RDY-006","برامج PM وتوقعاتها مفحوصة","مخطط الصيانة","عال"],
      ["RDY-007","المخزون والحدود الدنيا وحركات الصرف جاهزة","مخزن","عال"], ["RDY-008","التقارير الحرجة مجربة","مدير الصيانة","متوسط"],
      ["RDY-009","مراجعة صلاحيات أولية مكتملة","مسؤول النظام","حرج"], ["RDY-010","تدريب المستخدمين وتوثيق الإجراءات مكتمل","مدير الصيانة","متوسط"],
    ].map(([code,item,ownerRole,criticality])=>({ id:uid(), code, item, ownerRole, criticality, status:"غير مكتمل", evidence:"", dueDate:today() }));
    const gates = [
      ["GATE-001","Go-Live Technical Gate","Firebase + APK + Backup + Rules","مسؤول النظام"], ["GATE-002","Operations Gate","Assets + WO + PM + Supervision","مدير الصيانة"],
      ["GATE-003","Security Gate","Roles + SoD + Access Review","مسؤول النظام"], ["GATE-004","Data Gate","Asset/Inventory/Meter data quality","مالك البيانات"],
      ["GATE-005","Management Approval Gate","Final production approval","مدير المصنع"],
    ].map(([code,name,criteria,ownerRole])=>({ id:uid(), code, name, criteria, ownerRole, required:true, status:"مفتوح", approvedBy:"", approvedAt:"" }));
    save({
      ...db,
      governanceFrameworks: upsertMany(db.governanceFrameworks, [{ id:uid(), code:"GOV-FWK-100", name:"CMMS Governance Operating Model 100%", version:"1.0", ownerRole:"مدير", scope:"Maintenance, Assets, Inventory, Work Execution, Firebase, Reports", status:"نشط", approvedAt:now() }]),
      governanceControlLibrary: upsertMany(db.governanceControlLibrary, controls),
      governanceSoDRules: upsertMany(db.governanceSoDRules, sod),
      governanceRaciMatrix: upsertMany(db.governanceRaciMatrix, raci, "process"),
      governanceKpiDefinitions: upsertMany(db.governanceKpiDefinitions, kpis),
      governanceSlaRules: upsertMany(db.governanceSlaRules, sla),
      governanceDataOwners: upsertMany(db.governanceDataOwners, dataOwners, "domain"),
      governanceAuthorityLimits: upsertMany(db.governanceAuthorityLimits, authority),
      governanceBackupPolicies: upsertMany(db.governanceBackupPolicies, backup),
      governanceRetentionRules: upsertMany(db.governanceRetentionRules, retention),
      governanceReadinessChecklist: upsertMany(db.governanceReadinessChecklist, readiness),
      governanceReleaseGates: upsertMany(db.governanceReleaseGates, gates),
      governanceAccessCertifications: [...(db.governanceAccessCertifications||[]), { id:uid(), period:today().slice(0,7), ownerRole:"مسؤول النظام", status:"مفتوح", reviewedUsers:0, findings:0, dueDate:today(), notes:"مراجعة أولية لصلاحيات Firebase قبل التشغيل." }],
      governanceSecurityReviews: [...(db.governanceSecurityReviews||[]), { id:uid(), at:now(), reviewerRole:"مسؤول النظام", area:"Firestore Rules", status: firebaseEnabled ? "مقبول" : "إعداد مطلوب", findings: firebaseEnabled ? 0 : 1, notes: firebaseEnabled ? "Firebase مفعّل داخل التطبيق." : "يجب تفعيل Firebase قبل الإنتاج." }],
      governancePolicyAcknowledgements: [...(db.governancePolicyAcknowledgements||[]), { id:uid(), policy:"CMMS Governance Operating Model", role:roleLabel, userEmail:firebaseProfile?.email || "", acknowledgedAt:now(), status:"مقر" }],
      governanceAuditEvents: [...(db.governanceAuditEvents||[]), addAudit("إنشاء حوكمة CMMS 100% — ضوابط/RACI/SoD/KPI/Readiness")]
    });
  };
  const buildControlTests = () => {
    const assetNums = (db.assets||[]).map((a)=>String(a.number||"").trim()).filter(Boolean);
    const dupAssets = assetNums.filter((n,i)=>assetNums.indexOf(n)!==i);
    const woWithoutAsset = (db.workOrders||[]).filter((w)=>!w.assetId || !db.assets.some((a)=>a.id===w.assetId));
    const activeWithoutTech = openWos.filter((w)=>!(w.assigneeId || (w.operations||[]).some((o)=>o.assigneeId) || (db.workOrderAssignments||[]).some((a)=>a.workOrderId===w.id)));
    const closedWithoutReview = closedWos.filter((w)=>!(db.workOrderSupervisorReviews||[]).some((r)=>r.workOrderId===w.id && (r.decision==="Approve" || r.status==="معتمد" || r.decision==="اعتماد")) && !(db.workOrderApprovals||[]).some((a)=>a.workOrderId===w.id));
    const missingStatusHistory = (db.workOrders||[]).filter((w)=>w.status !== "مسودة" && !(db.workOrderStatusHistory||[]).some((h)=>h.workOrderId===w.id));
    const closedCorrectiveNoFailure = closedWos.filter((w)=>(w.type==="تصحيحي" || w.type==="طارئ") && !w.failure && !(db.workOrderFailures||[]).some((f)=>f.workOrderId===w.id) && !(db.workOrderFailureRecords||[]).some((f)=>f.workOrderId===w.id));
    const pmMissingProgram = (db.workOrders||[]).filter((w)=>w.type==="وقائي" && !w.programId && !w.workDefId);
    const criticalAssetsNoPm = (db.assets||[]).filter((a)=>a.critical && a.active !== false && !(db.programs||[]).some((p)=>p.assetId===a.id || (p.groupId && (db.assetGroups||[]).some((g)=>g.id===p.groupId && (g.assignments||[]).some((x)=>x.assetId===a.id && !x.end)))));
    const materialCostNoUsage = (db.workOrderCosts||[]).filter((c)=>Number(c.materialCost||c.material||0)>0 && !(db.workOrderMaterialUsage||[]).some((m)=>m.workOrderId===c.workOrderId) && !(db.stockTx||[]).some((t)=>t.workOrderId===c.workOrderId));
    const laborCostNoTx = (db.workOrderCosts||[]).filter((c)=>Number(c.laborCost||c.labor||0)>0 && !(db.workOrderLaborTransactions||[]).some((l)=>l.workOrderId===c.workOrderId) && !(db.laborCostTransactions||[]).some((l)=>l.workOrderId===c.workOrderId));
    const safetyWithoutChecklist = openWos.filter((w)=>w.safetyRequired && !(w.checklist||[]).length && !(db.workOrderSafetyChecklists||[]).some((c)=>c.workOrderId===w.id));
    const pendingReviewAging = (db.workOrders||[]).filter((w)=>w.status==="بانتظار المراجعة" && w.plannedEnd && daysUntil(w.plannedEnd)<-2);
    const reportOwnersMissing = (db.governanceKpiDefinitions||[]).filter((k)=>!k.ownerRole);
    const overdueCaps = (db.governanceCapaActions||[]).filter((c)=>c.dueDate && daysUntil(c.dueDate)<0 && c.status!=="مغلق" && c.status!=="مكتمل");
    const test = (controlCode, name, condition, issueCount, severity="متوسط", evidence="") => ({ id:uid(), runId:"RUN-"+Date.now(), controlCode, name, testedAt:now(), testedBy:roleLabel, result: condition ? "Pass" : (severity === "منخفض" ? "Warning" : "Fail"), issueCount:Number(issueCount||0), severity, status: condition ? "مغلق" : "مفتوح", evidence, recommendation: condition ? "لا إجراء" : "افتح CAPA أو أصلح البيانات ثم أعد الفحص" });
    return [
      test("CTRL-001", "Firebase Auth مفعل", !!firebaseEnabled, firebaseEnabled?0:1, "حرج", firebaseEnabled ? "firebaseEnabled=true" : "Firebase غير مفعل"),
      test("CTRL-002", "الدور الحالي من Firebase Profile", !firebaseEnabled || !!firebaseProfile?.role, (!firebaseEnabled || firebaseProfile?.role)?0:1, "حرج", roleLabel),
      test("CTRL-003", "لا أمر عمل بدون أصل", woWithoutAsset.length===0, woWithoutAsset.length, "حرج", woWithoutAsset.map((w)=>w.number).join(", ")),
      test("CTRL-004", "لا أمر نشط بدون فني/تعيين", activeWithoutTech.length===0, activeWithoutTech.length, "عال", activeWithoutTech.map((w)=>w.number).join(", ")),
      test("CTRL-005", "قوائم السلامة موجودة عند الحاجة", safetyWithoutChecklist.length===0, safetyWithoutChecklist.length, "حرج", safetyWithoutChecklist.map((w)=>w.number).join(", ")),
      test("CTRL-006", "الإغلاق النهائي له مراجعة مشرف", closedWithoutReview.length===0, closedWithoutReview.length, "حرج", closedWithoutReview.map((w)=>w.number).join(", ")),
      test("CTRL-007", "كل تغيير حالة له Audit", missingStatusHistory.length===0, missingStatusHistory.length, "حرج", missingStatusHistory.map((w)=>w.number).join(", ")),
      test("CTRL-008", "أوامر التصحيح/الطوارئ المغلقة لها Failure", closedCorrectiveNoFailure.length===0, closedCorrectiveNoFailure.length, "عال", closedCorrectiveNoFailure.map((w)=>w.number).join(", ")),
      test("CTRL-009", "PM WO مربوط ببرنامج أو تعريف عمل", pmMissingProgram.length===0, pmMissingProgram.length, "عال", pmMissingProgram.map((w)=>w.number).join(", ")),
      test("CTRL-010", "الأصول الحرجة لها PM", criticalAssetsNoPm.length===0, criticalAssetsNoPm.length, "عال", criticalAssetsNoPm.map((a)=>a.number||a.name).join(", ")),
      test("CTRL-011", "لا تكرار أرقام أصول", dupAssets.length===0, dupAssets.length, "عال", [...new Set(dupAssets)].join(", ")),
      test("CTRL-012", "تكلفة المواد لها حركة", materialCostNoUsage.length===0, materialCostNoUsage.length, "عال", materialCostNoUsage.map((c)=>c.workOrderId).join(", ")),
      test("CTRL-013", "تكلفة العمالة لها معاملة", laborCostNoTx.length===0, laborCostNoTx.length, "عال", laborCostNoTx.map((c)=>c.workOrderId).join(", ")),
      test("CTRL-014", "مراجعات المشرف لا تتراكم", pendingReviewAging.length===0, pendingReviewAging.length, "متوسط", pendingReviewAging.map((w)=>w.number).join(", ")),
      test("CTRL-015", "SoD Matrix مهيأة", (db.governanceSoDRules||[]).length>=8, Math.max(0, 8-(db.governanceSoDRules||[]).length), "حرج", (db.governanceSoDRules||[]).length+" قواعد"),
      test("CTRL-016", "RACI Matrix مهيأة", (db.governanceRaciMatrix||[]).length>=10, Math.max(0, 10-(db.governanceRaciMatrix||[]).length), "متوسط", (db.governanceRaciMatrix||[]).length+" صف"),
      test("CTRL-017", "Backup Policy موجودة", (db.governanceBackupPolicies||[]).length>0, (db.governanceBackupPolicies||[]).length?0:1, "حرج", (db.governanceBackupPolicies||[]).map((b)=>b.name).join("; ")),
      test("CTRL-018", "Retention Rules موجودة", (db.governanceRetentionRules||[]).length>0, (db.governanceRetentionRules||[]).length?0:1, "عال", (db.governanceRetentionRules||[]).map((r)=>r.recordType).join("; ")),
      test("CTRL-019", "Access Certification موجودة", (db.governanceAccessCertifications||[]).length>0, (db.governanceAccessCertifications||[]).length?0:1, "حرج", (db.governanceAccessCertifications||[]).map((r)=>r.period+":"+r.status).join("; ")),
      test("CTRL-020", "KPI Owners مكتملة", reportOwnersMissing.length===0 && (db.governanceKpiDefinitions||[]).length>=8, reportOwnersMissing.length, "متوسط", reportOwnersMissing.map((k)=>k.name).join(", ")),
      test("CTRL-021", "Release Gates مهيأة", (db.governanceReleaseGates||[]).length>=5, Math.max(0, 5-(db.governanceReleaseGates||[]).length), "حرج", (db.governanceReleaseGates||[]).map((g)=>g.code+":"+g.status).join("; ")),
      test("CTRL-022", "Readiness Checklist موجودة", (db.governanceReadinessChecklist||[]).length>=10, Math.max(0, 10-(db.governanceReadinessChecklist||[]).length), "حرج", readinessPct+"%"),
      test("CTRL-023", "سياسات الحوكمة فعالة", activePolicies.length>=5, Math.max(0, 5-activePolicies.length), "متوسط", activePolicies.map((p)=>p.name).join("; ")),
      test("CTRL-024", "سجل التدقيق غير فارغ", (db.governanceAuditEvents||[]).length>0, (db.governanceAuditEvents||[]).length?0:1, "متوسط", (db.governanceAuditEvents||[]).length+" حدث"),
      test("CTRL-025", "لا CAPA مفتوحة متأخرة", overdueCaps.length===0, overdueCaps.length, "عال", "CAPA Overdue")
    ];
  };
  const runControls = () => {
    if (!can?.review && !can?.admin) return alert("اختبار الضوابط للمشرف أو المدير فقط.");
    const tests = buildControlTests();
    const failures = tests.filter((t)=>t.result === "Fail");
    const cap = failures.slice(0, 10).map((t)=>({ id:uid(), sourceControl:t.controlCode, title:"CAPA — " + t.name, rootCause:"يحدد بعد التحقيق", action:"تصحيح: " + t.recommendation, ownerRole:t.severity==="حرج"?"مدير":"مشرف", priority:t.severity, dueDate:today(), status:"مفتوح", createdAt:now() }));
    const updatedControls = (db.governanceControlLibrary || []).map((c)=>{ const t = tests.find((x)=>x.controlCode===c.code); return t ? { ...c, lastTestedAt:t.testedAt, lastResult:t.result } : c; });
    save({ ...db, governanceControlTests:[...(db.governanceControlTests||[]), ...tests], governanceControlLibrary:updatedControls, governanceCapaActions:[...(db.governanceCapaActions||[]), ...cap], governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("تشغيل اختبار ضوابط حوكمة 100%", "Controls", { pass:tests.filter((t)=>t.result==="Pass").length, fail:failures.length })] });
  };
  const closeGate = (gate) => {
    if (!can?.admin && !can?.review) return;
    save({ ...db, governanceReleaseGates:(db.governanceReleaseGates||[]).map((g)=>g.id===gate.id?{...g,status:"معتمد",approvedBy:roleLabel,approvedAt:now()}:g), governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("اعتماد بوابة إصدار: "+gate.name, "Release Gates")] });
  };
  const closeCapa = (capa) => save({ ...db, governanceCapaActions:(db.governanceCapaActions||[]).map((c)=>c.id===capa.id?{...c,status:"مكتمل",closedAt:now(),closedBy:roleLabel}:c), governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("إغلاق CAPA: "+capa.title, "CAPA")] });
  const approveException = (ex, decision) => save({ ...db, governanceExceptionRegister:(db.governanceExceptionRegister||[]).map((e)=>e.id===ex.id?{...e,status:decision,approvedBy:roleLabel,approvedAt:now()}:e), governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit(decision+" استثناء: "+ex.title, "Exceptions")] });
  const createException = () => {
    const title = prompt("عنوان الاستثناء") || "استثناء تشغيلي";
    const risk = prompt("سبب/مخاطر الاستثناء") || "يحدد لاحقًا";
    save({ ...db, governanceExceptionRegister:[...(db.governanceExceptionRegister||[]), { id:uid(), number:"EXC-"+String(1000+(db.governanceExceptionRegister||[]).length+1), title, risk, compensatingControl:"مراجعة مشرف + CAPA", ownerRole:roleLabel, status:"مفتوح", requestedAt:now(), expiresOn:"" }], governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("إنشاء استثناء حوكمة", "Exceptions")] });
  };
  const markReady = (item) => save({ ...db, governanceReadinessChecklist:(db.governanceReadinessChecklist||[]).map((x)=>x.id===item.id?{...x,status:x.status==="مكتمل"?"غير مكتمل":"مكتمل", evidence:x.evidence||"تم التحقق بواسطة "+roleLabel+" في "+now()}:x), governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("تحديث جاهزية: "+item.item, "Readiness")] });
  const exportEvidence = () => {
    const data = { generatedAt:now(), maturity, foundationScore, testScore, controls:db.governanceControlLibrary||[], tests:latestTests.slice(0,200), caps:db.governanceCapaActions||[], exceptions:db.governanceExceptionRegister||[], readiness:db.governanceReadinessChecklist||[], releaseGates:db.governanceReleaseGates||[] };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type:"application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "cmms-governance-evidence-"+today()+".json"; a.click();
  };
  const resultColor = (r) => r === "Pass" || r === "نجح" || r === "ناجح" ? C.green : r === "Warning" || r === "تحذير" ? C.amber : C.red;
  const filteredTests = filter === "الكل" ? latestTests : latestTests.filter((t)=>t.result===filter || t.severity===filter);

  return <>
    <div style={{ display:"flex", gap:8, overflowX:"auto", marginBottom:12 }}>{tabs.map(([id,label])=><Chip key={id} active={sub===id} onClick={()=>setSub(id)}>{label}</Chip>)}</div>
    {sub === "dashboard" && <>
      <Section title="Governance 100% Dashboard">
        <div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={maturity+"%"} label="نضج الحوكمة" color={maturityColor}/><Stat n={(db.governanceControlLibrary||[]).length} label="ضوابط" color={C.blue}/><Stat n={fail} label="فشل" color={fail?C.red:C.green}/><Stat n={readinessPct+"%"} label="الجاهزية" color={readinessPct>=90?C.green:C.amber}/></div>
        <div style={{...card(), borderRightColor:maturityColor, lineHeight:1.8, fontSize:13}}>
          <b>الهدف:</b> الوصول إلى حوكمة إنتاجية لا تعتمد على الواجهة فقط، بل على أدوار، ضوابط، أدلة، مراجعات، CAPA، SoD، RACI، نسخ احتياطي، وجاهزية تشغيل. النسبة ليست وعدًا قانونيًا بـ 100%، لكنها تقيس اكتمال عناصر الحوكمة داخل التطبيق.
        </div>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}>
          {can?.manage && <Btn bg={C.green} onClick={seedGovernance100}>+ إنشاء/تحديث حوكمة CMMS 100%</Btn>}
          {can?.review && <Btn bg={C.blue} onClick={runControls}>تشغيل اختبار الضوابط الآن</Btn>}
          <Btn bg={C.ink} onClick={exportEvidence}>تصدير ملف الأدلة JSON</Btn>
          <Btn bg={C.orange} onClick={()=>setSub("readiness")}>فتح جاهزية الإنتاج</Btn>
        </div>
      </Section>
      <Section title="Domains Coverage">
        {GOVERNANCE100_DOMAINS.map((d)=>{ const count=(db.governanceControlLibrary||[]).filter((c)=>c.domain===d).length; return <div key={d} style={card()}><Row main={d} sub={count+" ضابط"} badge={{text:count?"مغطى":"ناقص", color:count?C.green:C.amber}} /></div>; })}
      </Section>
    </>}
    {sub === "controls" && <>
      <Section title="Control Library"><div style={{...card(), fontSize:13, color:C.steel}}>كل ضابط له مالك، دورية، دليل مطلوب، ونتيجة آخر اختبار. استخدم زر اختبار الضوابط لإنشاء Evidence وCAPA تلقائيًا.</div>{(db.governanceControlLibrary||[]).map((c)=><div key={c.id} style={{...card(), borderRightColor:resultColor(c.lastResult)}}><Row main={c.code+" — "+c.name} sub={[c.domain,c.ownerRole,c.frequency,c.automation,"Evidence: "+(c.evidenceRequired||"—")].filter(Boolean).join(" · ")} badge={{text:c.lastResult||c.status||"نشط", color:resultColor(c.lastResult)}} /></div>)}{!(db.governanceControlLibrary||[]).length && <Empty text="اضغط إنشاء حوكمة CMMS 100% لإضافة مكتبة الضوابط." />}</Section>
      <Crud ctx={ctx} entity="governanceControlLibrary" title="ضابط حوكمة" schema={[{k:"code",label:"Code"},{k:"name",label:"Name"},{k:"domain",label:"Domain",type:"select",options:GOVERNANCE100_DOMAINS},{k:"ownerRole",label:"Owner Role",type:"select",options:ROLES},{k:"frequency",label:"Frequency"},{k:"automation",label:"Automation",type:"select",options:["تلقائي","شبه آلي","يدوي"]},{k:"criticality",label:"Criticality",type:"select",options:["حرج","عال","متوسط","منخفض"]},{k:"evidenceRequired",label:"Evidence",type:"textarea"},{k:"status",label:"Status",type:"select",options:["نشط","معلق","متقاعد"]}]} render={(r)=>[r.code+" — "+r.name, [r.domain,r.ownerRole,r.frequency].join(" · ")]} badge={(r)=>({text:r.status||"نشط", color:r.status==="نشط"?C.green:C.steel})}/>
    </>}
    {sub === "tests" && <Section title="Control Test Results"><div style={{display:"flex", gap:6, overflowX:"auto", marginBottom:8}}>{["الكل","Pass","Fail","Warning","حرج","عال","متوسط"].map((x)=><Chip key={x} active={filter===x} onClick={()=>setFilter(x)}>{x}</Chip>)}</div>{filteredTests.map((t)=><div key={t.id} style={{...card(), borderRightColor:resultColor(t.result)}}><Row main={(t.controlCode||"")+" — "+t.name} sub={[t.testedAt,"Issues: "+t.issueCount,t.evidence,t.recommendation].filter(Boolean).join(" · ")} badge={{text:t.result, color:resultColor(t.result)}} /></div>)}{!filteredTests.length && <Empty text="لا نتائج اختبار بعد. شغّل اختبار الضوابط." />}</Section>}
    {sub === "approvals" && <>
      <Section title="Authority Limits / Approval Matrix">{(db.governanceAuthorityLimits||[]).map((a)=><div key={a.id} style={card()}><Row main={a.code+" — "+a.action} sub={["Approver: "+a.approverRole,"Limit: "+a.amountLimit,"E-Sign: "+a.eSignatureRequired].join(" · ")} badge={{text:a.status||"نشط", color:C.green}} /></div>)}{!(db.governanceAuthorityLimits||[]).length && <Empty text="أنشئ حوكمة 100% لإضافة حدود الاعتماد."/>}</Section>
      <Section title="Release Gates">{(db.governanceReleaseGates||[]).map((g)=><div key={g.id} style={{...card(), borderRightColor:g.status==="معتمد"?C.green:C.amber}}><Row main={g.code+" — "+g.name} sub={[g.criteria,"Owner: "+g.ownerRole,g.approvedAt].filter(Boolean).join(" · ")} badge={{text:g.status, color:g.status==="معتمد"?C.green:C.amber}} action={can?.review && g.status!=="معتمد"?<Btn bg={C.green} onClick={()=>closeGate(g)}>اعتماد</Btn>:null}/></div>)}</Section>
      <Crud ctx={ctx} entity="governanceERecords" title="E-Record / E-Sign Evidence" schema={[{k:"recordType",label:"Record Type"},{k:"recordId",label:"Record ID"},{k:"action",label:"Action"},{k:"signedByRole",label:"Signed By Role",type:"select",options:ROLES},{k:"signedAt",label:"Signed At"},{k:"meaning",label:"Meaning",type:"textarea"}]} render={(r)=>[r.recordType+" — "+r.action, [r.recordId,r.signedByRole,r.signedAt].filter(Boolean).join(" · ")]} />
    </>}
    {sub === "sod" && <Section title="Segregation of Duties Matrix">{(db.governanceSoDRules||[]).map((r)=><div key={r.id} style={{...card(), borderRightColor:r.risk==="حرج"?C.red:C.amber}}><Row main={r.code+" — "+r.name} sub={[r.permissionA,"vs",r.permissionB,r.mitigation].filter(Boolean).join(" · ")} badge={{text:r.risk, color:r.risk==="حرج"?C.red:C.amber}} /></div>)}{!(db.governanceSoDRules||[]).length && <Empty text="لا توجد قواعد SoD بعد." />}</Section>}
    {sub === "raci" && <><Section title="RACI Operating Model">{(db.governanceRaciMatrix||[]).map((r)=><div key={r.id} style={card()}><Row main={r.process} sub={["R: "+r.responsible,"A: "+r.accountable,"C: "+r.consulted,"I: "+r.informed].join(" · ")} badge={{text:r.status||"معتمد", color:C.green}} /></div>)}</Section><Section title="Data Owners">{(db.governanceDataOwners||[]).map((d)=><div key={d.id} style={card()}><Row main={d.domain} sub={["Owner: "+d.ownerRole,"Steward: "+d.stewardRole,"Fields: "+d.keyFields].join(" · ")} /></div>)}</Section></>}
    {sub === "kpi" && <><Section title="KPI Definitions">{(db.governanceKpiDefinitions||[]).map((k)=><div key={k.id} style={card()}><Row main={k.code+" — "+k.name} sub={[k.definition,"Target: "+k.target,"Owner: "+k.ownerRole,k.frequency].join(" · ")} badge={{text:k.uom||"KPI", color:C.blue}} /></div>)}</Section><Section title="SLA / Escalation Rules">{(db.governanceSlaRules||[]).map((s)=><div key={s.id} style={card()}><Row main={s.code+" — "+s.priority} sub={["Response: "+s.responseTime,"Resolution: "+s.resolutionTarget,"Owner: "+s.ownerRole,s.escalation].join(" · ")} /></div>)}</Section></>}
    {sub === "exceptions" && <Section title="Exception Register">{can?.manage && <Btn bg={C.orange} onClick={createException} style={{width:"100%",padding:12,marginBottom:8}}>+ طلب استثناء</Btn>}{(db.governanceExceptionRegister||[]).map((e)=><div key={e.id} style={{...card(), borderRightColor:e.status==="معتمد"?C.green:e.status==="مرفوض"?C.red:C.amber}}><Row main={(e.number||"")+" — "+e.title} sub={[e.risk,e.compensatingControl,"Owner: "+e.ownerRole,e.requestedAt].filter(Boolean).join(" · ")} badge={{text:e.status, color:e.status==="معتمد"?C.green:e.status==="مرفوض"?C.red:C.amber}} action={can?.review && e.status==="مفتوح"?<div style={{display:"flex",gap:4}}><Btn bg={C.green} onClick={()=>approveException(e,"معتمد")}>اعتماد</Btn><Btn bg={C.red} onClick={()=>approveException(e,"مرفوض")}>رفض</Btn></div>:null}/></div>)}{!(db.governanceExceptionRegister||[]).length && <Empty text="لا توجد استثناءات مفتوحة."/>}</Section>}
    {sub === "capa" && <><Section title="CAPA / Corrective Actions"><div style={{...card(), fontSize:13, color:C.steel}}>تُنشأ CAPA تلقائيًا عند فشل الضوابط. أغلقها بعد معالجة السبب الجذري وإعادة الفحص.</div>{(db.governanceCapaActions||[]).map((c)=><div key={c.id} style={{...card(), borderRightColor:c.status==="مكتمل"?C.green:C.red}}><Row main={c.title} sub={["Control: "+c.sourceControl,"Root Cause: "+c.rootCause,"Action: "+c.action,"Due: "+c.dueDate].filter(Boolean).join(" · ")} badge={{text:c.status, color:c.status==="مكتمل"?C.green:C.red}} action={c.status!=="مكتمل"&&can?.review?<Btn bg={C.green} onClick={()=>closeCapa(c)}>إغلاق</Btn>:null}/></div>)}{!(db.governanceCapaActions||[]).length && <Empty text="لا توجد CAPA بعد."/>}</Section><Crud ctx={ctx} entity="governanceIncidentReviews" title="Incident / RCA Review" schema={[{k:"number",label:"Number"},{k:"title",label:"Title"},{k:"assetId",label:"Asset",type:"select",from:"assets",fromKey:"name"},{k:"failureMode",label:"Failure Mode"},{k:"rootCause",label:"Root Cause",type:"textarea"},{k:"correctiveAction",label:"Corrective Action",type:"textarea"},{k:"ownerRole",label:"Owner Role",type:"select",options:ROLES},{k:"status",label:"Status",type:"select",options:["مفتوح","قيد التنفيذ","مكتمل"]}]} render={(r)=>[r.number+" — "+r.title, [nameOf("assets",r.assetId),r.failureMode,r.status].filter(Boolean).join(" · ")]} /></>}
    {sub === "readiness" && <><Section title="Production Readiness Checklist"><div style={{display:"flex",gap:8, marginBottom:8}}><Stat n={readinessPct+"%"} label="جاهزية" color={readinessPct>=90?C.green:C.amber}/><Stat n={(db.governanceReadinessChecklist||[]).length-readinessDone} label="متبقي" color={readinessDone===(db.governanceReadinessChecklist||[]).length?C.green:C.red}/><Stat n={(db.governanceReleaseGates||[]).filter((g)=>g.status==="معتمد").length+"/"+(db.governanceReleaseGates||[]).length} label="Gates" color={C.blue}/></div>{(db.governanceReadinessChecklist||[]).map((x)=><div key={x.id} style={{...card(), borderRightColor:x.status==="مكتمل"?C.green:C.amber}} onClick={()=>can?.review&&markReady(x)}><Row main={x.code+" — "+x.item} sub={["Owner: "+x.ownerRole,"Criticality: "+x.criticality,x.evidence].filter(Boolean).join(" · ")} badge={{text:x.status, color:x.status==="مكتمل"?C.green:C.amber}} /></div>)}</Section><Section title="Backup & Retention">{[...(db.governanceBackupPolicies||[]), ...(db.governanceRetentionRules||[])].map((x)=><div key={x.id} style={card()}><Row main={(x.code||"")+" — "+(x.name||x.recordType)} sub={[x.frequency,x.retention||x.retentionPeriod,x.ownerRole,x.rule].filter(Boolean).join(" · ")} /></div>)}</Section></>}
    {sub === "evidence" && <><Section title="Evidence Register">{(db.governanceEvidenceRegister||[]).map((e)=><div key={e.id} style={card()}><Row main={e.title} sub={[e.controlCode,e.source,e.createdAt,e.uri].filter(Boolean).join(" · ")} /></div>)}{!(db.governanceEvidenceRegister||[]).length && <Empty text="سيتم تصدير الأدلة كملف JSON، ويمكن إضافة Evidence URLs لاحقًا."/>}</Section><Section title="Training / Acknowledgements">{(db.governancePolicyAcknowledgements||[]).map((a)=><div key={a.id} style={card()}><Row main={a.policy} sub={[a.role,a.userEmail,a.acknowledgedAt].filter(Boolean).join(" · ")} badge={{text:a.status||"مقر", color:C.green}} /></div>)}{(db.governanceTrainingRecords||[]).map((t)=><div key={t.id} style={card()}><Row main={t.course||t.title||t.topic} sub={[t.userRole||t.roleName,t.completedAt,t.status].filter(Boolean).join(" · ")} /></div>)}</Section></>}
  </>;
}

/* ───────────────────────── التقارير ومحرك الوظائف ───────────────────────── */
function Reports({ ctx }) {
  const { db, save, woCost, nameOf, can } = ctx;
  const [reportName, setReportName] = useState(MAINTENANCE_REPORTS[0]);
  const all = db.workOrders;
  const byStatus = [...WO_FLOW, ...WO_EXTRA].map((s) => ({ name: s, عدد: all.filter((w) => w.status === s).length })).filter((d) => d.عدد > 0);
  const byType = ["وقائي", "تصحيحي", "طارئ"].map((t) => ({ name: t, value: all.filter((w) => w.type === t).length })).filter((d) => d.value > 0);
  const costByAsset = db.assets.map((a) => ({ name: a.name, تكلفة: all.filter((w) => w.assetId === a.id).reduce((s, w) => s + woCost(w).total, 0) })).filter((d) => d.تكلفة > 0).sort((a, b) => b.تكلفة - a.تكلفة).slice(0, 6);
  const techPerf = db.technicians.map((t) => { let ops = 0, hours = 0; all.forEach((w) => (w.operations || []).forEach((o) => { if (o.assigneeId === t.id && o.status === "مكتملة") { ops++; hours += Number(o.actualHours || 0); } })); return { name: t.name, عمليات: ops, ساعات: hours }; }).filter((x) => x.عمليات > 0).sort((a, b) => b.عمليات - a.عمليات);
  const pm = all.filter((w) => w.type === "وقائي" && ["مغلق"].includes(w.status));
  const pmOnTime = pm.filter((w) => !w.plannedEnd || !w.completedAt || w.completedAt <= w.plannedEnd).length;
  const totalCost = all.reduce((s, w) => s + woCost(w).total, 0);
  const done = all.filter((w) => w.status === "مغلق").length;
  const reportRows = (name) => {
    if (name.includes("Past Due")) return all.filter((w)=>w.plannedEnd && daysUntil(w.plannedEnd)<0).map((w)=>({ number:w.number, title:w.title, asset:nameOf("assets", w.assetId), status:w.status, plannedEnd:w.plannedEnd }));
    if (name.includes("Completed")) return all.filter((w)=>w.status==="مغلق").map((w)=>({ number:w.number, title:w.title, asset:nameOf("assets", w.assetId), completedAt:w.completedAt, cost:woCost(w).total }));
    if (name.includes("Cost")) return all.map((w)=>({ number:w.number, asset:nameOf("assets", w.assetId), labor:woCost(w).labor, material:woCost(w).material, total:woCost(w).total })).filter((r)=>r.total>0);
    if (name.includes("Technician")) return techPerf;
    if (name.includes("Failure") || name.includes("MTTR") || name.includes("MTBF")) return all.filter((w)=>w.failure).map((w)=>({ number:w.number, asset:nameOf("assets", w.assetId), mode:w.failure?.mode, cause:w.failure?.cause, downtime:w.failure?.downtime || w.failure?.downtimeMinutes || 0, action:w.failure?.action }));
    if (name.includes("Forecast")) return (db.maintenanceForecasts||[]).map((f)=>({ program:nameOf("programs", f.programId), asset:nameOf("assets", f.assetId), dueDate:f.dueDate, status:f.status, risk:f.risk }));
    if (name.includes("Material")) return (db.workOrderMaterialUsage||[]).map((m)=>({ workOrder:nameOf("workOrders", m.workOrderId, "number"), item:nameOf("items", m.itemId), usedQty:m.usedQty, cost:Number(m.usedQty||0)*Number(m.unitCost||0) }));
    return all.map((w)=>({ number:w.number, title:w.title, asset:nameOf("assets", w.assetId), type:w.type, priority:w.priority, status:w.status, plannedStart:w.plannedStart, plannedEnd:w.plannedEnd }));
  };
  const exportCsv = (name, rows) => { const cols = [...new Set(rows.flatMap((r)=>Object.keys(r)))]; const csv = [cols.join(","), ...rows.map((r)=>cols.map((c)=>'"'+String(r[c] ?? "").replace(/"/g, '""')+'"').join(","))].join("\n"); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type:"text/csv;charset=utf-8" })); a.download = name.replace(/\s+/g, "-") + "-" + today() + ".csv"; a.click(); };
  const runReport = () => { const rows = reportRows(reportName); const job = { id:uid(), name:reportName, status:"Completed", requestedAt:now(), completedAt:now(), rowCount:rows.length, requestedBy:"CMMS" }; const out = { id:uid(), jobId:job.id, name:reportName, generatedAt:now(), rowCount:rows.length, summary:JSON.stringify(rows.slice(0, 5)) }; save({ ...db, reportJobs:[...(db.reportJobs||[]), job], savedReportOutputs:[...(db.savedReportOutputs||[]), out] }); };
  const rows = reportRows(reportName);
  return (<>
    <div style={{ display: "flex", gap: 8, marginBottom: 16 }}><Stat n={all.length} label="إجمالي الأوامر" color={C.ink} /><Stat n={done} label="مغلق" color={C.green} /><Stat n={pm.length ? Math.round((pmOnTime / pm.length) * 100) + "%" : "—"} label="التزام الوقائية" color={C.blue} small /><Stat n={money(totalCost)} label="التكلفة" color={C.orange} small /></div>
    <Section title="Report Job Engine"><div style={{...card(), display:"grid", gridTemplateColumns:"1fr", gap:8}}><Field label="التقرير"><select value={reportName} onChange={(e)=>setReportName(e.target.value)} style={inputStyle()}>{MAINTENANCE_REPORTS.map((r)=><option key={r}>{r}</option>)}</select></Field><div style={{display:"flex", gap:8}}>{can?.review && <Btn bg={C.green} onClick={runReport} style={{flex:1}}>Run Report Job</Btn>}<Btn bg={C.blue} onClick={()=>exportCsv(reportName, rows)} style={{flex:1}}>Export CSV</Btn></div><div style={{fontSize:12, color:C.steel}}>الصفوف الحالية: {rows.length}. يتم حفظ نتيجة التشغيل داخل reportJobs و savedReportOutputs.</div></div>{(db.reportJobs||[]).slice().reverse().slice(0,5).map((j)=><div key={j.id} style={card()}><Row main={j.name} sub={j.requestedAt+" · "+j.status+" · Rows: "+j.rowCount} badge={{text:j.status, color:C.green}} /></div>)}</Section>
    {byStatus.length === 0 ? <Empty text="ستظهر الرسوم عند توفر أوامر عمل." /> : (<><Section title="أوامر العمل حسب الحالة"><div style={{ ...card(), height: 220, padding: 8 }}><ResponsiveContainer><BarChart data={byStatus}><XAxis dataKey="name" tick={{ fontSize: 10 }} /><YAxis allowDecimals={false} width={24} /><Tooltip /><Bar dataKey="عدد" fill={C.orange} /></BarChart></ResponsiveContainer></div></Section>{byType.length > 0 && <Section title="وقائي / تصحيحي / طارئ"><div style={{ ...card(), height: 220, padding: 8 }}><ResponsiveContainer><PieChart><Pie data={byType} dataKey="value" nameKey="name" outerRadius={70} label>{byType.map((d, i) => <Cell key={i} fill={[C.green, C.amber, C.red][i]} />)}</Pie><Legend /><Tooltip /></PieChart></ResponsiveContainer></div></Section>}{techPerf.length > 0 && <Section title="أداء الفنيين"><div style={card()}>{techPerf.map((t) => (<div key={t.name} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4 }}><span>{t.name}</span><span>{t.عمليات} عملية · {t.ساعات} ساعة</span></div>))}</div></Section>}{costByAsset.length > 0 && <Section title="تكلفة الصيانة حسب الأصل (ر.س)"><div style={{ ...card(), height: 220, padding: 8 }}><ResponsiveContainer><BarChart data={costByAsset} layout="vertical"><XAxis type="number" /><YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 11 }} /><Tooltip /><Bar dataKey="تكلفة" fill={C.blue} /></BarChart></ResponsiveContainer></div></Section>}</>)}
  </>);
}

/* ───────────────────────── البيانات والنسخ ───────────────────────── */
function DataTab({ exportData, importData, exportAssetsCSV, db, can, save }) {
  const counts = Object.values(db).filter(Array.isArray).reduce((a, v) => a + v.length, 0);
  const importAssetsCsv = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      const lines = String(reader.result || "").split(/\r?\n/).filter((l) => l.trim());
      if (lines.length < 2) return alert("ملف CSV فارغ");
      const headers = lines[0].split(",").map((h) => h.trim());
      const rows = lines.slice(1).map((line) => {
        const cells = line.split(",");
        const r = {}; headers.forEach((h, i) => r[h] = (cells[i] || "").trim());
        return r;
      });
      const imported = []; const skipped = [];
      rows.forEach((r) => {
        const number = r.number || r.asset_number || r["رقم الأصل"] || "";
        const name = r.name || r.description || r["اسم الأصل"] || "";
        if (!name) { skipped.push(number || "بدون اسم"); return; }
        if (number && db.assets.some((a) => a.number === number)) { skipped.push(number + " مكرر"); return; }
        imported.push({ id:uid(), number: number || "AST-" + String(2000 + db.assets.length + imported.length + 1), name, location: r.location || r["الموقع"] || "Unknown", locationType: r.locationType || "UNKNOWN", type: r.type || "معدات", ownership: r.ownership || "مؤسسة", assetType: (r.ownership || "") === "عميل" ? "CUSTOMER" : "ENTERPRISE", serial: r.serial || "", itemName: r.itemName || r.item || "", itemRequired:false, quantity:Number(r.quantity || 1), parts:[], docs:[], photos:[], notes:[], history:[{ action:"استيراد CSV", at:now(), by:"استيراد" }], allowWO:true, allowPrograms:true, active:true });
      });
      save({ ...db, assets:[...db.assets, ...imported], assetImportBatches:[...(db.assetImportBatches || []), { id:uid(), at:now(), source:file.name, imported:imported.length, skipped:skipped.length, notes: skipped.join("; ") }] });
      alert("تم استيراد " + imported.length + " أصل. المتروك: " + skipped.length);
    };
    reader.readAsText(file);
  };
  return (
    <>
      <Section title="نسخة احتياطية">
        <div style={card()}>
          <div style={{ fontSize: 13, color: C.steel, marginBottom: 8 }}>
            لديك {counts} سجلًا. نزّل JSON أو استورده؛ البيانات الآن تُحفظ في الـ Backend عند توفره مع نسخة محلية احتياطية.
          </div>
          <Btn bg={C.blue} onClick={exportData} style={{ width: "100%", padding: 12, marginBottom: 8 }}>تنزيل نسخة احتياطية (JSON)</Btn>
          <Btn bg={C.purple} onClick={exportAssetsCSV} style={{ width: "100%", padding: 12 }}>تصدير سجل الأصول (CSV)</Btn>
        </div>
      </Section>
      <Section title="استيراد">
        <div style={card()}>
          <input type="file" accept=".json" onChange={(e) => e.target.files[0] && importData(e.target.files[0])} style={{ fontSize: 14 }} />
        </div>
      </Section>
      <Section title="استيراد أصول CSV — فصل 3 Import Assets">
        <div style={{ ...card(), fontSize:13, color:C.steel }}>الأعمدة المقبولة: number,name,location,type,ownership,serial,itemName,quantity. يتم تجاهل الأرقام المكررة وتسجيل دفعة الاستيراد.</div>
        <input type="file" accept=".csv,text/csv" onChange={(e) => e.target.files[0] && importAssetsCsv(e.target.files[0])} />
        {(db.assetImportBatches || []).slice().reverse().map((b) => <div key={b.id} style={card()}><Row main={b.source + " — " + b.imported + " مستورد"} sub={b.at + " · متروك: " + b.skipped + (b.notes ? " · " + b.notes : "")} /></div>)}
      </Section>
      {can.admin && (
        <Section title="منطقة الخطر">
          <div style={{ ...card(), borderRightColor: C.red }}>
            <Btn bg={C.red} onClick={() => { if (confirm("حذف كل البيانات نهائيًا؟")) save({ ...EMPTY }); }} style={{ width: "100%", padding: 12 }}>مسح كل البيانات</Btn>
          </div>
        </Section>
      )}
    </>
  );
}

/* ───────────────────────── CRUD عام ───────────────────────── */
function assetSchema() {
  return [
    { k: "number", label: "رقم الأصل (فارغ = توليد تلقائي)" }, { k: "name", label: "اسم الأصل" },
    { k: "ownership", label: "الملكية", type: "select", options: ASSET_OWNERSHIP },
    { k: "customer", label: "العميل (لأصل العميل)" },
    { k: "customerAccountId", label: "حساب العميل" },
    { k: "type", label: "النوع", type: "select", options: ["معدات", "مركبة", "مبنى", "أداة", "أخرى"] },
    { k: "itemRequired", label: "Item مطلوب", type: "check" },
    { k: "itemName", label: "Item / الصنف المرتبط" },
    { k: "fullLifecycleTracked", label: "Full Lifecycle Tracked", type: "check" },
    { k: "customerAssetTracking", label: "Customer Asset Tracking", type: "check" },
    { k: "operatingOrganizationId", label: "منظمة التشغيل/الصيانة", type: "select", from: "maintenanceOrganizations", fromKey: "name" },
    { k: "locationType", label: "نوع الموقع", type: "select", options: LOCATION_TYPES },
    { k: "location", label: "الموقع (إلزامي)" }, { k: "serial", label: "الرقم التسلسلي (فريد داخل المنظمة)" },
    { k: "lotNumber", label: "Lot Number" },
    { k: "quantity", label: "الكمية (غير المسلسل يقبل >1 ثم تقسيم)", type: "number" },
    { k: "uom", label: "UOM" }, { k: "secondaryQuantity", label: "Secondary Quantity", type: "number" },
    { k: "specs", label: "المواصفات الفنية (سطر لكل مواصفة)", type: "textarea" },
    { k: "parentId", label: "الأصل الأب", type: "select", from: "assets", fromKey: "name" },
    { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
    { k: "contact", label: "جهة الاتصال/المسؤول" },
    { k: "shipmentDate", label: "Shipment Date", type: "date" },
    { k: "installedDate", label: "Installed Date", type: "date" },
    { k: "inServiceDate", label: "In-Service Date", type: "date" },
    { k: "defaultWOType", label: "نوع أمر العمل الافتراضي", type: "select", options: ["", "تصحيحي", "وقائي", "طارئ"] },
    { k: "defaultWOSubtype", label: "Subtype افتراضي", type: "select", options: DEFAULT_WO_SUBTYPES },
    { k: "allowWO", label: "يسمح بأوامر العمل", type: "check" },
    { k: "allowPrograms", label: "يسمح ببرامج الصيانة", type: "check" },
    { k: "enableIoT", label: "تفعيل IoT (توأم رقمي)", type: "check" },
    { k: "competitorAsset", label: "Competitor Asset", type: "check" },
    { k: "critical", label: "أصل حرج", type: "check" }, { k: "active", label: "نشط", type: "check" },
    { k: "project", label: "Project" }, { k: "task", label: "Task" }, { k: "countryOfOrigin", label: "Country of Origin" },
    { k: "fixedAssetNumber", label: "Fixed Asset Number" }, { k: "fixedAssetBook", label: "Fixed Asset Book" },
    { k: "lastSalesOrderDetails", label: "Last Sales Order / Service Details", type: "textarea" },
    { k: "useBomForInitialHierarchy", label: "استخدام BOM لإنشاء هيكل أولي", type: "check" },
    { k: "endDate", label: "تاريخ إنهاء الأصل (ينهي الصيانة والاستخدام)", type: "date" },
  ];
}

function Crud({ ctx, entity, title, schema, render, badge, validate, validateDelete }) {
  const { db, add, update, remove, can } = ctx;
  const [form, setForm] = useState(null);
  const rows = db[entity];
  return (
    <>
      {can.manage && <Btn bg={C.orange} onClick={() => setForm("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ إضافة — {title}</Btn>}
      {rows.length === 0 && <Empty text={"لا سجلات في " + title + " بعد."} />}
      {rows.map((r) => {
        const [main, sub] = render(r);
        return (
          <div key={r.id} style={card()} onClick={() => can.manage && setForm(r)}>
            <Row main={main} sub={sub} badge={badge ? badge(r) : undefined} />
          </div>
        );
      })}
      {form && (
        <FormSheet title={form === "new" ? "إضافة — " + title : "تعديل"} onClose={() => setForm(null)} db={db}
          schema={schema} initial={form === "new" ? { active: true } : form}
          onDelete={form !== "new" && can.admin ? () => { const err = validateDelete?.(form); if (err) { alert(err); return; } remove(entity, form.id); setForm(null); } : undefined}
          onSave={(d) => { const err = validate?.(d, form === "new" ? null : form); if (err) { alert(err); return; } form === "new" ? add(entity, d) : update(entity, form.id, d); setForm(null); }} />
      )}
    </>
  );
}

function FormSheet({ title, schema, db, initial = {}, onSave, onClose, onDelete }) {
  const [f, setF] = useState(initial);
  const set = (k, v) => setF({ ...f, [k]: v });
  const first = schema[0].k;
  return (
    <Sheet title={title} onClose={onClose}>
      {schema.map((s) => (
        <Field key={s.k} label={s.label}>
          {s.type === "select" && (
            <select value={f[s.k] || ""} onChange={(e) => set(s.k, e.target.value)} style={input}>
              <option value="">—</option>
              {(s.options || db[s.from] || []).map((o) =>
                typeof o === "string"
                  ? <option key={o} value={o}>{o}</option>
                  : <option key={o.id} value={o.id}>{s.fromLabel ? s.fromLabel(o) : o[s.fromKey]}</option>)}
            </select>
          )}
          {s.type === "multi" && (
            <div style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, padding: 8, maxHeight: 140, overflowY: "auto", background: "#fff" }}>
              {(db[s.from] || []).length === 0 && <div style={{ color: C.steel, fontSize: 13 }}>لا عناصر متاحة بعد</div>}
              {(db[s.from] || []).map((o) => (
                <label key={o.id} style={{ display: "flex", gap: 8, alignItems: "center", padding: "4px 0" }}>
                  <input type="checkbox" checked={(f[s.k] || []).includes(o.id)}
                    onChange={(e) => set(s.k, e.target.checked ? [...(f[s.k] || []), o.id] : (f[s.k] || []).filter((x) => x !== o.id))} />
                  <span style={{ fontSize: 14 }}>{o[s.fromKey]}</span>
                </label>
              ))}
            </div>
          )}
          {s.type === "check" && <input type="checkbox" checked={!!f[s.k]} onChange={(e) => set(s.k, e.target.checked)} style={{ width: 22, height: 22 }} />}
          {s.type === "textarea" && <textarea value={f[s.k] || ""} onChange={(e) => set(s.k, e.target.value)} rows={3} style={{ ...input, resize: "vertical" }} />}
          {(!s.type || ["text", "number", "date"].includes(s.type)) && (
            <input type={s.type || "text"} value={f[s.k] ?? ""} onChange={(e) => set(s.k, e.target.value)} style={input} />
          )}
        </Field>
      ))}
      <div style={{ display: "flex", gap: 8 }}>
        <Btn bg={C.orange} style={{ flex: 1, padding: 13, fontSize: 15, opacity: String(f[first] || "").trim() ? 1 : 0.5 }}
          onClick={() => String(f[first] || "").trim() && onSave(f)}>حفظ</Btn>
        {onDelete && <Btn bg={C.red} style={{ padding: 13 }} onClick={onDelete}>حذف</Btn>}
      </div>
    </Sheet>
  );
}

/* ───────────────────────── عناصر واجهة ───────────────────────── */
function AddInline({ placeholder, onAdd }) {
  const [t, setT] = useState("");
  return (
    <div style={{ display: "flex", gap: 8 }}>
      <input value={t} onChange={(e) => setT(e.target.value)} placeholder={placeholder} style={input} />
      <Btn bg={C.ink} onClick={() => { if (t.trim()) { onAdd(t.trim()); setT(""); } }}>+</Btn>
    </div>
  );
}
const card = () => ({ background: C.card, border: `1.5px solid ${C.ink}`, borderRight: `8px solid ${C.ink}`, borderRadius: 4, padding: "10px 12px", marginBottom: 8, boxShadow: "-2px 2px 0 " + C.line });
const input = { width: "100%", padding: "10px 12px", border: `1.5px solid ${C.ink}`, borderRadius: 4, background: "#fff", boxSizing: "border-box" };
const inputStyle = () => ({ ...input });
const delBtn = { marginTop: 6, background: "none", border: "none", color: C.steel, fontSize: 12, textDecoration: "underline", padding: 0 };

function Btn({ bg, children, style, onClick }) {
  return <button onClick={(e) => { e.stopPropagation(); onClick && onClick(); }} style={{ background: bg, color: "#fff", border: `1.5px solid ${C.ink}`, borderRadius: 4, padding: "7px 12px", fontSize: 13, fontWeight: 700, ...style }}>{children}</button>;
}
function Badge({ text, color }) {
  return <span style={{ background: color, color: "#fff", borderRadius: 4, padding: "3px 8px", fontSize: 12, fontWeight: 700, whiteSpace: "nowrap" }}>{text}</span>;
}
function Chip({ active, children, onClick }) {
  return <button onClick={onClick} style={{ padding: "5px 12px", borderRadius: 999, border: `1.5px solid ${C.ink}`, background: active ? C.ink : "transparent", color: active ? "#fff" : C.ink, fontSize: 13, whiteSpace: "nowrap" }}>{children}</button>;
}
function Stat({ n, label, color, small }) {
  return <div style={{ flex: 1, background: C.card, border: `2px solid ${C.ink}`, borderRadius: 4, padding: "8px 10px" }}>
    <div style={{ fontSize: small ? 14 : 24, fontWeight: 800, color, lineHeight: 1.3 }}>{n}</div>
    <div style={{ fontSize: 10.5, color: C.steel }}>{label}</div>
  </div>;
}
function Section({ title, children }) {
  return <section style={{ marginBottom: 18 }}>
    <h2 style={{ fontSize: 15, fontWeight: 800, borderBottom: `1px solid ${C.line}`, paddingBottom: 5, margin: "0 0 8px" }}>{title}</h2>
    {children}
  </section>;
}
function Row({ main, sub, badge, action }) {
  return <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "flex-start" }}>
    <div style={{ minWidth: 0 }}>
      <div style={{ fontWeight: 700, fontSize: 14.5 }}>{main}</div>
      {sub && <div style={{ fontSize: 12.5, color: C.steel }}>{sub}</div>}
    </div>
    {badge && <Badge text={badge.text} color={badge.color} />}
    {action}
  </div>;
}
function Empty({ text }) {
  return <div style={{ padding: "22px 12px", textAlign: "center", color: C.steel, border: `1.5px dashed ${C.line}`, borderRadius: 6, marginBottom: 8, fontSize: 13.5 }}>{text}</div>;
}
function Field({ label, children }) {
  return <label style={{ display: "block", marginBottom: 11, flex: 1 }}>
    <div style={{ fontSize: 12, color: C.steel, marginBottom: 4, fontWeight: 700 }}>{label}</div>
    {children}
  </label>;
}
function Sheet({ title, onClose, children }) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(22,25,27,.5)", zIndex: 10, display: "flex", alignItems: "flex-end" }}>
      <div dir="rtl" onClick={(e) => e.stopPropagation()} style={{ background: C.card, width: "100%", maxHeight: "92vh", overflowY: "auto", borderTop: `3px solid ${C.ink}`, borderRadius: "12px 12px 0 0", padding: 16, fontFamily: "'Cairo', system-ui, sans-serif" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <h2 style={{ margin: 0, fontSize: 18, fontWeight: 800 }}>{title}</h2>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 24 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}
