# تحديث v21 — Supervision Workbench + Advanced Maintenance Forecast

هذا التحديث يكمل المرحلة التالية بعد تشغيل Firebase واستقرار APK.

## ما أضيف

### 1. لوحة المشرف المتقدمة Supervision Workbench
- تبويبات: الملخص، Workbench، الجدولة، الإسناد، المواد، المراجعة، التعارضات، السجل.
- حساب حمل الفنيين حسب أوامر العمل والساعات المتوقعة.
- حساب استغلال السعة لكل Work Center بناءً على الموارد المتاحة والطلب المفتوح.
- Conflict Preview لاكتشاف:
  - أمر بدون أصل.
  - أمر بدون فني مسند.
  - أمر متأخر.
  - أمر بانتظار مواد.
  - أمر بانتظار مراجعة أكثر من يوم.
  - أمر بدون Work Center واضح.
  - ضغط زائد على الفني في نفس اليوم.
- Assignment Drawer لإسناد/إعادة إسناد الفنيين.
- Auto Assignment لتوزيع الأوامر غير المسندة على الفني الأقل حملًا.
- حفظ خطة جدولة Snapshot داخل `maintenanceSchedulePlans` مع التعارضات داخل `maintenanceScheduleConflicts`.

### 2. توقعات الصيانة المتقدمة Advanced Forecast
- Forecast Horizon بالأيام.
- توليد Forecast Lines لكل برنامج وأصل.
- دعم برامج الأيام وبرامج العدادات.
- حساب:
  - Current Meter.
  - Due Meter.
  - Remaining.
  - Estimated daily rate.
  - Due / Due Soon / Planned.
- Forecast Validation:
  - لا أصول متأثرة.
  - لا Work Definition.
  - لا Meter للبرامج المعتمدة على العداد.
  - Interval غير صحيح.
- Save Forecast Run داخل `maintenanceForecastRuns`.
- Suppress / Unsuppress لأي Forecast Line.
- Generate Due PM Work Orders من التوقعات المستحقة أو القريبة.

### 3. كيانات جديدة
- `maintenanceForecastRuns`
- `maintenanceForecastSuppressions`
- `maintenanceSchedulePlans`
- `maintenanceScheduleConflicts`

## أين تجدها داخل التطبيق

- `الإشراف` من الشريط السفلي لفتح لوحة المشرف المتقدمة.
- `المزيد → توقعات الصيانة` لفتح التوقعات المتقدمة.
- `المزيد → إدارة الصيانة` ثم الملخص ستجد أزرار انتقال مباشرة إلى لوحة المشرف والتوقعات.

## ملاحظة Firebase

القواعد الحالية تسمح للمدير/المشرف بكتابة الكيانات الجديدة. أرفقت نسخة قواعد v21 احتياطية إذا أردت نشرها من Firebase Console.
