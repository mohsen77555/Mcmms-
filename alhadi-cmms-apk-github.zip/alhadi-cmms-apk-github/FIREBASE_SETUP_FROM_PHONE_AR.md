# ربط تطبيق CMMS مع Firebase من الهاتف

هذه النسخة تضيف Firebase Auth + Firestore + Firestore Security Rules حتى لا تكون الصلاحيات مجرد اختيار داخل الواجهة.

## 1) أنشئ مشروع Firebase

1. افتح Firebase Console من المتصفح.
2. Create project.
3. افتح Build → Authentication → Sign-in method.
4. فعّل Email/Password.
5. افتح Build → Firestore Database.
6. Create database.
7. اختر Production mode.

## 2) انشر قواعد Firestore

افتح Firestore Database → Rules، ثم انسخ محتوى ملف:

firestore.rules

والصقه كاملًا، ثم Publish.

> بريد المالك الافتراضي داخل القواعد هو:
> mohsenalhadi77555@gmail.com
>
> إذا كان بريدك مختلفًا، غيّر هذا السطر داخل firestore.rules قبل النشر.

## 3) خذ إعدادات Web App

من Firebase Project settings → General → Your apps → Web app.
انسخ كائن firebaseConfig، مثال:

const firebaseConfig = {
  apiKey: "...",
  authDomain: "...",
  projectId: "...",
  storageBucket: "...",
  messagingSenderId: "...",
  appId: "..."
};

## 4) الصقه داخل التطبيق

بعد تثبيت APK:

1. افتح التطبيق.
2. المزيد → Firebase والصلاحيات.
3. الصق firebaseConfig.
4. اضغط حفظ إعدادات Firebase.
5. التطبيق سيعيد التشغيل.
6. سجّل دخولك بنفس بريد المالك أعلاه ليأخذ دور مدير تلقائيًا.

## 5) إضافة المستخدمين

1. من شاشة الدخول، كل مستخدم ينشئ حسابه.
2. أنت كمدير تدخل: المزيد → المستخدمون والصلاحيات.
3. اختر دور كل مستخدم: مدير، مشرف، فني، مخزن، طالب خدمة.
4. إذا كان المستخدم فنيًا، اربطه بسجل الفني المناسب.

## ما الذي تحميه القواعد؟

- لا قراءة بدون تسجيل دخول.
- المدير والمشرف يستطيعان إدارة أغلب البيانات.
- الفني يكتب أقسام العمل والقراءات فقط.
- المخزن يكتب المخزون والحركات وأوامر العمل المرتبطة بالصرف.
- طالب الخدمة يكتب طلبات العمل فقط.

ملاحظة: هذه مرحلة قوية وسريعة مبنية على أقسام البيانات. المرحلة الإنتاجية الأعمق هي تحويل كل أمر عمل وكل أصل إلى مستند مستقل بقواعد أدق على مستوى السجل الواحد.
