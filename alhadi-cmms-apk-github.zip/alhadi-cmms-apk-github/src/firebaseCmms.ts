import { initializeApp, getApps, getApp, type FirebaseOptions } from "firebase/app";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, type User } from "firebase/auth";
import { initializeFirestore, getFirestore, persistentLocalCache, persistentMultipleTabManager, doc, getDoc, setDoc, collection, getDocs, updateDoc, writeBatch, type Firestore } from "firebase/firestore";

export const FIREBASE_CONFIG_STORAGE_KEY = "cmms-firebase-config-v1";
export const FIREBASE_OWNER_EMAIL = ((import.meta as any).env?.VITE_FIREBASE_OWNER_EMAIL || "mohsenalhadi77555@gmail.com").toLowerCase();

export type CmmsFirebaseServices = {
  app: ReturnType<typeof initializeApp>;
  auth: ReturnType<typeof getAuth>;
  firestore: Firestore;
  config: FirebaseOptions;
};

const ROLE_ALIASES: Record<string, string> = {
  "مدير": "مدير", admin: "مدير", manager: "مدير", owner: "مدير",
  "مشرف": "مشرف", supervisor: "مشرف",
  "فني": "فني", technician: "فني", tech: "فني",
  "مخزن": "مخزن", warehouse: "مخزن", storekeeper: "مخزن",
  "طالب خدمة": "طالب خدمة", requester: "طالب خدمة", requestor: "طالب خدمة", user: "طالب خدمة",
};

export function normalizeFirebaseRole(value: any): string {
  const raw = String(value || "").trim();
  if (!raw) return "";
  return ROLE_ALIASES[raw] || ROLE_ALIASES[raw.toLowerCase()] || raw;
}

function envConfig(): FirebaseOptions | null {
  const env = (import.meta as any).env || {};
  if (!env.VITE_FIREBASE_API_KEY || !env.VITE_FIREBASE_PROJECT_ID || !env.VITE_FIREBASE_APP_ID) return null;
  return {
    apiKey: env.VITE_FIREBASE_API_KEY,
    authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || `${env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
    projectId: env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || `${env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
    messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || "",
    appId: env.VITE_FIREBASE_APP_ID,
  };
}

export function extractFirebaseConfig(text: string): FirebaseOptions | null {
  const input = String(text || "").trim();
  if (!input) return null;

  try {
    const parsed = JSON.parse(input);
    if (parsed?.apiKey && parsed?.projectId && parsed?.appId) return parsed;
  } catch {}

  const keys = ["apiKey", "authDomain", "projectId", "storageBucket", "messagingSenderId", "appId", "measurementId"];
  const cfg: any = {};
  for (const key of keys) {
    const m = input.match(new RegExp(`${key}\\s*:\\s*[\"']([^\"']+)[\"']`));
    if (m) cfg[key] = m[1];
  }
  if (cfg.apiKey && cfg.projectId && cfg.appId) return cfg;
  return null;
}

export function runtimeConfig(): FirebaseOptions | null {
  if (typeof window === "undefined" || !window.localStorage) return null;
  try {
    const raw = window.localStorage.getItem(FIREBASE_CONFIG_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function getFirebaseConfig(): FirebaseOptions | null {
  return envConfig() || runtimeConfig();
}

export function saveRuntimeFirebaseConfig(config: FirebaseOptions) {
  if (typeof window === "undefined" || !window.localStorage) return;
  window.localStorage.setItem(FIREBASE_CONFIG_STORAGE_KEY, JSON.stringify(config));
}

export function clearRuntimeFirebaseConfig() {
  if (typeof window === "undefined" || !window.localStorage) return;
  window.localStorage.removeItem(FIREBASE_CONFIG_STORAGE_KEY);
}

let cachedServices: CmmsFirebaseServices | null = null;

export function getFirebaseServices(): CmmsFirebaseServices | null {
  if (cachedServices) return cachedServices;
  const config = getFirebaseConfig();
  if (!config) return null;

  let app: ReturnType<typeof initializeApp>;
  try {
    app = getApps().length ? getApp() : initializeApp(config);
  } catch (e) {
    console.error("Firebase config غير صالح", e);
    return null;
  }
  let firestore: Firestore;
  try {
    firestore = initializeFirestore(app, {
      ignoreUndefinedProperties: true,
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    });
  } catch {
    // initializeFirestore throws if Firestore was already initialized; re-use the existing instance.
    firestore = getFirestore(app);
  }
  cachedServices = { app, auth: getAuth(app), firestore, config };
  return cachedServices;
}

export function subscribeFirebaseAuth(services: CmmsFirebaseServices, cb: (user: User | null) => void) {
  return onAuthStateChanged(services.auth, cb);
}

export async function signInFirebase(services: CmmsFirebaseServices, email: string, password: string) {
  return signInWithEmailAndPassword(services.auth, email.trim(), password);
}

export async function registerFirebase(services: CmmsFirebaseServices, email: string, password: string) {
  return createUserWithEmailAndPassword(services.auth, email.trim(), password);
}

export async function signOutFirebase(services: CmmsFirebaseServices) {
  return signOut(services.auth);
}

export async function ensureFirebaseUserProfile(services: CmmsFirebaseServices, user: User) {
  const token = await user.getIdTokenResult(true);
  const claims: any = token.claims || {};
  const claimRole = normalizeFirebaseRole(claims.role || claims.cmmsRole || claims.cmms_role);
  const claimTechId = String(claims.technicianId || claims.techId || claims.cmmsTechId || "");
  const email = String(user.email || "").toLowerCase();
  const isOwner = email === FIREBASE_OWNER_EMAIL;

  const ref = doc(services.firestore, "users", user.uid);
  const snap = await getDoc(ref);
  const existing: any = snap.exists() ? snap.data() : null;
  const storedRole = normalizeFirebaseRole(existing?.role);
  const role = isOwner ? "مدير" : (claimRole || storedRole || "طالب خدمة");
  const technicianId = existing?.technicianId || claimTechId || "";
  const nowIso = new Date().toISOString();
  const patch: any = snap.exists()
    ? {
        displayName: existing?.displayName || user.displayName || "",
        technicianId,
        updatedAtIso: nowIso,
        lastLoginAtIso: nowIso,
      }
    : {
        email: user.email || "",
        displayName: user.displayName || "",
        role,
        technicianId,
        createdAtIso: nowIso,
        updatedAtIso: nowIso,
        lastLoginAtIso: nowIso,
      };

  try {
    await setDoc(ref, patch, { merge: true });
  } catch (e) {
    console.warn("تعذر تحديث ملف المستخدم؛ سيتم استخدام الدور المقروء فقط", e);
  }

  return { ...(existing || {}), ...patch, role, email: user.email || existing?.email || "", uid: user.uid, claims, isOwner };
}

/* ───────────────────────── Firestore Record-per-Document Storage ─────────────────────────
  البنية الجديدة:
  cmms/main/meta/settings
  cmms/main/meta/schema
  cmms/main/records/{entityName}/items/{recordId}

  ما زالت القراءة تدعم البنية القديمة cmms/main/entities/{entityName} حتى لا تضيع بياناتك القديمة.
*/

const LEGACY_ENTITY_COLLECTION_PATH = ["cmms", "main", "entities"] as const;
const WORKSPACE_PATH = ["cmms", "main"] as const;

export const CMMS_RECORD_ENTITIES = [
  "maintenanceOrganizations", "plantParameters", "workAreas", "workCenters", "resources", "workCenterResources",
  "resourceInstances", "shifts", "resourceExceptions", "infolets", "importBatches",
  "governancePolicies", "approvalMatrix", "governanceApprovalRequests", "governanceDataQualityRules", "governanceRisks", "governanceChangeRequests", "governanceReviews", "governanceAuditEvents",
  "technicians", "assets", "assetGroups",
  "assetParts", "assetRelationships", "assetLogicalHierarchyNodes", "assetFlexfields", "assetImportBatches",
  "assetFixedAssetLinks", "assetServiceMappings", "assetIotSyncEvents", "assetMaterialComponentTransactions",
  "meterTemplates", "assetMeters", "readings", "warranties",
  "stdOps", "workDefs", "workRequests", "programs", "workOrders",
  "items", "warehouses", "stockTx",
  "warrantyProviders", "laborRates", "repairTimes", "coverages", "contracts", "entitlements", "claims",
  "assetGroupRules", "logicalHierarchies",
] as const;

type Actor = { uid?: string; email?: string | null; role?: string };

type FirestoreOperation = {
  ref: ReturnType<typeof doc>;
  data: any;
  options?: { merge?: boolean };
};

function recordCollectionRef(services: CmmsFirebaseServices, entity: string) {
  return collection(services.firestore, ...WORKSPACE_PATH, "records", entity, "items");
}

function recordDocRef(services: CmmsFirebaseServices, entity: string, id: string) {
  return doc(services.firestore, ...WORKSPACE_PATH, "records", entity, "items", safeDocId(id));
}

function settingsDocRef(services: CmmsFirebaseServices) {
  return doc(services.firestore, ...WORKSPACE_PATH, "meta", "settings");
}

function schemaDocRef(services: CmmsFirebaseServices) {
  return doc(services.firestore, ...WORKSPACE_PATH, "meta", "schema");
}

function safeDocId(id: any) {
  return String(id || "").trim().replace(/\//g, "__slash__") || "missing-id";
}

function stableJson(value: any) {
  return JSON.stringify(value ?? null);
}

function cleanSettingsForCompare(settings: any) {
  const { role, myTechId, ...rest } = settings || {};
  return rest;
}

function settingChanged(prev: any, next: any) {
  return stableJson(cleanSettingsForCompare(prev)) !== stableJson(cleanSettingsForCompare(next));
}

export function changedEntityKeys(prev: any, next: any) {
  const keys = new Set([...Object.keys(prev || {}), ...Object.keys(next || {})]);
  keys.delete("_meta");
  return [...keys].filter((k) => {
    if (k === "settings") return settingChanged(prev?.settings, next?.settings);
    return stableJson(prev?.[k]) !== stableJson(next?.[k]);
  });
}

function stripFirestoreMeta(row: any) {
  if (!row || typeof row !== "object") return row;
  const out: any = { ...row };
  for (const key of Object.keys(out)) {
    if (key.startsWith("_cmms") || key === "_deleted") delete out[key];
  }
  return out;
}

function mapById(rows: any[]) {
  const m = new Map<string, any>();
  for (const r of Array.isArray(rows) ? rows : []) {
    const id = String(r?.id || "");
    if (id) m.set(id, r);
  }
  return m;
}

function unique(values: any[]) {
  return [...new Set(values.map((v) => String(v || "").trim()).filter(Boolean))];
}

function assignedTechIdsForRecord(entity: string, row: any) {
  if (entity !== "workOrders") return [];
  const ids: any[] = [row.assigneeId, row.technicianId, row.techId, row.assignedTo, row.ownerTechId];
  for (const op of row.operations || row.ops || []) ids.push(op?.assigneeId, op?.technicianId, op?.techId);
  for (const e of row.execLog || []) ids.push(e?.techId, e?.technicianId);
  return unique(ids);
}

function requesterUidForRecord(entity: string, row: any, actor: Actor) {
  if (entity !== "workRequests") return "";
  return String(row.requesterUid || row.createdByUid || row.userUid || row.uid || actor.uid || "");
}

function prepareRecordForFirestore(entity: string, row: any, actor: Actor, atIso: string) {
  const clean = stripFirestoreMeta(row || {});
  const id = String(clean.id || "");
  return {
    ...clean,
    _cmmsEntity: entity,
    _cmmsRecordId: id,
    _cmmsSchemaVersion: 2,
    _cmmsStorageMode: "record-documents",
    _cmmsUpdatedAtIso: atIso,
    _cmmsUpdatedBy: actor.uid || "",
    _cmmsUpdatedByEmail: actor.email || "",
    _cmmsUpdatedByRole: actor.role || "",
    _cmmsAssignedTechIds: assignedTechIdsForRecord(entity, clean),
    _cmmsRequesterUid: requesterUidForRecord(entity, clean, actor),
  };
}

function tombstoneRecord(entity: string, id: string, actor: Actor, atIso: string) {
  return {
    id,
    _deleted: true,
    _cmmsEntity: entity,
    _cmmsRecordId: id,
    _cmmsSchemaVersion: 2,
    _cmmsStorageMode: "record-documents",
    _cmmsDeletedAtIso: atIso,
    _cmmsUpdatedAtIso: atIso,
    _cmmsUpdatedBy: actor.uid || "",
    _cmmsUpdatedByEmail: actor.email || "",
    _cmmsUpdatedByRole: actor.role || "",
    _cmmsAssignedTechIds: [],
    _cmmsRequesterUid: "",
  };
}

async function commitOperations(services: CmmsFirebaseServices, operations: FirestoreOperation[]) {
  const chunkSize = 420; // أقل من حد batched writes المتعارف عليه مع هامش أمان.
  let committed = 0;
  for (let i = 0; i < operations.length; i += chunkSize) {
    const batch = writeBatch(services.firestore);
    for (const op of operations.slice(i, i + chunkSize)) batch.set(op.ref, op.data, op.options || { merge: false });
    await batch.commit();
    committed += Math.min(chunkSize, operations.length - i);
  }
  return committed;
}

function schemaOperation(services: CmmsFirebaseServices, actor: Actor, atIso: string): FirestoreOperation {
  return {
    ref: schemaDocRef(services),
    data: {
      storageMode: "record-documents",
      schemaVersion: 2,
      updatedAtIso: atIso,
      updatedBy: actor.uid || "",
      updatedByEmail: actor.email || "",
      recordEntities: [...CMMS_RECORD_ENTITIES],
      paths: {
        settings: "cmms/main/meta/settings",
        records: "cmms/main/records/{entityName}/items/{recordId}",
        legacy: "cmms/main/entities/{entityName}",
      },
    },
    options: { merge: true },
  };
}

function settingsOperation(services: CmmsFirebaseServices, settings: any, actor: Actor, atIso: string): FirestoreOperation {
  return {
    ref: settingsDocRef(services),
    data: {
      value: { ...(settings || {}) },
      _cmmsSchemaVersion: 2,
      _cmmsStorageMode: "record-documents",
      _cmmsUpdatedAtIso: atIso,
      _cmmsUpdatedBy: actor.uid || "",
      _cmmsUpdatedByEmail: actor.email || "",
      _cmmsUpdatedByRole: actor.role || "",
    },
    options: { merge: false },
  };
}

function diffEntityOperations(services: CmmsFirebaseServices, entity: string, prevRows: any[], nextRows: any[], actor: Actor, atIso: string, forceFull = false) {
  const operations: FirestoreOperation[] = [];
  const prevById = forceFull ? new Map<string, any>() : mapById(prevRows || []);
  const nextById = mapById(nextRows || []);

  for (const [id, row] of nextById.entries()) {
    const before = prevById.get(id);
    if (forceFull || stableJson(stripFirestoreMeta(before)) !== stableJson(stripFirestoreMeta(row))) {
      operations.push({ ref: recordDocRef(services, entity, id), data: prepareRecordForFirestore(entity, row, actor, atIso), options: { merge: false } });
    }
  }

  for (const [id] of prevById.entries()) {
    if (!nextById.has(id)) {
      operations.push({ ref: recordDocRef(services, entity, id), data: tombstoneRecord(entity, id, actor, atIso), options: { merge: false } });
    }
  }

  return operations;
}

async function loadLegacyEntityDocs(services: CmmsFirebaseServices) {
  const raw: any = {};
  const snap = await getDocs(collection(services.firestore, ...LEGACY_ENTITY_COLLECTION_PATH));
  snap.forEach((d) => { raw[d.id] = d.data()?.value; });
  return raw;
}

export async function loadCmmsStateFromFirestore(services: CmmsFirebaseServices) {
  const legacy = await loadLegacyEntityDocs(services);
  const result: any = { ...legacy };
  const presentRecordCollections: string[] = [];
  let foundAnyRecord = false;

  const settingsSnap = await getDoc(settingsDocRef(services));
  if (settingsSnap.exists()) {
    const data: any = settingsSnap.data();
    result.settings = data?.value || stripFirestoreMeta(data);
  }

  for (const entity of CMMS_RECORD_ENTITIES) {
    const baseRows = Array.isArray(legacy[entity]) ? legacy[entity] : [];
    const byId = mapById(baseRows);
    const snap = await getDocs(recordCollectionRef(services, entity));
    if (!snap.empty) {
      presentRecordCollections.push(entity);
      foundAnyRecord = true;
      snap.forEach((d) => {
        const data: any = d.data();
        const id = String(data?.id || data?._cmmsRecordId || d.id);
        if (!id) return;
        if (data?._deleted) byId.delete(id);
        else byId.set(id, stripFirestoreMeta({ ...data, id: data?.id || id }));
      });
    }
    result[entity] = [...byId.values()];
  }

  const hasLegacy = Object.keys(legacy).length > 0;
  const hasSettings = !!result.settings;
  if (!hasLegacy && !foundAnyRecord && !hasSettings) return null;

  result._meta = {
    storageMode: "record-documents",
    schemaVersion: 2,
    recordCollectionsPresent: presentRecordCollections,
    legacyCollectionsPresent: Object.keys(legacy),
    hasLegacyFallback: hasLegacy,
    loadedAtIso: new Date().toISOString(),
  };
  return result;
}

export async function saveCmmsStateToFirestore(services: CmmsFirebaseServices, prev: any, next: any, actor: Actor) {
  const at = new Date().toISOString();
  const changed = changedEntityKeys(prev, next);
  if (!changed.length) return [];

  const operations: FirestoreOperation[] = [schemaOperation(services, actor, at)];
  const summaries: string[] = [];

  for (const key of changed) {
    if (key === "settings") {
      operations.push(settingsOperation(services, cleanSettingsForCompare(next?.settings || {}), actor, at));
      summaries.push("settings:1");
      continue;
    }

    if (!CMMS_RECORD_ENTITIES.includes(key as any)) continue;
    const before = Array.isArray(prev?.[key]) ? prev[key] : [];
    const after = Array.isArray(next?.[key]) ? next[key] : [];
    const ops = diffEntityOperations(services, key, before, after, actor, at, false);
    operations.push(...ops);
    if (ops.length) summaries.push(`${key}:${ops.length}`);
  }

  if (operations.length <= 1) return [];
  await commitOperations(services, operations);
  return summaries;
}

export async function migrateCmmsStateToRecordFirestore(services: CmmsFirebaseServices, state: any, actor: Actor) {
  const at = new Date().toISOString();
  const operations: FirestoreOperation[] = [schemaOperation(services, actor, at)];
  let records = 0;

  if (state?.settings) operations.push(settingsOperation(services, cleanSettingsForCompare(state.settings), actor, at));

  for (const entity of CMMS_RECORD_ENTITIES) {
    const rows = Array.isArray(state?.[entity]) ? state[entity] : [];
    const ops = diffEntityOperations(services, entity, [], rows, actor, at, true);
    operations.push(...ops);
    records += rows.filter((r: any) => r?.id).length;
  }

  const operationsCommitted = await commitOperations(services, operations);
  return { records, operations: operationsCommitted, entities: CMMS_RECORD_ENTITIES.length };
}

export async function listFirebaseUsers(services: CmmsFirebaseServices) {
  const snap = await getDocs(collection(services.firestore, "users"));
  const rows: any[] = [];
  snap.forEach((d) => rows.push({ id: d.id, uid: d.id, ...d.data() }));
  return rows.sort((a, b) => String(a.email || "").localeCompare(String(b.email || "")));
}

export async function updateFirebaseUserProfile(services: CmmsFirebaseServices, uid: string, patch: any) {
  await updateDoc(doc(services.firestore, "users", uid), { ...patch, updatedAtIso: new Date().toISOString() });
}
