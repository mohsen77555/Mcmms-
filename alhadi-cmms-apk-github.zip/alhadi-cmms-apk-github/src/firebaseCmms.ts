import { initializeApp, getApps, getApp, type FirebaseOptions } from "firebase/app";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, type User } from "firebase/auth";
import { initializeFirestore, getFirestore, persistentLocalCache, persistentMultipleTabManager, doc, getDoc, setDoc, collection, getDocs, updateDoc, writeBatch, type Firestore } from "firebase/firestore";

export const FIREBASE_CONFIG_STORAGE_KEY = "cmms-firebase-config-v1";
export const FIREBASE_OWNER_EMAIL = ((import.meta as any).env?.VITE_FIREBASE_OWNER_EMAIL || "mohsenalhadi77555@gmail.com").toLowerCase();

export type CmmsFirebaseServices = {
  app: ReturnType<typeof initializeApp>;
  auth: ReturnType<typeof getAuth>;
  firestore: Firestore;
  config: FirebaseOptions;
};

const ROLE_ALIASES: Record<string, string> = {
  "مدير": "مدير", admin: "مدير", manager: "مدير", owner: "مدير",
  "مشرف": "مشرف", supervisor: "مشرف",
  "فني": "فني", technician: "فني", tech: "فني",
  "مخزن": "مخزن", warehouse: "مخزن", storekeeper: "مخزن",
  "طالب خدمة": "طالب خدمة", requester: "طالب خدمة", requestor: "طالب خدمة", user: "طالب خدمة",
};

export function normalizeFirebaseRole(value: any): string {
  const raw = String(value || "").trim();
  if (!raw) return "";
  return ROLE_ALIASES[raw] || ROLE_ALIASES[raw.toLowerCase()] || raw;
}

function envConfig(): FirebaseOptions | null {
  const env = (import.meta as any).env || {};
  if (!env.VITE_FIREBASE_API_KEY || !env.VITE_FIREBASE_PROJECT_ID || !env.VITE_FIREBASE_APP_ID) return null;
  return {
    apiKey: env.VITE_FIREBASE_API_KEY,
    authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || `${env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
    projectId: env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || `${env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
    messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || "",
    appId: env.VITE_FIREBASE_APP_ID,
  };
}

export function extractFirebaseConfig(text: string): FirebaseOptions | null {
  const input = String(text || "").trim();
  if (!input) return null;

  try {
    const parsed = JSON.parse(input);
    if (parsed?.apiKey && parsed?.projectId && parsed?.appId) return parsed;
  } catch {}

  const keys = ["apiKey", "authDomain", "projectId", "storageBucket", "messagingSenderId", "appId", "measurementId"];
  const cfg: any = {};
  for (const key of keys) {
    const m = input.match(new RegExp(`${key}\\s*:\\s*[\"']([^\"']+)[\"']`));
    if (m) cfg[key] = m[1];
  }
  if (cfg.apiKey && cfg.projectId && cfg.appId) return cfg;
  return null;
}

export function runtimeConfig(): FirebaseOptions | null {
  if (typeof window === "undefined" || !window.localStorage) return null;
  try {
    const raw = window.localStorage.getItem(FIREBASE_CONFIG_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function getFirebaseConfig(): FirebaseOptions | null {
  return envConfig() || runtimeConfig();
}

export function saveRuntimeFirebaseConfig(config: FirebaseOptions) {
  if (typeof window === "undefined" || !window.localStorage) return;
  window.localStorage.setItem(FIREBASE_CONFIG_STORAGE_KEY, JSON.stringify(config));
}

export function clearRuntimeFirebaseConfig() {
  if (typeof window === "undefined" || !window.localStorage) return;
  window.localStorage.removeItem(FIREBASE_CONFIG_STORAGE_KEY);
}

let cachedServices: CmmsFirebaseServices | null = null;

export function getFirebaseServices(): CmmsFirebaseServices | null {
  if (cachedServices) return cachedServices;
  const config = getFirebaseConfig();
  if (!config) return null;

  let app: ReturnType<typeof initializeApp>;
  try {
    app = getApps().length ? getApp() : initializeApp(config);
  } catch (e) {
    console.error("Firebase config غير صالح", e);
    return null;
  }
  let firestore: Firestore;
  try {
    firestore = initializeFirestore(app, {
      ignoreUndefinedProperties: true,
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    });
  } catch {
    // initializeFirestore throws if Firestore was already initialized; re-use the existing instance.
    firestore = getFirestore(app);
  }
  cachedServices = { app, auth: getAuth(app), firestore, config };
  return cachedServices;
}

export function subscribeFirebaseAuth(services: CmmsFirebaseServices, cb: (user: User | null) => void) {
  return onAuthStateChanged(services.auth, cb);
}

export async function signInFirebase(services: CmmsFirebaseServices, email: string, password: string) {
  return signInWithEmailAndPassword(services.auth, email.trim(), password);
}

export async function registerFirebase(services: CmmsFirebaseServices, email: string, password: string) {
  return createUserWithEmailAndPassword(services.auth, email.trim(), password);
}

export async function signOutFirebase(services: CmmsFirebaseServices) {
  return signOut(services.auth);
}

export async function ensureFirebaseUserProfile(services: CmmsFirebaseServices, user: User) {
  const token = await user.getIdTokenResult(true);
  const claims: any = token.claims || {};
  const claimRole = normalizeFirebaseRole(claims.role || claims.cmmsRole || claims.cmms_role);
  const claimTechId = String(claims.technicianId || claims.techId || claims.cmmsTechId || "");
  const email = String(user.email || "").toLowerCase();
  const isOwner = email === FIREBASE_OWNER_EMAIL;

  const ref = doc(services.firestore, "users", user.uid);
  const snap = await getDoc(ref);
  const existing: any = snap.exists() ? snap.data() : null;
  const storedRole = normalizeFirebaseRole(existing?.role);
  const role = isOwner ? "مدير" : (claimRole || storedRole || "طالب خدمة");
  const technicianId = existing?.technicianId || claimTechId || "";
  const nowIso = new Date().toISOString();
  const patch: any = snap.exists()
    ? {
        displayName: existing?.displayName || user.displayName || "",
        technicianId,
        updatedAtIso: nowIso,
        lastLoginAtIso: nowIso,
      }
    : {
        email: user.email || "",
        displayName: user.displayName || "",
        role,
        technicianId,
        createdAtIso: nowIso,
        updatedAtIso: nowIso,
        lastLoginAtIso: nowIso,
      };

  try {
    await setDoc(ref, patch, { merge: true });
  } catch (e) {
    console.warn("تعذر تحديث ملف المستخدم؛ سيتم استخدام الدور المقروء فقط", e);
  }

  return { ...(existing || {}), ...patch, role, email: user.email || existing?.email || "", uid: user.uid, claims, isOwner };
}

const ENTITY_COLLECTION_PATH = ["cmms", "main", "entities"] as const;

export async function loadCmmsStateFromFirestore(services: CmmsFirebaseServices) {
  const snap = await getDocs(collection(services.firestore, ...ENTITY_COLLECTION_PATH));
  if (snap.empty) return null;
  const raw: any = {};
  snap.forEach((d) => {
    raw[d.id] = d.data()?.value;
  });
  return raw;
}

function stableJson(value: any) {
  return JSON.stringify(value ?? null);
}

export function changedEntityKeys(prev: any, next: any) {
  const keys = new Set([...Object.keys(prev || {}), ...Object.keys(next || {})]);
  keys.delete("_meta");
  return [...keys].filter((k) => stableJson(prev?.[k]) !== stableJson(next?.[k]));
}

export async function saveCmmsStateToFirestore(services: CmmsFirebaseServices, prev: any, next: any, actor: { uid?: string; email?: string | null; role?: string }) {
  const changed = changedEntityKeys(prev, next);
  if (!changed.length) return [];
  const batch = writeBatch(services.firestore);
  const at = new Date().toISOString();
  for (const key of changed) {
    const ref = doc(services.firestore, ...ENTITY_COLLECTION_PATH, key);
    batch.set(ref, {
      value: next?.[key] ?? null,
      updatedAtIso: at,
      updatedBy: actor.uid || "",
      updatedByEmail: actor.email || "",
      updatedByRole: actor.role || "",
    }, { merge: false });
  }
  await batch.commit();
  return changed;
}

export async function listFirebaseUsers(services: CmmsFirebaseServices) {
  const snap = await getDocs(collection(services.firestore, "users"));
  const rows: any[] = [];
  snap.forEach((d) => rows.push({ id: d.id, uid: d.id, ...d.data() }));
  return rows.sort((a, b) => String(a.email || "").localeCompare(String(b.email || "")));
}

export async function updateFirebaseUserProfile(services: CmmsFirebaseServices, uid: string, patch: any) {
  await updateDoc(doc(services.firestore, "users", uid), { ...patch, updatedAtIso: new Date().toISOString() });
}
