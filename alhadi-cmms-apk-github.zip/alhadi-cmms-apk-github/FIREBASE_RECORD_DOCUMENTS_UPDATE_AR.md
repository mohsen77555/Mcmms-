# تحديث Firebase: تخزين كل سجل كمستند مستقل

تم تعديل مشروع CMMS ليستخدم بنية Firestore أدق بدل حفظ كل قسم كمصفوفة كبيرة داخل مستند واحد.

## البنية الجديدة

```txt
cmms/main/meta/settings
cmms/main/meta/schema
cmms/main/records/assets/items/{assetId}
cmms/main/records/workOrders/items/{workOrderId}
cmms/main/records/stockTx/items/{transactionId}
cmms/main/records/readings/items/{readingId}
cmms/main/records/items/items/{itemId}
cmms/main/records/technicians/items/{technicianId}
...
```

كل كيان داخل التطبيق له مجموعة مستقلة تحت:

```txt
cmms/main/records/{entityName}/items/{recordId}
```

## لماذا هذا أفضل؟

- يقلل خطر وصول مستند واحد إلى حد الحجم.
- يجعل التحديثات أصغر: تعديل أصل واحد يكتب مستند الأصل فقط.
- يسمح بقواعد صلاحيات أدق على مستوى السجل.
- يحافظ على دعم البيانات القديمة الموجودة في `cmms/main/entities` للقراءة والترحيل.

## ما الذي تغير في الملفات؟

- `src/firebaseCmms.ts`: تمت إعادة بناء طبقة التخزين لتقرأ وتكتب السجلات كمستندات مستقلة.
- `firestore.rules`: تمت إضافة قواعد للمسار الجديد `records/{entity}/items/{id}`.
- `src/App.tsx`: تمت إضافة زر ترحيل داخل شاشة `Firebase والصلاحيات`.

## طريقة الترحيل من التطبيق

بعد نشر القواعد الجديدة وبناء APK:

1. افتح التطبيق بحساب المدير أو المشرف.
2. ادخل إلى `المزيد → Firebase والصلاحيات`.
3. اضغط `ترحيل/تحديث كل البيانات إلى مستندات مستقلة`.
4. بعد النجاح ستبقى البيانات القديمة قابلة للقراءة، لكن البيانات الجديدة ستُحفظ في البنية الجديدة.

## ملاحظة

الحذف يستخدم Tombstone document بدل الحذف الفيزيائي حتى لا تعود السجلات المحذوفة من النسخة القديمة أثناء فترة الانتقال.
