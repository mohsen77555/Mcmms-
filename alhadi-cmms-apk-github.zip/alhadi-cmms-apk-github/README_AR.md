# Alhadi CMMS Android APK — Firebase Backend

هذه النسخة تحول تطبيق CMMS إلى APK عبر GitHub Actions، وتضيف Firebase Auth + Firestore + Firestore Security Rules.

## ما الجديد؟

- تسجيل دخول عبر Firebase Authentication.
- حفظ بيانات CMMS في Firestore بدل الاعتماد على role selector داخل الواجهة.
- صلاحيات Backend-Enforced عبر `firestore.rules`.
- شاشة داخل التطبيق: `المزيد → Firebase والصلاحيات`.
- شاشة إدارة المستخدمين: `المزيد → المستخدمون والصلاحيات` للمدير/المشرف.

## بناء APK من الهاتف فقط

ارفع ملف `alhadi-cmms-apk-github.zip` إلى GitHub بنفس الاسم السابق. سيعمل Workflow الحالي ويبني APK تلقائيًا.

بعد اكتمال Actions حمّل Artifact:

`Alhadi-CMMS-debug-apk / app-debug.apk`

## ربط Firebase

بعد تثبيت APK، افتح:

`المزيد → Firebase والصلاحيات`

والصق كائن `firebaseConfig` من Firebase Console. راجع ملف:

`FIREBASE_SETUP_FROM_PHONE_AR.md`

## قواعد Firestore

انشر ملف `firestore.rules` من Firebase Console → Firestore Database → Rules.

بريد المالك الافتراضي داخل القواعد:

`mohsenalhadi77555@gmail.com`

هذا البريد يحصل على دور `مدير` تلقائيًا عند تسجيل الدخول.

## ملاحظات مهمة

هذه نسخة Debug للتجربة. للنشر الرسمي في Google Play نحتاج Release AAB موقّع.

النسخة الحالية تحفظ كل قسم من بيانات CMMS كمستند Firestore مستقل، وهذا أفضل من مستند JSON واحد. المرحلة الإنتاجية الأعمق لاحقًا هي تحويل كل أصل وكل أمر عمل إلى مستند مستقل لقواعد أدق على مستوى السجل الواحد.
