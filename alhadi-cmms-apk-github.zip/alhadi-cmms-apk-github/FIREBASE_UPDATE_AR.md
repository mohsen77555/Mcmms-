# تحديث GitHub بهذه النسخة

لا تحذف ملف workflow الحالي.

من الهاتف:

1. افتح مستودع GitHub.
2. Add file → Upload files.
3. ارفع الملف الجديد بنفس الاسم: alhadi-cmms-apk-github.zip
4. Commit changes.
5. افتح Actions.
6. انتظر علامة النجاح الخضراء.
7. حمّل Artifact باسم Alhadi-CMMS-debug-apk.
8. ثبّت app-debug.apk.

بعد التثبيت اربط Firebase من داخل التطبيق حسب FIREBASE_SETUP_FROM_PHONE_AR.md.
